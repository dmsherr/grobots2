# swagger_client.LiftWorkApi

All URIs are relative to *https://changehost.changedomain.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_lift_location_work_list**](LiftWorkApi.md#get_lift_location_work_list) | **GET** /IntelligentAgent/Liftwork/Location/{LocationId} | 
[**get_lift_work_list**](LiftWorkApi.md#get_lift_work_list) | **GET** /IntelligentAgent/Liftwork/Lift/{LiftIPV6Id} | 


# **get_lift_location_work_list**
> LiftWork get_lift_location_work_list(location_id)



Returns a list of all lift work for a specific location.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.LiftWorkApi(swagger_client.ApiClient(configuration))
location_id = 56 # int | Specify the Location ID as a string in quotes.

try:
    api_response = api_instance.get_lift_location_work_list(location_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LiftWorkApi->get_lift_location_work_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **location_id** | **int**| Specify the Location ID as a string in quotes. | 

### Return type

[**LiftWork**](LiftWork.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_lift_work_list**
> LiftWork get_lift_work_list(lift_ipv6_id)



Returns a list of work for a specific lift ID.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.LiftWorkApi(swagger_client.ApiClient(configuration))
lift_ipv6_id = 56 # int | Specify the Lift IPV6 address as a string in quotes.

try:
    api_response = api_instance.get_lift_work_list(lift_ipv6_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LiftWorkApi->get_lift_work_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lift_ipv6_id** | **int**| Specify the Lift IPV6 address as a string in quotes. | 

### Return type

[**LiftWork**](LiftWork.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

