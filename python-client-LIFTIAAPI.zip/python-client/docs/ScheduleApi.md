# swagger_client.ScheduleApi

All URIs are relative to *https://changehost.changedomain.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_scheduled_starts**](ScheduleApi.md#get_scheduled_starts) | **GET** /IntelligentAgent/starts | 


# **get_scheduled_starts**
> LiftInfo get_scheduled_starts()



Returns the list of lifts scheduled to start next.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.ScheduleApi(swagger_client.ApiClient(configuration))

try:
    api_response = api_instance.get_scheduled_starts()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScheduleApi->get_scheduled_starts: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**LiftInfo**](LiftInfo.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

