# LiftWork

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **int** |  | [optional] 
**lift_work_description** | **str** |  | [optional] 
**lift_work_id** | **str** |  | [optional] 
**lift_work_start_time** | **str** |  | [optional] 
**lift_work_stop_time** | **str** |  | [optional] 
**lift_work_location_id** | **str** |  | [optional] 
**lift_load_center** | **float** |  | [optional] 
**lift_work_weight** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


