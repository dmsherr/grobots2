# swagger_client.LiftsApi

All URIs are relative to *https://changehost.changedomain.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_lift_locations**](LiftsApi.md#get_lift_locations) | **GET** /IntelligentAgent/LiftLocations/{STATUS} | 
[**get_starts**](LiftsApi.md#get_starts) | **GET** /IntelligentAgent/starts/{LOCATION} | 
[**getlifts**](LiftsApi.md#getlifts) | **GET** /IntelligentAgent/lifts | 


# **get_lift_locations**
> LiftInfo get_lift_locations(status)



This operation returns a list of lifts and their location details 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.LiftsApi(swagger_client.ApiClient(configuration))
status = 56 # int | Specify the Lift STATUS as an integer. 0 = inactive 1 = active

try:
    api_response = api_instance.get_lift_locations(status)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LiftsApi->get_lift_locations: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **status** | **int**| Specify the Lift STATUS as an integer. 0 &#x3D; inactive 1 &#x3D; active | 

### Return type

[**LiftInfo**](LiftInfo.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_starts**
> LiftInfo get_starts(location)



Returns a list of lifts scheduled to start for a specific location.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.LiftsApi(swagger_client.ApiClient(configuration))
location = 'location_example' # str | Specify the value of the LOCATION ID as a string

try:
    api_response = api_instance.get_starts(location)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LiftsApi->get_starts: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **location** | **str**| Specify the value of the LOCATION ID as a string | 

### Return type

[**LiftInfo**](LiftInfo.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getlifts**
> LiftInfo getlifts()



Returns a list of lifts based on the token entitlement scope of the client.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: AccessCode
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.LiftsApi(swagger_client.ApiClient(configuration))

try:
    api_response = api_instance.getlifts()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LiftsApi->getlifts: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**LiftInfo**](LiftInfo.md)

### Authorization

[AccessCode](../README.md#AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

