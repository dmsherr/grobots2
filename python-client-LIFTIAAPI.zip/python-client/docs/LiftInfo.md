# LiftInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **int** |  | [optional] 
**lift_description** | **str** |  | [optional] 
**lift_ipv6_id** | **str** |  | [optional] 
**lift_start_time** | **str** |  | [optional] 
**lift_start_time_unix** | **str** |  | [optional] 
**location_id** | **str** |  | [optional] 
**lift_fuel_level** | **float** |  | [optional] 
**lift_fuel_type** | **str** |  | [optional] 
**lift_fork_position** | **float** |  | [optional] 
**lift_direction** | **str** |  | [optional] 
**lift_vibration_hz** | **float** |  | [optional] 
**lift_velocity** | **float** |  | [optional] 
**lift_engine_temp_c** | **float** |  | [optional] 
**lift_engine_temp_f** | **float** |  | [optional] 
**lift_engine_temp_k** | **float** |  | [optional] 
**lift_engine_temp_r** | **float** |  | [optional] 
**lift_latitude** | **float** |  | [optional] 
**lift_longitude** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


