# swagger_client.LiftInfoApi

All URIs are relative to *https://changehost.changedomain.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateliftinfo**](LiftInfoApi.md#updateliftinfo) | **POST** /IntelligentAgent/updateliftinfo/{LiftIPV6Id} | 


# **updateliftinfo**
> LiftInfo updateliftinfo(lift_ipv6_id)



Update Lift Information

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure OAuth2 access token for authorization: admin_AccessCode
configuration = swagger_client.Configuration()
configuration.access_token = 'YOUR_ACCESS_TOKEN'

# create an instance of the API class
api_instance = swagger_client.LiftInfoApi(swagger_client.ApiClient(configuration))
lift_ipv6_id = 'lift_ipv6_id_example' # str | Specify the Lift IPV6 address as a string in quotes.

try:
    api_response = api_instance.updateliftinfo(lift_ipv6_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LiftInfoApi->updateliftinfo: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lift_ipv6_id** | **str**| Specify the Lift IPV6 address as a string in quotes. | 

### Return type

[**LiftInfo**](LiftInfo.md)

### Authorization

[admin_AccessCode](../README.md#admin_AccessCode)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

