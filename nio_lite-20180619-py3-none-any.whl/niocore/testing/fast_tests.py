try:
    from nose2.events import Plugin

    class FastUnitTests(Plugin):
        commandLineSwitch = (None, 'fast', 'Run tests that do not sleep')

        def startTest(self, ev):
            test_method = getattr(ev.test, ev.test._testMethodName, None)
            if test_method and getattr(test_method, '_sleeping', False):
                # Set the setup, teardown, and test methods to just pass
                # TODO: Figure out how to automatically skip the test from here
                setattr(ev.test, 'setUp', self._passer)
                setattr(ev.test, 'tearDown', self._passer)
                setattr(ev.test, ev.test._testMethodName, self._passer)

                # mark the test as skipped
                ev.result.addSkip(ev.test, 'Not running tests that sleep')
                ev.handled = True

        def _passer(self, *args, **kwargs):
            pass
except ImportError:
    # Do not require to have nose2 installed when running unittests
    pass


def sleeping_test(test_func):
    setattr(test_func, '_sleeping', True)
    return test_func
