from unittest.mock import patch
import multiprocessing

from nio.util.runner import RunnerStatus
from niocore.core.ipc.native.service import IPCService
from niocore.testing.test_case import NIOCoreTestCase
from nio.block.base import Block
from niocore.core.service.context import CoreServiceContext
from niocore.core.service.launcher import ServiceLauncher
from nio.router.base import BlockRouter
from nio.service.base import Service


class NIOServiceTestCase(NIOCoreTestCase):

    """ A test case that builds a service context and configures a service """

    def configure_service(self, service_pipe, core_pipe):
        """Instanstiates service launcher and configures it"""
        context = CoreServiceContext(
            self.get_service_type(),
            self.get_service_properties(),
            IPCService,
            service_pipe,
            core_pipe,
            self.get_service_blocks(),
            BlockRouter,
            # no modules, since we're not proxying in a new process
            modules={})
        self.service_launcher = ServiceLauncher(context)
        # Don't want the service to actually block
        with patch.object(self.service_launcher, '_block'):
            self.service_launcher.configure()
        self.service = self.service_launcher._service

    def get_service_blocks(self):
        """Override this to specify the definition of blocks in the service"""
        return [{
            "type": Block,
            "properties": {}
        }]

    def get_service_properties(self):
        """Override this to specify the service properties"""
        return {
            "name": "DummyService",
            "auto_start": False,
            "execution": [],
            "mappings": []
        }

    def get_service_type(self):
        """Override this to specify the service type"""
        return Service

    def get_core_target(self):
        """Override this to specify the process startup routine"""
        return NotImplementedError

    def stop_service_on_teardown(self):
        """Override this to specify if service is stopped at taerdown"""
        return True

    def setUp(self):
        super().setUp()
        # simulate core process
        service_pipe, core_pipe = multiprocessing.Pipe()
        self._process = multiprocessing.Process(
            target=self.get_core_target(),
            args=(service_pipe, core_pipe,))
        self._process.start()

        # setup service
        self.configure_service(service_pipe, core_pipe)
        self.assertEqual(self.service.status, RunnerStatus.configured)
        self.service_launcher._start_service()

    def tearDown(self):
        if self.stop_service_on_teardown():
            self.service_launcher._stop_service()
        super().tearDown()
