from nio.modules.context import ModuleContext
from nio.modules.settings import Settings
from nio.testing.web_test_case import NIOWebTestCase
from niocore.modules.web.cherrypy.module import CherryPyWebModule
from .test_case import NIOCoreTestCase


class NIOCoreWebTestCase(NIOWebTestCase, NIOCoreTestCase):

    def get_module(self, module_name):
        if module_name == 'web':
            return CherryPyWebModule()
        else:
            return super().get_module(module_name)

    def get_context(self, module_name, module):
        if module_name == 'security':
            context = ModuleContext()
            context.users = {}
            context.permissions = {
                "Guest": ["*"]
            }
            return context
        else:
            return super().get_context(module_name, module)

    def get_test_modules(self):
        return super().get_test_modules() | {'web', 'security'}

    def get_conf_host(self):
        """ Returns the host configured in Settings, or a default.

        """
        return Settings.get('server', 'host', fallback='127.0.0.1')

    def get_conf_port(self):
        """ Returns the port configured in Settings, or a default.

        """
        return Settings.getint('server', 'port', fallback=8182)
