from .test_case import NIOCoreTestCase


class NIOCoreSecurityTestCase(NIOCoreTestCase):

    def get_test_modules(self):
        return super().get_test_modules() | {'security'}
