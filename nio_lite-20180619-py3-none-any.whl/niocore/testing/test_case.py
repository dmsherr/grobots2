from nio.modules.settings import Settings
from nio.testing.test_case import NIOTestCase, NIOTestCaseNoModules
from niocore.modules.settings.ini.module import SettingsIniModule
from niocore.util.environment import NIOEnvironment


class NIOCoreTestCase(NIOTestCase):

    def get_module(self, module_name):
        # make sure in niocore tests Settings are loaded using the Core
        # implementation mostly to cover usage of 'update' and 'import_file'
        if module_name == 'settings':
            return SettingsIniModule()
        else:
            return super().get_module(module_name)

    def tearDown(self):
        try:
            Settings.clear()
        # test cases with no modules will raise this exception
        except NotImplementedError:
            pass
        NIOEnvironment.reset()
        super().tearDown()


class NIOCoreTestCaseNoModules(NIOCoreTestCase, NIOTestCaseNoModules):
    pass
