from niocore.testing.service_test_case import NIOServiceTestCase
from niocore.testing.test_case import NIOCoreTestCase, NIOCoreTestCaseNoModules
from niocore.testing.web_test_case import NIOCoreWebTestCase

# declaring where to get namespace prefixes from when running niocore unit tests
NIOCoreModuleLocations = ["niocore.modules", "nio.modules"]
