from nio.modules.settings import Settings
from nio.util.discovery import is_class_discoverable
from nio.util.logging import get_nio_logger
from niocore.core.block.manager import BlockManager
from niocore.core.component import CoreComponent
from niocore.core.context import InvalidContext
from niocore.core.loader.discover import Discover
from niocore.core.loader.loader import Loader
from niocore.core.service.manager import ServiceManager
from niocore.util.environment import NIOEnvironment
from niocore.util.sorting import sort_collection

__all__ = ['ComponentManager']

PredefinedComponents = [BlockManager, ServiceManager]


class ComponentManager(object):

    """ Manager for Core components

    Handles every operation related to core components.
    Discover, starts and stops core components installed in the system

    """

    def __init__(self):
        self.logger = get_nio_logger('ComponentManager')
        self._components = []
        self._default_discoverability = \
            Settings.getboolean("discovery", "component_default",
                                fallback=False)

    def _discover_installed(self, default_namespaces):
        """ Discover components in namespaces as well as configured paths.

        This method will look through the paths configured in the environment
        or default namespaces and return any components marked discoverable.

        Args:
            default_namespaces (string): Comma separated namespaces

        Returns
            components (list): List of component classes
        """

        self.logger.debug("Discovering components ...")

        namespaces = set()
        for rsc_path in NIOEnvironment.get_resource_paths('components',
                                                          default_namespaces):
            namespaces.add(Loader.load_path(rsc_path))

        components = []
        for namespace in namespaces:
            self.logger.debug("Looking in {0}".format(namespace))
            comps = Discover.discover_classes(
                namespace, CoreComponent, self._discover_component_criteria)

            self.logger.debug("{0} components found".format(len(comps)))
            components.extend(comps)

        self.logger.info("{} components found, {}".format(
            len(components), [_type.__name__ for _type in components]))
        return components

    def _discover_component_criteria(self, obj):
        return is_class_discoverable(obj, self._default_discoverability)

    def discover(self, exclusions):
        classes = self._discover_installed("niocore.components")
        components = [klass() for klass in classes
                      if klass.__name__ not in exclusions]

        components.extend([component()
                           for component in PredefinedComponents])

        self._components = sort_collection(components, "get_order")
        self.logger.debug('%s components discovered' % len(self._components))
        return self._components

    @property
    def components(self):
        return self._components

    def configure(self, context):
        """ Initialize all core components

        Args:
            context (CoreContext): Initialization context containing
                initialization values needed by all components
        """
        # Configure components

        if context is None:
            raise InvalidContext(None)

        for component in self._components:
            context.system.register_component(component)
            component.do_configure(context)

    def start(self):
        """ Starts all components

        Components will start depending on start_level value (asc) to handle
        dependency and order in the startup process

        """
        for component in self._components:
            component.do_start()

    def stop(self):
        """ Stops all components

        Components will stop depending on start_level value (desc) to handle
        dependency and order in the stopping process

        """
        for component in reversed(self._components):
            component.do_stop()
