from niocore.core.loader.discover import Discover
from nio.modules.module import Module


class ModuleDiscovery(object):

    """ Class for module discovery functionality """

    @classmethod
    def discover_modules(cls, locations, logger):
        logger.debug("Discovering functional modules...")

        discovered = []
        for location in locations:
            location_modules = \
                Discover.discover_classes(location, Module)
            discovered.extend(location_modules)

            logger.debug("{0} modules discovered in {1}".format(
                len(location_modules), location))

        return {module.get_module_name(): module for module in discovered}
