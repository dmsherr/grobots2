"""

 Base class for Type and Instance Management

"""
from niocore.configuration import Configuration, CfgType
from niocore.core.api.collections.typed import ResourceTypedCollection, \
    ResourceTypedFactory
from niocore.core.component import CoreComponent
from niocore.core.hooks import CoreHooks


class TypedManager(CoreComponent):

    """ Generic Type Manager that is a core component

    Base class for handling types and configured instances

    Discover specific types and links those types to a list of
    configuration instances

    """

    def __init__(self, config_name):
        super().__init__()
        self._config_name = config_name
        # Dictionary id / (type,config)
        self._instance_collection = None
        # List for available types
        self._type_collection = None

    @property
    def types(self):
        """List of types available"""
        return self._type_collection

    @property
    def instances(self):
        return self._instance_collection

    @property
    def instance_ids(self):
        """Returns list of instances available"""
        return self.instances.ids \
            if self.instances is not None else []

    @property
    def instance_properties(self):
        """Returns list of instances available"""
        return self.instances.properties \
            if self.instances is not None else []

    def _get_resource_typed_factory(self):
        """ Allows resource typed factory override
        """
        return ResourceTypedFactory()

    def _create_typed_collection(self, configuration):
        """ Creates the typed collection
        """
        collection = \
            ResourceTypedCollection(self._config_name,
                                    configuration,
                                    self._type_collection,
                                    self._get_resource_typed_factory())
        return collection

    def configure(self, context):
        """ Configures the manager

        Discovers classes installed based on a type
        Builds an collection of instances, types and configs

        """

        super().configure(context)
        # class most likely will be 'Configuration' but allow for redefinition
        config = self._fetch_configuration()
        # create type collection
        self._type_collection = self._get_discoverable_collection()

        # retrieve list of instance configuration
        self._instance_collection = self._create_typed_collection(config)

        # Subscribe to configuration changes.
        CoreHooks.attach('configuration_change',
                         self._on_configuration_change)

    def _fetch_configuration(self):
        return self.get_type_configuration_class()(self._config_name,
                                                   fetch_on_create=True,
                                                   is_collection=True,
                                                   substitute=False)

    def _on_configuration_change(self, cfg_type):
        """ Handler for the configuration_change hook.

        Read the Configuration again and updates the instance_collection
        by providing this new configuration
        """
        # verify it matches type of specified
        if cfg_type in [self.get_configuration_type(), CfgType.all]:
            config = self._fetch_configuration()
            self._instance_collection.refresh(config)

    def get_configuration_type(self):
        # Override to specify a specific configuration type
        return CfgType.all

    def get_type_configuration_class(self):
        """ Return default configuration class type
        """
        return Configuration

    def get_info(self, id):
        """ Returns instance's info based on id

         Args:
            id (str): the instance's identifier

        Returns:
            TypedConfiguration instance

        """
        return self.instances.get_info(id) \
            if self.instances is not None else None

    def _get_class(self, class_path):
        """ Returns a class base on a string type

        Validates the class in part of the list of types discovered

        Arguments:
            class_path (str): path to class

        Returns:
            Class type

        Raises:
            RuntimeError: if class does not exists
        """
        if self._type_collection is not None:
            _type = self._type_collection.get_type(class_path)
            if _type is not None:
                return _type
        # TODO: return more specific error
        raise TypeError("Invalid or not available class: %s" % class_path)

    def _get_discoverable_collection(self):
        """ Overrideable method providing discoverable collection
        """
        raise NotImplementedError
