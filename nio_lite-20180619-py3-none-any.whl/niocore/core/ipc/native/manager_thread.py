from threading import Thread


class IPCManagerThread(Thread):
    """ This class host an ipc message manager within a thread.
    """

    def __init__(self, manager):
        """ Initializes the thread.

        Args:
            manager (Manager): manager instance it will run
        """
        super().__init__(daemon=True)

        self._manager = manager

    def run(self):
        """ Manager thread entry point.

        Starts the manager

        """
        self._manager.start()

    def stop(self):
        """ Stops the thread and the manager
        """
        self._manager.stop()
