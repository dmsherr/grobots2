from threading import Lock

from niocore.core.ipc.native.manager import IPCManager
from niocore.core.ipc.native.manager_thread import IPCManagerThread
from niocore.common.ipc.base import IPCBase
from niocore.util.unique import Unique


class IPC(IPCBase):
    """ Base class for IPC communications.

    Creates an IPC manager for given pipe and callback setting it to run
    inside an IPC manager thread.
    """

    def __init__(self, pipe, callback):
        """ Initializes class variables
        """
        self._pipe = pipe
        self._pipe_lock = Lock()
        self._callback = callback
        self._manager = None
        self._manager_thread = None

    def start(self):
        """ Instantiates the manager and starts the manager thread
        """
        self._manager = IPCManager(self._pipe,
                                   self._callback,
                                   self.__class__.__name__)
        self._manager_thread = IPCManagerThread(self._manager)
        self._manager_thread.start()

    def stop(self):
        """ Stops the manager and closes the pipe
        """
        if self._manager_thread:
            self._manager_thread.stop()
            self._manager_thread.join()
            self._manager_thread = None

        if self._pipe:
            with self._pipe_lock:
                self._pipe.close()
            self._pipe = None

    def send(self, message, callback=None, async_response=True):
        """ Sends a message, thus initiating a request, where a
        response is expected.

        If message does not have an 'id' set, a unique 'id' is
        created and assigned to it. This 'id' will be correlated
        with a potential response completing the request round-trip

        Args:
            message: message to deliver
            callback: callback to call when a response is received, if not
                specified default callback will be used
            async_response: specifies whether or not to deliver response
                in a new thread
        """
        if self._pipe:
            if message.header.message_id is None:
                message.header.message_id = Unique.id()
            self._manager.add_request(message.header.message_id,
                                      callback,
                                      async_response)
            with self._pipe_lock:
                self._pipe.send(message)

    def send_async(self, message):
        """ Sends a message where a response is not expected.

        Args:
            message: message to deliver
        """
        if self._pipe:
            with self._pipe_lock:
                self._pipe.send(message)

    def is_request_pending(self, _id):
        """ Finds out whether a given request is pending

        This is useful when an id was provided in the message and
        caller wants to find out if the request is still pending.

        Args:
            _id: request identifier
        """
        return self._manager.get_request(_id) is not None
