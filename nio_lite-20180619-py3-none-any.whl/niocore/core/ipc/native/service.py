from niocore.core.ipc.native.base import IPC


class IPCService(IPC):
    """ Class to be instantiated from the service (child process)
    """

    def __init__(self, service_pipe, core_pipe, callback):
        super().__init__(service_pipe, callback)

        # per convention, close the core pipe in the service
        if core_pipe:
            core_pipe.close()
