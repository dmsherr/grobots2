from niocore.core.ipc.native.base import IPC


class IPCCore(IPC):
    """ Class to be instantiated from the core for each process
    """

    def __init__(self, service_pipe, core_pipe, callback):
        super().__init__(core_pipe, callback)

        # per convention, close the service pipe in core
        if service_pipe:
            service_pipe.close()
