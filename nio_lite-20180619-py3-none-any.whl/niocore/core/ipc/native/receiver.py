from threading import Event


class IPCReceiver(object):
    """ Utility class that allows the definition of a request
    callback to collect a response (see receive method) while including
    'wait' built-in functionality
    """

    def __init__(self):
        self.response = None
        self._stop_waiting_event = Event()

    def receive(self, message):
        """ Callback method that will be called to
        store where the request response is saved.
        """
        self.response = message
        self._stop_waiting_event.set()

    def wait(self, max_wait):
        """ Allows to wait until response is received or time expires

        Args:
            max_wait: maximum waiting time

        Returns:
            Response body when received otherwise None
        """
        self._stop_waiting_event.wait(max_wait)
        self._stop_waiting_event.clear()
        if self.response:
            return self.response.body
