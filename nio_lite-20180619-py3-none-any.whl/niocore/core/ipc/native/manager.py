from threading import Event, RLock

from datetime import timedelta
from niocore.common.ipc import IPCMessage
from nio.util.logging import get_nio_logger
from nio.util.threading import spawn
from nio.modules.scheduler.job import Job

__all__ = ["IPCManager"]


class PendingRequest(object):
    def __init__(self, _id, callback, async_response):
        self.id = _id
        self.callback = callback
        self.async_response = async_response


class IPCManager(object):
    POLL_PERIOD = 0.1

    def __init__(self, pipe, default_callback, name):
        super().__init__()

        self._pipe = pipe
        self._default_callback = default_callback
        self.logger = get_nio_logger(name)
        self._stop_event = Event()
        self._requests = dict()
        self._requests_lock = RLock()

    def start(self):
        """ Starts the manager

        """
        while not self._stop_event.is_set():
            try:
                if self._pipe.poll(IPCManager.POLL_PERIOD):
                    message = self._pipe.recv()
                    self.logger.debug("Received message: {0}".format(message))
                    try:
                        self._on_message(message)
                    except Exception:  # pragma: no cover
                        self.logger.exception('Delivering message')
            except OverflowError:
                # Occurs when date changes backwards (say a device goes to sleep
                # and loses current date), error details:
                # fd_event_list = self._poll.poll(timeout)
                # OverflowError: Python int too large to convert to C int
                self.logger.exception("Receiving data from pipe, ignoring it")
            except EOFError:
                # One of the ends of the pipe is closed, we're done
                break
            except Exception:
                self.logger.exception("Error receiving data from pipe")
                break
        self.logger.info('Leaving IPC manager')

    def stop(self):
        self._stop_event.set()
        # clean up requests
        self._requests = dict()

    def add_request(self, _id, callback, async_response=True):
        with self._requests_lock:
            request = PendingRequest(_id, callback, async_response)

            # create a job to purge request on timeout
            Job(self._on_request_timeout,
                timedelta(seconds=IPCMessage.TIME_TO_LIVE),
                False,
                request)

            self.logger.debug("NEW REQUEST : %s" % request.id)
            # save request
            self._requests[_id] = request

    def _on_request_timeout(self, request):
        with self._requests_lock:
            if request.id in self._requests:
                self.logger.debug("REMOVING TIMEOUT REQUEST: %s" % request.id)
                self._requests.pop(request.id)
            else:
                self.logger.debug(
                    "CANNOT FIND TIMEOUT REQUEST: %s" %
                    request.id)

    def _on_message(self, message):
        handler = None
        async_response = False
        if message.header.correlation_id:
            # find the request, remove it and call its callback
            request = self.get_request(message.header.correlation_id)
            if request:
                with self._requests_lock:
                    self._requests.pop(message.header.correlation_id)
                    self.logger.debug("REMOVED MSG REQUEST: %s" % request.id)
                handler = request.callback
                async_response = request.async_response
            else:
                # request timed-out already
                self.logger.debug("Response: {0} received, and request "
                                   "timed-out".format(message))
                return

        # if no handler was set, use default handler
        if handler is None:
            # use async handler
            handler = self._default_callback

        if async_response:
            self.logger.debug("Spawning a thread to deliver message: {0}".
                               format(message.body))
            spawn(handler, message)
        else:
            self.logger.debug("Calling handler to deliver message: {0}".
                               format(message.body))
            try:
                handler(message)
            except Exception:
                self.logger.exception(
                    "Delivering message: {0}".format(message))

    def get_request(self, _id):
        with self._requests_lock:
            return self._requests.get(_id)
