"""

   NIO Block Manager

"""
from nio.router.base import MissingBlock
from niocore.configuration import CfgType
from niocore.core.block.discoverable_collection import \
    BlocksDiscoverableCollection
from niocore.core.loader.loader import Loader
from niocore.core.typed import TypedManager
from niocore.configuration.block import BlockConfiguration


class BlockManager(TypedManager):

    """ Block Manager core component

    Handles block discovering and management

    """

    _name = "BlockManager"

    def __init__(self):
        # Set myself up as a typed manager for blocks
        super().__init__("blocks")

    def get_configuration_type(self):
        return CfgType.block

    def _get_discoverable_collection(self):
        return BlocksDiscoverableCollection()

    def fetch_block_template(self, id):
        """ Fetches block template (type and properties) based on a name

        Args:
            id: block identifier

        Returns:
            block info {class type, block properties as an AttributeDict}
        """
        try:
            typed_configuration = self.get_info(id)
            return {'type': typed_configuration.type,
                    'properties': typed_configuration.config.data}
        except Exception as e:
            self.logger.exception("No such block: %s" % id)
            raise MissingBlock("No such block: %s" % id, e)

    def get_type_configuration_class(self):
        """ Specify configuration type for collection elements
        (see TypedManager)
        """
        return BlockConfiguration

    def validate_block_folder(self, block_folder):
        """ Validates blocks defined under a given folder

        Attempts to construct a namespace containing the 'block_folder' with
        every possible location where blocks can be defined, once it finds
        one valid namespace containing the 'block_folder' in question,
        it validates it.

        Args:
            block_folder (str): relative block folder

        Returns:
             (valid (bool), errors (dict))
             tuple containing overall operation result, and in case there were
             errors loading, a dict containing:
             {[module name] or [block_folder]: [failure reason]}
        """

        # ensure type collection is available since this functionality my be
        # called when configuring project manager component, which is set to
        # execute before block manager component
        if self.types is None:
            self.logger.info(
                "Skipping validation, block manager is not configured")
            return (True, {})

        # find out every potential root namespace for 'blocks'
        namespaces = self.types._get_type_namespaces()
        for namespace in namespaces:
            namespace_to_block = "{}.{}".format(namespace,
                                                block_folder)
            # is this namespace containing the block folder valid?
            if Loader.is_namespace_valid(namespace_to_block):
                self.logger.info(
                    "Validating blocks at {}".format(namespace_to_block))
                # once a valid namespace is found, validate and return
                return Loader.namespace_loadable(
                    namespace_to_block,
                    self.types._get_module_exclusions())

        # not a single potential namespace had this block folder
        return False, {block_folder: "Block folder is invalid"}
