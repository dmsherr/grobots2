"""

    API Resource

"""
from niocore.core.api.type import TypeResource


class BlockTypeResource(TypeResource):

    @property
    def properties(self):
        prop_dict = super().properties
        # add version shortcut
        prop_dict['version'] = prop_dict['properties']['version']['default']

        # Include our block inputs/outputs here for backwards compatibility
        prop_dict['attributes'] = {
            'input': [input.get_description()
                      for input in self._target.inputs()],
            'output': [output.get_description()
                       for output in self._target.outputs()]
        }
        return prop_dict
