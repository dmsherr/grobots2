from nio.block.base import Base as Block
from nio.modules.settings import Settings
from niocore.core.api.collections.factory import ResourceFactory
from niocore.core.api.collections.type import ResourceDiscoverableTypeCollection
from niocore.core.block.api.resource import BlockTypeResource


class BlocksDiscoverableCollection(ResourceDiscoverableTypeCollection):
    """ Provides the overriding methods that define a
    blocks discoverable collection
    """

    def __init__(self):
        # Note: set default discoverability before parent's __init__ since
        # when target is not specified, it itself triggers discoverable
        # operations
        self._default_discoverability = \
            Settings.getboolean("discovery", "block_default",
                                fallback=True)
        super().__init__("{}_types".format(self._get_resource_id()))

    def _get_resource_id(self):
        return "blocks"

    def _get_discoverable_base(self):
        return Block

    def _get_default_namespaces(self):
        return "blocks"

    def _get_default_discoverability(self):
        return self._default_discoverability

    def _get_resource_factory(self):
        return ResourceFactory(BlockTypeResource)

    def _get_module_exclusions(self):
        exclusions = Settings.get("discovery", "block_module_exclusions",
                                  fallback='*.tests, *.tests.*')
        return [item.strip() for item in exclusions.split(',')]
