"""
  NIO Core Hooks

"""
from niocore.util.hooks import Hooks


class CoreHooks(object):
    _hooks = Hooks(['exit', 'service_status_change', 'configuration_change'])

    @classmethod
    def attach(cls, point, callback):
        """ Attach a callback to a point

        """
        cls._hooks.attach(point, callback)

    @classmethod
    def run(cls, point, *args, **kwargs):
        """ Executes callbacks associated with a point

        Args:
            point (str): point for running callbacks
        """
        return cls._hooks.run(point, *args, **kwargs)

    @classmethod
    def detach(cls, point, callback):
        """ Detach a callback from a point

        """
        # doesn't matter if callback isn't registered
        if callback in cls._hooks._hooks[point]:
            cls._hooks.detach(point, callback)
