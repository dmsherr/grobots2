"""
   NIO Main entry


"""
import sys
import os
import multiprocessing
from argparse import ArgumentParser


def _nio_main():
    # make it so that child process does not inherit parent
    # The parent process starts a fresh python interpreter process.
    # The child process will only inherit those resources necessary
    # to run the process objects run() method
    try:
        multiprocessing.set_start_method('spawn')
    except:
        print("CRITICAL : n.io requires Python 3.4 or greater")
        sys.exit(1)

    argparser = ArgumentParser(
        description='''Executable for launching a NIO instance'''
    )
    argparser.add_argument('-s', '--settings', default=[], action='append',
                           help=("File defining global settings for "
                                 "the NIO instance"))
    argparser.add_argument('-r', '--root', default=os.getcwd(),
                           help="Working folder for the NIO instance")
    # TODO: remove when obsolete no longer applies
    # -e is an obsolete parameter maintained for backwards compatibility
    argparser.add_argument('-e', '--environment', default='nio.env',
                           help=("Environment variables from which to pull "
                                 "NIO config values (OBSOLETE, now they "
                                 "can be specified within [user_defined])"))
    argparser.add_argument('-l', '--logging', default='NOTSET',
                           help=("Default basic logging level to use before "
                                 "logging is configured"))
    args = argparser.parse_args()

    # Setup basic logging configuration before actual logging is configured,
    # if logging is NOTSET, default behavior for logging is to be at WARNING
    # level and go to stderr
    import logging
    # find out if specified logging is valid
    if args.logging in logging._nameToLevel:
        basic_logging_level = logging._nameToLevel[args.logging]
        if basic_logging_level != logging.NOTSET:
            logging.basicConfig(stream=sys.stdout, level=basic_logging_level)
    else:
        print("Unrecognized logging level: '{0}'".format(args.logging))
        sys.exit(1)

    if not args.settings:
        # set nio.conf as default if no conf. file was specified
        args.settings.append("nio.conf")

    # Sets NIO running environment
    from niocore.util.environment import NIOEnvironment

    # TODO: remove when obsolete no longer applies
    # temporary code to warn user if a variables file will be loaded
    show_load_warning = False
    if os.path.isfile(args.environment):
        show_load_warning = True
    else:
        from os.path import join
        env_file = join(args.root, args.environment)
        if os.path.isfile(env_file):
            show_load_warning = True
    if show_load_warning:
        print("WARNING, loading variables file: {} is OBSOLETE, "
              "please add your definitions to a [user_defined] section".
              format(args.environment))

    NIOEnvironment.set_environment(args.root,
                                   args.settings,
                                   args.environment)

    # Start NIO Server
    from niocore.core.server import NIOServer
    NIOServer().run()


if __name__ == '__main__':
    _nio_main()
