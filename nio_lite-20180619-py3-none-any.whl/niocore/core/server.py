"""
  NIO Main Server

"""
import signal
from os import name
from threading import Lock

from nio import Module
from nio.modules.initializer import ModuleInitializer
from nio.modules.settings import Settings
from nio.util.discovery import is_class_discoverable
from nio.util.flags_enum import FlagsEnum
from nio.util.logging import get_nio_logger
from nio.util.nio_time import get_nio_time
from nio.util.runner import RunnerStatus
from niocore.core.context import CoreContext
from niocore.core.hooks import CoreHooks
from niocore.core.loader.discover import Discover
from niocore.core.loop_guard import LoopGuard
from niocore.core.manager import ComponentManager
from niocore.util.environment import NIOEnvironment


class NIOServer(ModuleInitializer):

    """NIO Server. Single instance of the NIO core running as a process

    One instance of this class will be launched per running instance.

    """

    def __init__(self):
        """Creates the instance of the server.

        This method expects that the server.run() call will
        occur after initializing.
        """

        super().__init__()
        self.manager = None
        self._stop_lock = Lock()
        self.logger = get_nio_logger('default')
        self._status = FlagsEnum(RunnerStatus,
                                 RunnerStatus.created)
        self._loop_guard = LoopGuard()

    def run(self):
        """Runs the NIO Server.

        Initialize, starts and waits for a signal (TBD) to stop

        """
        try:
            self._configure()
        except:
            self.logger.critical('NIO failed to configure', exc_info=True)
            return

        try:
            self._start()

            if name == "nt":
                try:
                    import win32api

                    self.logger.info("Setting Console Ctrl Handler")
                    win32api.SetConsoleCtrlHandler(self._close_console, True)
                except ImportError:
                    self.logger.warning("pywin32 not installed for Python")

            signal.signal(signal.SIGINT, self._handle_keyboard_interrupt)
            # We need to handle this signal for when running as a service
            signal.signal(signal.SIGTERM, self._shutdown)

            self._block()
        except:
            self.logger.critical('Server has terminated abnormally',
                                 exc_info=True)
        finally:
            self._stop()

    def _configure(self):
        """Configure the main server and all of its components.

            Discovers modules
            Reads module configuration
            Initializes modules
            Discovers core components
            Configures core components
        """
        start_time = get_nio_time()

        self.status.set(RunnerStatus.configuring)

        module_types = self._discover_installed_modules(["niocore.modules"])
        # register modules
        for module_type in module_types:
            self.register_module(module_type())

        # initialize registered modules
        try:
            self.initialize(safe=True)
        except Exception:
            # likely for logger to be configured already since logging
            # is configured during first module initialization
            self.logger = get_nio_logger('default')
            self.logger.exception("Modules failed to initialize")
            raise

        # NIO logging configured, we can use it now
        self.logger = get_nio_logger('NIOServer')

        # Create Component Manager at this point.
        # modules are already initialized
        self.manager = ComponentManager()

        # Discover core components considering components to exclude
        try:
            self.manager.discover(self._get_component_exclusions())
        except Exception:
            self.logger.exception("NIO discover components failure")
            raise

        # Create the core component init context
        self.logger.debug('creating init context')
        context = CoreContext(self.manager.components,
                              self._initialized_modules)
        context.system.properties['start_time'] = start_time
        # Hook for exit signal
        CoreHooks.attach('exit', self._shutdown)

        # Initialize components
        try:
            self.manager.configure(context)
        except Exception:
            self.logger.exception("NIO components configuration failure")
            raise

        # Check for blocking method
        if context.loop_guard is not None:
            self._loop_guard = context.loop_guard

        self.status.set(RunnerStatus.configured)

    def _start(self):
        """ Starts the Server

        Calls the manager to start all components
        """
        if not self.status.is_set(RunnerStatus.started) and \
                not self.status.is_set(RunnerStatus.starting):
            self.status.set(RunnerStatus.starting)
            self.manager.start()
            self.status.set(RunnerStatus.started)

    def _stop(self):
        """ Stops the Server

        Calls the manager to stop all components
        """
        with self._stop_lock:
            if not self.status.is_set(RunnerStatus.stopped) and \
                    not self.status.is_set(RunnerStatus.stopping):
                self.status.set(RunnerStatus.stopping)
                try:
                    self.manager.stop()
                    self.finalize()
                finally:
                    self.status.set(RunnerStatus.stopped)

    def _shutdown(self, *args, **kwargs):
        """ Have signature with variable arguments to accommodate a call
        that can potentially come from signal.SIGTERM callback.
        """
        self.logger.info("Shutting down")
        # Unblock loop
        self._loop_guard.unblock()

    def _close_console(self, signal_type):
        self.logger.info("Closing console - shutting down")
        self._shutdown()
        return True

    def _handle_keyboard_interrupt(self, signum, frame):  # pragma: no cover
        self.logger.info("Keyboard interrupt detected - shutting down")
        self._shutdown()

    def _block(self):  # pragma: no cover (can't test blocking...)
        """ Blocks the Server until signaled to finish"""

        self.logger.info('blocking')
        self._loop_guard.block()

    def _discover_installed_modules(self, namespaces):
        """ Discover modules in namespaces.

        This method will look through the specified namespaces, as well as the
        paths configured in the environment, and return any modules marked
        discoverable.

        Args:
            namespaces (list): List of stringed namespaces to start in

        Returns
            components (list): List of modules classes
        """

        # discover modules
        module_types = []
        for namespace in namespaces:
            self.logger.debug("Looking from modules in {0}".format(namespace))
            module_types.extend(Discover.discover_classes(namespace, Module))

        self.logger.info("{} modules found, {}".format(
            len(module_types), [_type.__name__ for _type in module_types]))
        return module_types

    @staticmethod
    def _discover_module_criteria(obj):
        # if module does not specify discoverability on its own, consider
        # it discoverable, i.e., passing True as default discoverability
        return is_class_discoverable(obj, True)

    def get_context(self, module):
        """ Provides initializer with prepared-core context for given
        module

        Args:
            module (module instance)

        Returns:
            core's module context
        """
        return module.prepare_core_context()

    def _get_component_exclusions(self):
        component_exclusions = \
            Settings.get("components", "disabled", fallback="SNMPAgent")
        if component_exclusions:
            return [component.strip()
                    for component in component_exclusions.split(',')]
        return []

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, status):
        self.logger.info("NIO server is {0}".format(status.name))
        self._status = status

    def _initialize_module(self, module, context, safe):
        # TODO: re-address this way of finding-out that a module has initialized
        # TODO: IF/WHEN we implement hooks for module lifecycle events
        super()._initialize_module(module, context, safe)
        if module.get_module_type() == "settings":
            NIOEnvironment.load_user_defined_from_settings()
        elif module.get_module_type() == "persistence":
            # read again user_defined settings after Persistence module is
            # available since some might have been stored using Persistence
            NIOEnvironment.update_user_defined_from_settings()

            NIOEnvironment.load_user_defined_from_persistence()

            # configure logging after persistence module is initialized
            # since in cloud environments logging configuration is stored
            # remotely, by the time peristence is initialized, settings module
            # has also been initialized
            from niocore.util.logging import configure as configure_logging
            configure_logging()
