"""

   Block Service Processor builder

"""
import copy

from nio.modules.settings import Settings
from nio.util.logging import get_nio_logger
from niocore.core.block.manager import BlockManager
from niocore.core.context import ContextBuilder
from niocore.util.environment import NIOEnvironment


class BlockBuilder(ContextBuilder):
    """A context builder that will prepare a service context with the service's
        block information.

    Participate in the building of the service context by providing block
    related information. This info will be later used by the service during
    the block initialization process.

    """

    def __init__(self, block_manager):
        """ Sets Block Manager to use for retrieving block information

        Args:
            block_manager: Block Manager instance to use

        """
        if not isinstance(block_manager, BlockManager):
            raise TypeError('Invalid Block Manager')
        self.logger = get_nio_logger('BlockBuilder')
        self._block_manager = block_manager
        # keep a cache of block router types
        self._block_router_types = {}

    def prepare_context(self, context, *args):
        """Prepares the service context by adding block information

        Adds list of block types and block router type to the context

        Args:
            context (ServiceContext): Service initialization context
            args: First item will contain the ServiceConfiguration to consider

        """
        configuration = args[0]
        context.blocks = self._get_service_blocks(configuration)

        # perform environment substitution for block properties
        for b in context.blocks:
            b['properties'] = \
                NIOEnvironment.substitute_env_vars(b['properties'])

        context.block_router_type = \
            self._get_block_router_type(configuration)

        # set router settings
        context.router_settings = {
            "clone_signals":
                Settings.getboolean("service", "clone_signals",
                                    fallback=True),
            "check_signal_type":
                Settings.getboolean("service", "check_signal_type",
                                    fallback=True),
            "max_workers":
                Settings.getint("service", "thread_pool_max_workers",
                                fallback=50),
            "diagnostics":
                Settings.getboolean("service", "router_diagnostics",
                                    fallback=True),
            "diagnostic_interval":
                Settings.getint("service", "router_diagnostic_interval",
                                fallback=3600),
        }

    def _get_service_blocks(self, configuration):
        """ Find out list of blocks and their properties
        given a service configuration

        Arguments:
            configuration (Configuration): service configuration

        Returns:
            List of blocks with the format:
                {type, properties}

        """

        # resulting list
        blocks = []

        # temporary dictionary containing block templates with format
        # {block_name: block_template}
        templates = {}

        # get list of all service execution blocks
        ids = configuration.get_execution_ids()

        for id in ids:
            # determine whether id belongs to a mapping or a 'source' block
            source_id = configuration.get_source_block(id)
            if source_id == id:
                # not a mapping, dealing with source block
                # get template and add to blocks
                templates[source_id] = \
                    self._block_manager.fetch_block_template(source_id)
                blocks.append(templates[source_id])
            else:
                # is corresponding template already cached?
                if source_id in templates:
                    template = templates[source_id]
                else:
                    # retrieve template
                    template = \
                        self._block_manager.fetch_block_template(source_id)
                    # save template for eventual future look-up
                    templates[source_id] = template

                # copy template and override id thus making it a block
                # on its own for execution purposes.
                mapped_block = copy.deepcopy(template)
                mapped_block["properties"]["id"] = id
                blocks.append(mapped_block)

        return blocks

    def _get_block_router_type(self, configuration):
        """Get the type of block router to use for given service.

        This method will give preference to a service specification,
        then it will go through the global nio service setting detecting
        and discovering the router to use. If no router is set, it
        will use the default block router (BlockRouter).

        Arguments:
            configuration (Configuration): service configuration

        Returns:
            Block router type
        """

        # does the service configuration specifies a block router to use?
        if hasattr(configuration.data, "block_router") \
                and configuration.data.block_router is not None:
            # use service specification
            router = configuration.data.block_router
        else:
            # grab it from nio level
            router = Settings.get("service", "block_router", fallback=None)

        router_type = None
        if router:
            # is router namespace in the cache?
            if router in self._block_router_types:
                router_type = self._block_router_types[router]
            else:
                # attempt to get router class from namespace
                try:
                    from niocore.util.class_reflection import get_class

                    router_type = get_class(router)
                    # update cache
                    self._block_router_types[router] = router_type
                except:
                    self.logger.warning(
                        "Specified block router: {0} is not valid".format(
                            router))

        if not router_type:
            # set default router
            from nio.router.thread_pool_executor \
                import ThreadedPoolExecutorRouter
            router_type = ThreadedPoolExecutorRouter

        return router_type
