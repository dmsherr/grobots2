"""

   Core Service Init Context

"""
from enum import Enum

from nio.service.context import ServiceContext


class RequestPoint(Enum):
    """ Specifies different points one can execute requests when
    launching a service, see 'requests' member within CoreServiceContext
    for usage.
    """
    before_configure = 1
    after_configure = 2
    before_start = 3
    after_start = 4
    before_stop = 5


class CoreServiceContext(object):

    def __init__(
            self,
            service_type,
            properties,
            ipc_class,
            service_pipe,
            core_pipe,
            blocks=None,
            block_router_type=None,
            modules=None,
            root='',
            router_settings=None,
            mgmt_signal_handler=None,
            logging_config=None,
            ipc_request_time_to_live=2,
            requests=None,
            stop_service_timeout=None,
            check_parent_timeout=None,
            blocks_async_configure=True,
            blocks_async_start=False,
            blocks_async_stop=True,
            instance_id=None):
        """ Initializes information needed for a Service

        Arguments:
            service_type (class type): service class type
            properties (dict): service metadata
            ipc_class: class to instantiate for InterProcessCommunications
            service_pipe (python pipe): service pipe for ipc communication
            core_pipe (python pipe): core pipe for ipc communication
            blocks (list): list of blocks, each with the format:
                {"type": block class,
                 "properties": block metadata}
            block_router_type: block router class to use
            modules (dict): module to initialize with the format
                {module: module_context}
            root (str): path to working directory (project root)
            router_settings (dict): router settings, these can include
                "clone_signals" and/or any other settings depending on router
                being used
            mgmt_signal_handler (method): method to use to publish
                management signals, receives signals as only parameter
            logging_config (dict): A dictionary to configure the service
                process's logging module with
            ipc_request_time_to_live (float): time an IPC request remains valid
                before a timeout is issued
            stop_service_timeout (float): maximum time a service stop is
                allowed to execute before continuing stop procedures
            check_parent_timeout (float): specifies if service checks for parent 
                termination and how often, if None no check is performed
            requests : list of requests to execute when launching a service,
                list elements are tuples with format:
                (RequestPoint, ExecutableRequest)
            blocks_async_configure: If True, blocks configure asynchronously
            blocks_async_start: If True, blocks start asynchronously
            blocks_async_stop: If True, blocks stop asynchronously
            instance_id: Instance this service belongs to

        """
        self.service_type = service_type
        self.properties = properties
        self.ipc_class = ipc_class
        self.service_pipe = service_pipe
        self.core_pipe = core_pipe
        self.blocks = blocks or []
        self.block_router_type = block_router_type
        self.modules = modules or {}
        self.root = root
        self.router_settings = router_settings or {}
        self.mgmt_signal_handler = mgmt_signal_handler
        self.logging_config = logging_config if logging_config is not None \
            else {}
        self.ipc_request_time_to_live = ipc_request_time_to_live
        self.stop_service_timeout = stop_service_timeout
        self.check_parent_timeout = check_parent_timeout
        self.requests = requests or []
        self.blocks_async_configure = blocks_async_configure
        self.blocks_async_start = blocks_async_start
        self.blocks_async_stop = blocks_async_stop
        self.instance_id = instance_id

        # data core components write to
        self.component_data = {}

        # sdk context data, this data is extracted from this context data
        # see get_sdk_context
        self._sdk_context = None

    def get_sdk_context(self):
        """ Retrieves a service context as expected by the sdk

        Returns: nio-sdk Service Context

        """
        return ServiceContext(self.properties,
                              blocks=self.blocks,
                              block_router_type=self.block_router_type,
                              router_settings=self.router_settings,
                              mgmt_signal_handler=self.mgmt_signal_handler,
                              blocks_async_configure=self.blocks_async_configure,
                              blocks_async_start=self.blocks_async_start,
                              blocks_async_stop=self.blocks_async_stop,
                              instance_id=self.instance_id)
