class ServiceInfo(object):
    """Maintains Service information in the main process"""

    def __init__(self, id, name, status, logger):
        self._id = id
        self._name = name
        self._status = status
        self.logger = logger
        self._process = None

    @property
    def status(self):
        return self._status

    @property
    def process(self):
        return self._process

    @process.setter
    def process(self, process):
        self._process = process

    @property
    def id(self):
        return self._id

    @property
    def name(self):
        return self._name
