from .launcher import ServiceLauncher


def service_create(context):
    """ Create service as a process functionality

    This is the code first run when a service process
    is created.

    Args:
        context (ServiceContext):  context to grab initialization
            parameters from

    Returns:
        None

    """

    service_launcher = ServiceLauncher(context)
    service_launcher.configure()
