"""

   Service API commands

"""
from niocore.core.api.command import CommandResource
from nio.modules.security.access import ensure_access
from niocore.modules.security.access import compose_resource


class ServiceCommandResource(CommandResource):
    """ Command Resource used to expose a Command in a Service

    Executes the method on_service_command in the executor passed

    """

    # Defines service's commands with protected access
    _protected_commands = ['start', 'stop']

    def __init__(self, target, service_id, executor):
        """ Initializes a service block command resource

        Args:
            target (Command): target command
            service_id (str): service identifier
            executor (instance): Service Manager instance
        """
        super().__init__(target.id, target)
        self._service_id = service_id
        self._executor = executor

    def get_command(self):
        return self.id

    def execute(self, args):
        """ Executes a command on a service

        Args:
            args (dict /object): args to pass to the command being executed

        """
        if self.get_command() in self._protected_commands:
            # Ensure "execute" access for specific service command
            ensure_access(compose_resource("services", self._service_id),
                          "execute")

        return self._executor.on_service_command(self._service_id,
                                                 self.get_command(),
                                                 args)


class ServiceBlockCommandResource(ServiceCommandResource):
    """ Command Resource used to expose a Block Command in a Service

    Executes the method on_service_command in the executor passed

    """

    def __init__(self, target, service_id, block_id, executor):
        """ Initializes a service block command resource

        Args:
            target (Command): target command
            service_id (str): service id
            block_id (str): block id
            executor (instance): Service Manager instance
        """
        super().__init__(target, service_id, executor)
        self._block_id = block_id
        self._command = "{0}/{1}".format(block_id, self.id)

    def get_command(self):
        return self._command

    def execute(self, args):
        """ Executes a command on a block

        Args:
            args (dict /object): args to pass to the command being executed

        """
        # Ensure block "execute" access for command
        ensure_access(compose_resource("blocks", self._block_id), "execute")
        return self._executor.on_service_command(self._service_id,
                                                 self.get_command(),
                                                 args)
