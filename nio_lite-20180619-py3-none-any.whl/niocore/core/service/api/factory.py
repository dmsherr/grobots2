"""

  Service Resource Factory

"""
from niocore.core.api.collections.factory import ResourceCommandFactory
from niocore.core.api.collections.typed import ResourceTypedFactory
from niocore.core.service.api.command import ServiceCommandResource, \
    ServiceBlockCommandResource
from niocore.core.service.api.resource import ServiceConfigurationResource


class ServiceCommandFactory(ResourceCommandFactory):

    """ Command Factory for creating commands in a Service

    """

    def __init__(self, id, executor):
        """ Constructor for Factory

        Args:
            id (str): Service's id owning this factory
            executor: Object to be used by the commands for executing methods
        """
        super().__init__()
        self._id = id
        self._executor = executor

    def create(self, command):
        return ServiceCommandResource(command, self._id, self._executor)

    @property
    def executor(self):
        return self._executor


class ServiceBlockCommandFactory(ResourceCommandFactory):

    """ Command Factory for creating commands in a block within a service

    """

    def __init__(self, service_id, block_id, executor):
        """ Constructor for Factory

        Args:
            service_id (str): Service's id owning this factory
            block_id (str): Block's id
            executor: Object to be used by the commands for executing methods
        """
        super().__init__()
        self._service_id = service_id
        self._block_id = block_id
        self._executor = executor

    def create(self, command):
        return ServiceBlockCommandResource(command,
                                           self._service_id,
                                           self._block_id,
                                           self._executor)


class ServiceResourceFactory(ResourceTypedFactory):

    """Factory to create Service Resources

    """

    def __init__(self, executor, block_instances):
        """ Constructor for Service factory

        Args:
            executor: Object to be used by the commands for executing methods
            block_instances: Reference to block definitions within the
                system, used to look up block definitions for blocks within
                the service such as:
        """
        super().__init__(ServiceConfigurationResource)
        self._executor = executor
        self._block_instances = block_instances

    def create(self, item):
        """ Creates a Service Resource

        Args:
            item (TypedConfiguration): item containing metadata and
            Resource type

        Returns:
            Newly Service resource created

        """
        # Create Factory for command for this Resource
        id = item.config.id
        factory = ServiceCommandFactory(id, self._executor)
        return self._type(id, item, factory, self._block_instances)
