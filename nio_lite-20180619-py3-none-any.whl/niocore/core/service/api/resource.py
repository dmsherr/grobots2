"""

  Service API resources

"""
from nio.service.base import Service
from niocore.core.api.collections.typed import ResourceTypedCollection

from niocore.core.api.configuration import TypedConfigurationResource
from niocore.util.find import find


class ServiceBlockResource(TypedConfigurationResource):
    def __init__(self, block_id, target, service_factory):
        super().__init__(block_id, target, service_factory)

    @property
    def properties(self):
        """ Returns runtime properties

        Execute Service command "properties" when block instance is running
        and properties are requested.

        """
        command = find(lambda c: c.id == 'properties', self.commands)
        if not command:
            return super().properties
        return command.execute(None)  # Properties has not parameter

    def matches(self, identifier):
        return identifier in [self.id, self.properties.get('name')]


class ServiceConfigurationResource(TypedConfigurationResource):
    def __init__(self, service_id, target, service_factory, block_instances):
        """ Service Configuration Resource

        Wraps a Service item to expose it through the API

        Populates the resource's children list looking up blocks
            within the service and accessing their configuration
            using the block instances, this list is accessed from
            rest when addressing a block within a service (service/block)

        """
        super().__init__(service_id, target, service_factory)
        self._include_pid = False

        # populate resource children list with a service block resource
        # for each execution-block in the service
        block_ids = self._target_config.get_execution_ids()
        for block_id in block_ids:
            # knowing execution id, get access to source (if different)
            # and validate that it still exists
            source_block = self._target_config.get_source_block(block_id)
            # check if item still exists
            item = block_instances.fetch(source_block)
            if item is None:
                # This block must have been deleted from the instance
                # we don't need to register it as a child then
                continue

            # have a special factory, one that can save both service and
            # block ids
            from niocore.core.service.api.factory import \
                ServiceBlockCommandFactory

            factory = ServiceBlockCommandFactory(service_id,
                                                 block_id,
                                                 service_factory.executor)
            resource = ServiceBlockResource(block_id,
                                            item.target,
                                            factory)
            self._children.append(resource)

    @property
    def properties(self):
        """Extend the service properties with the status of the service"""
        old_props = super().properties

        # Find the service_status command, retrieve runtime status, and add it
        # to service properties
        command = find(lambda c: c.id == 'status', self.commands)
        # no arguments to request status, command already contains all
        # that is needed to execute
        status = command.execute({}) if command else {}

        # Update excepted (added) properties
        for _type, exceptions in ResourceTypedCollection.property_exceptions:
            if issubclass(_type, Service):
                for property_to_add in exceptions:
                    # so far all excepted properties come from 'status' so
                    # assume they all are in 'status' and set unknown otherwise
                    old_props[property_to_add] = \
                        status.get(property_to_add, "Unknown")

        if not self._include_pid and "pid" in old_props:
            del old_props["pid"]

        return old_props

    def apply_url_params(self, **kwargs):
        """ Allow item to filter itself out or set a 'state' based on
        conditions

        Kwargs:
            url parameters

        Return:
            True if item determines to filter itself out
        """

        # parse url conditions and determine 'pid' inclusion
        self._include_pid = False
        if "include_pids" in kwargs and \
                kwargs["include_pids"].lower() == 'true':
            self._include_pid = True

        # no objections to include itself in results
        return True
