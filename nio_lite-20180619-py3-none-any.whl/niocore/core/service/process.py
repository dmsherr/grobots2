import multiprocessing
from threading import Event, RLock
from time import sleep, monotonic

from nio.util.flags_enum import FlagsEnum
from nio.util.logging import get_nio_logger
from nio.util.runner import RunnerStatus
from nio.util.threading import spawn
from niocore.common.ipc import IPCMessage
from niocore.common.ipc.command.request import IPCRequestCommand
from niocore.common.ipc.response import IPCResponseStatus
from niocore.common.service.message.status import StatusMessage
from niocore.common.service.message.stop import StopMessage
from niocore.core.ipc.native.core import IPCCore
from niocore.core.ipc.native.receiver import IPCReceiver
from niocore.core.service.info import ServiceInfo
from niocore.core.service.util import service_create
from niocore.util.events import wait_for_events
from niocore.util.hooks import Hooks


class InvalidContext(Exception):
    """ Exception raised when trying to start a service and
    the context is invalid
    """
    pass


class ConfigureFailure(Exception):
    """ Exception raised when a service fails to start
    """
    pass


class ConfigureTimeout(Exception):
    """ Exception raised when a service doesn't configure on time
    """
    pass


class StartFailure(Exception):
    """ Exception raised when a service fails to configure
    """
    pass


class RequestTimeout(Exception):
    """ Exception raised when executing a request and the response
     exceeds waiting time specified
    """
    pass


class RequestError(Exception):
    """ Exception raised when executing a request and an error is received
    in the response
    """
    pass


class ServiceProcess(object):
    """Launches a service and serves as it's handler
    """

    # Maximum time to give a service to launch and configure
    CONFIGURE_TIMEOUT = 60

    # Interval at which to check if service is fully configured
    # this setting allows not to wait for configure timeout to expire in case
    # of failure by monitoring service at this defined interval
    CONFIGURE_CHECK_INTERVAL = 1

    # Maximum time to give a service to start
    START_TIMEOUT = 10

    # Maximum time to give a service to stop
    STOP_TIMEOUT = 10

    # Partitioning of time interval to wait while checking for service
    # to stop by itself
    STOP_CHECK_INTERVAL = 1

    hook_points = ['service_status_change']

    class ServiceStatusTimeout(Exception):

        """ Exception raised when a status notification is expected from
         service and it is not received
        """
        pass

    class ServiceStatusError(Exception):

        """ Exception raised when a status notification is expected and an
        error is received instead
        """
        pass

    def __init__(self, service_init_context, service_pipe, core_pipe,
                 id, name="", stop_request_callback=None):
        self.logger = get_nio_logger("{0}.{1}".format(
            self.__class__.__name__, name or id))
        self._service_init_context = service_init_context
        self._service_pipe = service_pipe
        self._core_pipe = core_pipe
        self._stop_request_callback = stop_request_callback

        self._status_lock = RLock()
        self._ipc_core = None
        self._service_status_events = {
            RunnerStatus.configured: Event(),
            RunnerStatus.started: Event(),
            RunnerStatus.error: Event(),
        }
        self._hooks = Hooks(ServiceProcess.hook_points)

        status = \
            FlagsEnum(RunnerStatus,
                      status_change_callback=self._on_status_change_callback)
        self._service_info = \
            ServiceInfo(id,
                        name,
                        status,
                        self.logger)
        status.set(RunnerStatus.created)

    @property
    def hooks(self):
        return self._hooks

    @property
    def service_info(self):
        return self._service_info

    def start(self):
        """Starts a service by launching it as a child process.

        Raises:
            InvalidContext: if context contains invalid settings
            ConfigureFailure: if service fails to configure
            StartFailure: if service fails to start
        """

        if self._service_init_context is None:
            raise InvalidContext(
                "Failed to start service, context is not set")
        if self._service_pipe is None:
            raise InvalidContext(
                "Failed to start, service pipe is not set")  # pragma: no cover
        if self._core_pipe is None:
            raise InvalidContext(
                "Failed to start, core pipe is not set")  # pragma: no cover

        self.logger.info("Starting service process")
        # launch process
        self.status.set(RunnerStatus.configuring)
        self._launch_process()

        # start core communication handler
        self._ipc_core = IPCCore(self._service_init_context.service_pipe,
                                 self._service_init_context.core_pipe,
                                 self._ipc_default_handler)
        self._ipc_core.start()

        # initiate a thread to detect a process start failure case when
        # Service class code is not even reached by multiprocessing module
        stop_monitoring_event = Event()
        spawn(self._monitor_process_configure,
              stop_monitoring_event,
              self._service_status_events[RunnerStatus.error])

        # wait for service configured notification
        try:
            self._wait_for_status_notification(
                RunnerStatus.configured,
                ServiceProcess.CONFIGURE_TIMEOUT)
        except ServiceProcess.ServiceStatusError:
            raise ConfigureFailure()
        except ServiceProcess.ServiceStatusTimeout:
            raise ConfigureTimeout()
        finally:
            self._stop_process_configure_monitoring(stop_monitoring_event)

        # send start command
        self.send_async(IPCMessage(IPCRequestCommand("start", None)))

        # wait for service started notification
        try:
            self._wait_for_status_notification(
                RunnerStatus.started,
                ServiceProcess.START_TIMEOUT)
        except ServiceProcess.ServiceStatusError:
            raise StartFailure()
        except ServiceProcess.ServiceStatusTimeout:
            # allow service start timeout to go unnoticed
            pass

    def _wait_for_status_notification(self, status, max_wait_time):
        status_event = self._service_status_events[status]
        error_event = self._service_status_events[RunnerStatus.error]
        # make sure both events are 'clear'
        status_event.clear()
        error_event.clear()

        # wait for either event to be set (they are set in _ipc_default_handler
        # as a response to the service sending the status asynchronously
        if wait_for_events(max_wait_time,
                           status_event, error_event):
            if error_event.is_set():
                raise ServiceProcess.ServiceStatusError()
            # a non-error status was received
            return

        timeout_msg = \
            "Status:'{0}' was not received on time for Service: '{1}'".\
            format(status.name, self.service_info.id)
        self.logger.warning(timeout_msg)
        raise ServiceProcess.ServiceStatusTimeout(timeout_msg)

    def _stop_service(self):
        """ Stops associated service by sending the stop command

        After sending command, service then is monitored, if it does not
        terminate within allowed timeout, the process is terminated through
        a 'terminate' call
        """

        self.logger.debug("Sending stop command")
        self.send_async(IPCMessage(IPCRequestCommand("stop", None)))

        terminate_time = monotonic() + ServiceProcess.STOP_TIMEOUT
        # allow process to stop by itself, otherwise terminate it.
        while self.service_info.process.is_alive():
            # has waiting time elapsed?
            if monotonic() > terminate_time:
                self.logger.warning(
                    "Service: '{0}' failed to terminate on time".
                    format(self.service_info.id))
                self.service_info.process.terminate()
                break
            sleep(ServiceProcess.STOP_CHECK_INTERVAL)

    def stop(self):
        """ Stops the service."""
        self.logger.info("Stopping service process")
        # stop associated service
        self.status.set(RunnerStatus.stopping)
        try:
            self._stop_service()
        except Exception:  # pragma: no cover
            # log and continue, service is being stopped
            self.logger.exception(
                "Error while stopping service")  # pragma: no cover

        # stop ipc communication handler
        if self._ipc_core:
            try:
                self._ipc_core.stop()
            except Exception:  # pragma: no cover
                # log and continue, comms are being stopped
                self.logger.exception(
                    "Error while stopping ipc comm.")  # pragma: no cover
            self._ipc_core = None

        self.status.set(RunnerStatus.stopped)

    @property
    def status(self):
        with self._status_lock:
            return self.service_info.status

    def _on_status_change_callback(self, old_status, new_status):
        self.logger.debug("Status changed from: {0} to: {1}".format(
            old_status.name, new_status.name))
        self.hooks.run('service_status_change', self, old_status, new_status)

    @property
    def pid(self):
        if self.service_info.process:
            return self.service_info.process.pid
        return 'unknown'

    @property
    def parent_pid(self):
        if self.service_info.process:
            return self.service_info.process._parent_pid
        return 'unknown'

    def _launch_process(self):
        """ Launches service as a process using multiprocessing module

        The process is set to be daemon.

        Returns:
            None

        """
        self.service_info.process = multiprocessing.Process(
            target=service_create, args=(self._service_init_context, ))

        # if parent dies, subprocess dies also
        self.service_info.process.daemon = True
        self.service_info.process.start()

    def send(self, message, callback=None):
        if self._ipc_core:
            try:
                self._ipc_core.send(message, callback)
            except BrokenPipeError:
                self.logger.error(
                    "Communication with Service: '{0}' is broken".
                    format(self.service_info.id))
                raise

    def send_async(self, message):
        if self._ipc_core:
            try:
                self._ipc_core.send_async(message)
            except BrokenPipeError:
                self.logger.error(
                    "Communication with Service: {0} is broken".
                    format(self.service_info.id))
                raise

    def _ipc_default_handler(self, message):
        """ Here we receive all async messages from the service, as well as,
        responses to messages that were sent for which a callback was not
        specified thus acting like a default callback handler.
        """
        self.logger.debug("Received ipc service message: {0}".format(message))

        if isinstance(message.body, StatusMessage):
            # save status, just copy the status flags over
            self.status.flags = message.body.status.flags
            # notify if requested
            for status in self._service_status_events:
                if self.status.is_set(status):
                    self.logger.debug("setting event")
                    self._service_status_events[status].set()
        elif isinstance(message.body, StopMessage):
            # request a service stop by id
            if self._stop_request_callback:
                self._stop_request_callback(message.body.id)
            else:
                self.logger.warning("Received stop service message and"
                                    "stop callback is not set")
        else:
            self.logger.warning("Invalid Message: {0}".format(message))

    def is_alive(self):
        receiver = IPCReceiver()
        self.send(IPCMessage(IPCRequestCommand("heartbeat", {})),
                  receiver.receive)

        response = receiver.wait(IPCMessage.TIME_TO_LIVE)

        if response:
            return response.status == IPCResponseStatus.ok

        return False  # pragma: no cover

    def execute_request(self, request, wait_time=None):

        receiver = IPCReceiver()
        self.send(IPCMessage(request), receiver.receive)

        # wait for response on "send" request
        response = receiver.wait(wait_time or IPCMessage.TIME_TO_LIVE)

        if not response:
            # response was not received on time
            timeout_msg = \
                "In Service: '{0}', no response received for request: {1}".\
                format(self.service_info.id, request)
            self.logger.warning(timeout_msg)
            raise RequestTimeout(timeout_msg)

        if response.status == IPCResponseStatus.error:
            error_msg = \
                "Error executing: {0} on Service: '{1}', details: {2}".\
                format(request, self.service_info.id, response.description)
            self.logger.warning(error_msg)
            # if an exception came from the service, raise it
            if response.exception is not None:
                raise response.exception
            raise RequestError(error_msg)
        else:
            return response.result

    def _monitor_process_configure(self, stop_monitoring_event, not_alive_event):
        """ Monitors a process during its configuration

        Monitors process alive status and sets an event when process
        is determined to be dead.

        Args:
            stop_monitoring_event: used to receive stop monitoring
                notification
            not_alive_event: Event to trigger when a process is detected
                to be dead
        """

        # make sure our own notification flag is cleared
        not_alive_event.clear()
        while True:
            # check if process is alive
            if not self.service_info.process.is_alive():
                self._notify_process_failure(not_alive_event)
                self.logger.info("Service: '{0}' is not alive".format(
                    self.service_info.id))
                break
            # check if monitoring should stop
            elif stop_monitoring_event.is_set():
                self.logger.info("Service/Process-start monitoring stopped")
                break
            # keep monitoring
            sleep(ServiceProcess.CONFIGURE_CHECK_INTERVAL)
        self.logger.debug("Process configure monitoring has ended")

    def _notify_process_failure(self, not_alive_event):
        not_alive_event.set()

    @staticmethod
    def _stop_process_configure_monitoring(stop_monitoring_event):
        stop_monitoring_event.set()
