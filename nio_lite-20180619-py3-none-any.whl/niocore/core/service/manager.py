"""
  NIO Service Manager class

"""
import multiprocessing
from threading import RLock

from nio.modules.settings import Settings
from nio.types.bool import BoolType
from nio.util.runner import RunnerStatus
from nio.util.threading import spawn
from niocore.common.executable_request import ExecutableRequest
from niocore.common.ipc import IPCMessage
from niocore.common.ipc.command.request import IPCRequestCommand
from niocore.configuration import CfgType
from niocore.configuration.service import ServiceConfiguration
from niocore.core.hooks import CoreHooks
from niocore.core.ipc.native.service import IPCService
from niocore.core.service.api.factory import ServiceResourceFactory
from niocore.core.service.discoverable_collection import \
    ServicesDiscoverableCollection
from niocore.core.service.process import ConfigureFailure, ConfigureTimeout, \
    StartFailure
from niocore.core.service.process import ServiceProcess
from niocore.core.typed import TypedManager
from niocore.util.class_reflection import get_class_namespace
from niocore.util.environment import NIOEnvironment
from niocore.util.exceptions import MultipleChoices
from niocore.util.logging import get_logging_settings


class InvalidServiceState(ValueError):
    pass


class ServiceManager(TypedManager):

    """ Service Manager core component

    Handles all service startup and shutdown operations


    """

    _name = "ServiceManager"

    def __init__(self):
        # Set myself up as a typed manager for services
        super().__init__("services")
        self._processes = {}
        self._processes_lock = RLock()
        self._service_modules = []
        self._block_router_type = None
        self._block_manager = None
        self._builders = None
        # allow to define a lock per command
        self._command_locks = {"start": RLock()}
        self._blocks_async_configure = None
        self._blocks_async_start = None
        self._blocks_async_stop = None
        self._service_stop_timeout = None
        self._service_check_parent_timeout = None

    def _get_resource_typed_factory(self):
        return ServiceResourceFactory(self, None)

    def _get_discoverable_collection(self):
        return ServicesDiscoverableCollection()

    def get_service_status(self, service_id):
        """Returns the status of a service by id

        Args:
            service_id (str): The service identifier

        Returns:
            status (str): The status of the service or "stopped" if the
                service cannot be found in the process list
        """
        process = self.get_process(service_id)
        status = process.status.name if process \
            else RunnerStatus.stopped.name

        return status

    def on_service_command(self, service_id, command, args):
        """ Receives and executes a service command originating
        from REST API

        Args:
            service_id (str): Service command is targeted to
            command (str): Command to sent, when command is
                directed to a block it will be of the format: 'block/command'
            args (dict{name: value}): the arguments to the command method

        Raises:
            ServiceAlreadyStarted: Starting a service that is started
            ServiceAlreadyStarting: Starting a service that is starting
            InvalidService: Commanding on a service that is not started
        """
        self.logger.debug("Executing command {0} on service {1}".
                          format(command, service_id))

        if command in self._command_locks:
            self.logger.debug("Acquiring lock, command: {0}".format(command))
            self._command_locks[command].acquire()
        try:
            # handle start separately
            if command == "start":
                process = self.get_process(service_id)
                if process:
                    # first consider a process that may be in error, and
                    # allow it to restart.
                    if process.status.is_set(RunnerStatus.error):
                        # allow it to restart if it is in error mode
                        # attempt to stop process first
                        try:
                            self._stop_service(service_id, True)
                        except Exception:
                            self.logger.debug("Stopping a service")
                    # make sure it is not started already
                    elif process.status.is_set(RunnerStatus.started):
                        raise InvalidServiceState(
                            "Service: {0} is already started".format(
                                service_id))
                    elif process.status.is_set(RunnerStatus.starting):
                        raise InvalidServiceState(
                            "Service: {0} is already starting".format(
                                service_id))

                # look for service properties and start it
                for item in self.instance_properties:
                    if item.config.id == service_id:
                        self._start_service(item.config, True)
                        # respond with full service status
                        return self.on_service_command(service_id, "status", {})

            # status is also a special case
            # we request real time service status including all block status
            elif command == "status":
                # Assume stopped at first
                status = self.get_service_status(service_id)
                process = self.get_process(service_id)
                pid = process.pid if process else "unknown"
                parent_pid = process.parent_pid if process else "unknown"
                full_status = {"service": status}
                # Get full service status if there still a process
                if process and status not in [RunnerStatus.stopped.name,
                                              RunnerStatus.stopping.name]:
                    try:
                        request = IPCRequestCommand(command, args)
                        full_status = self.execute_request(service_id,
                                                           request)
                        # override status with general-like status
                        # coming from service
                        if "service_and_blocks" in full_status:
                            status = full_status["service_and_blocks"]
                            del full_status["service_and_blocks"]
                    except BrokenPipeError:
                        full_status = None
                        if status != RunnerStatus.error.name:
                            # this will not happen when optional Service
                            # Monitor component is running, but verify anyways

                            # service not running and status was not error
                            self.logger.warning(
                                "Service '{0}' was detected to be no longer "
                                "running, setting status to error".
                                format(service_id))
                            status = RunnerStatus.error.name

                return dict(status=status,  # to keep compatibility
                            pid=pid,
                            parent_pid=parent_pid,
                            full_status=full_status)

            # The stop command won't actually go to the service either
            elif command == "stop":
                self._stop_service(service_id, True)
                return dict(status=RunnerStatus.stopped.name)

            # It is some other command, let's send it to the process.
            else:
                request = IPCRequestCommand(command, args)
                return self.execute_request(service_id, request)
        finally:
            if command in self._command_locks:
                self.logger.debug("Releasing lock, command: {0}".
                                  format(command))
                self._command_locks[command].release()

    def configure(self, context):
        """ Configure Service Manager

        Retrieves Block Manager from the init context.

        Args:
            context (CoreContext): core component initialization context
                containing list of core components installed

        Raises:
            InvalidContext: error if Block Manager not present

        """
        super().configure(context)

        # save locally which modules need to be initialized for a service
        self._service_modules = context.initialized_modules

        self._block_manager = self.get_dependency('BlockManager')

        # overwrite default resource factory
        self._override_factory()

        # set any settings concerning processes which service manager
        # is responsible for launching
        IPCMessage.TIME_TO_LIVE = \
            Settings.getfloat("service",
                              "ipc_request_time_to_live", fallback=2.0)

        ServiceProcess.CONFIGURE_TIMEOUT = \
            Settings.getfloat("service",
                              "configure_timeout", fallback=60.0)

        ServiceProcess.CONFIGURE_CHECK_INTERVAL = \
            Settings.getfloat("service",
                              "configure_check_interval", fallback=1.0)

        ServiceProcess.START_TIMEOUT = \
            Settings.getfloat("service",
                              "start_timeout", fallback=10.0)

        ServiceProcess.STOP_TIMEOUT = \
            Settings.getfloat("service",
                              "stop_timeout", fallback=10.0)

        ServiceProcess.STOP_CHECK_INTERVAL = \
            Settings.getfloat("service",
                              "stop_check_interval", fallback=1.0)

        self._blocks_async_configure = \
            Settings.getboolean("service",
                                "blocks_async_configure", fallback=True)

        self._blocks_async_start = \
            Settings.getboolean("service",
                                "blocks_async_start", fallback=False)

        self._blocks_async_stop = \
            Settings.getboolean("service",
                                "blocks_async_stop", fallback=True)

        self._service_stop_timeout = \
            Settings.getfloat("service",
                              "service_stop_timeout", fallback=5.0)

        check_parent_timeout = \
            Settings.getfloat("service", "check_parent_timeout", fallback=0)
        # any positive number remains as the timeout otherwise set it to None
        self._service_check_parent_timeout = check_parent_timeout \
            if check_parent_timeout > 0 else None

    def get_configuration_type(self):
        return CfgType.service

    def get_type_configuration_class(self):
        """ Specify configuration type for collection elements
        (see TypedManager)
        """
        return ServiceConfiguration

    def _override_factory(self):
        """ Set the factory for creating block resources using the
        instances retrieved by the Block Manager
        """
        factory = ServiceResourceFactory(self,
                                         self._block_manager.instances)
        self.instances.set_factory(factory)

    def start(self):
        """ Executes the starting process

        Retrieves configuration for all services available.
        Start services configured for "auto start" and launch those services

        """
        # go through list of services and start those with auto_start = true
        super().start()

        # determine whether to start services async or sync
        # read 'async_start' entry under 'service' entry from niocore.conf
        async_start = Settings.getboolean("service", "async_start",
                                          fallback=True)

        for item in self.instance_properties:
            # perform 'auto_start' substitution now. We will use the
            # substituted variable to check if we should auto start the
            # service.
            # We will have to substitute env vars for whole configuration later
            # when building the context, but here we just do it / care for
            # auto_start to allow auto_start to be set by an env var.
            auto_start = \
                NIOEnvironment.replace_setting(item.config.data.auto_start)
            try:
                auto_start = BoolType.deserialize(auto_start)
                if item.type is not None and auto_start:
                    self._start_service(item.config, not async_start)
            except AttributeError:
                self.logger.warning(
                    "Service '{0}' is missing auto_start, using False".
                    format(item.config.id))
            except Exception:
                self.logger.exception(
                    "Service %s failed to start" % item.config.id)

    @property
    def services(self):
        """ Exposes defined services

        Returns:
             {service_id: service_name} dictionary
        """
        return {item.config.data.id: item.config.data.name
                for item in self.instance_properties}

    def identify_service(self, service):
        """ Identifies a service

        Args:
            service (str): Service name or id

        Returns:
             service id

        Raises:
            MultipleChoices if service name cannot be uniquely identified
            ValueError if service is invalid
        """
        services = self.services
        if service in services:
            return service
        found = [id for id, name in services.items() if name == service]
        # handle multiple choices
        found_count = len(found)
        if found_count == 1:
            return found[0]
        elif found_count > 1:
            raise MultipleChoices(found)
        raise ValueError("Service: '{}' is invalid".format(service))

    def _get_builders(self):
        """Returns list of context builders available"""

        if self._builders is None:
            from niocore.core.service.builder.block import BlockBuilder

            self._builders = [BlockBuilder(self._block_manager)]
        return self._builders

    def _on_service_status_change(self, service_process,
                                  old_status, new_status):
        self.logger.debug('Service status change: {0}, status: {1}'.
                          format(service_process.service_info.id,
                                 new_status))
        CoreHooks.run('service_status_change', service_process,
                      old_status, new_status)

    def _start_service(self, configuration, synchronous=False):
        """ Private method for handling the service starting process

        Prepares the service init context by collecting all data needed for
        a service to start.
        Launches the service in a new process

        """
        service_pipe, core_pipe = multiprocessing.Pipe()
        # prepare context
        context = self._prepare_service_context(configuration,
                                                service_pipe,
                                                core_pipe)

        # make sure block namespace as a string is what gets serialized before
        # launching process thus avoiding pickling errors
        # at the other end, block namespace is converted back to block type
        for block_definition in context.blocks:
            block_definition['type'] = \
                get_class_namespace(block_definition['type'])

        # create Service process
        process = ServiceProcess(context, service_pipe, core_pipe,
                                 configuration.id,
                                 configuration.data.get("name", ""),
                                 self._stop_service)
        process.hooks.attach('service_status_change',
                             self._on_service_status_change)

        # keep a reference to process
        with self._processes_lock:
            self._processes[configuration.id] = process

        # If an error during 'start' happens, the process is stopped
        if synchronous:
            self._start_process(process)
        else:
            spawn(self._start_process, process)

    def _start_process(self, process):
        try:
            process.start()
        except (ConfigureFailure, ConfigureTimeout) as e:
            self.logger.exception("Service {0} failed to configure".
                                  format(process.service_info.id))
            self._stop_service(process.service_info.id, True)
            raise e
        except StartFailure as e:
            self.logger.exception("Service {0} failed to start".
                                  format(process.service_info.id))
            self._stop_service(process.service_info.id, True)
            raise e
        except Exception as e:
            self.logger.exception("Error starting service {0}".
                                  format(process.service_info.id))
            self._stop_service(process.service_info.id, True)
            raise e

        self.logger.info("Service: {0} with process identifier(pid): {1} "
                         "has started".format(process.service_info.id,
                                              process.pid))

    def _stop_service(self, service_id, synchronous=False):
        """ Stops a service and removes reference to it.

        If service is not found, simply ignore request

        Args:
            service_id (str): service to stop

        """
        self.logger.info('Stopping service: {0}'.format(service_id))

        process = None
        with self._processes_lock:
            if service_id in self._processes:
                # remove service registration
                process = self._processes.pop(service_id)

        # to be safe, make sure 'stop' execution is outside of 'lock'
        if process:
            # Stopping a stopped service is a safe operation
            if synchronous:
                process.stop()
            else:
                spawn(process.stop)

    def _prepare_service_context(self, configuration, service_pipe, core_pipe):
        config_type = 'Service'
        service_id = \
            configuration.id if hasattr(configuration, "id") else "Unknown"
        try:
            config_type = configuration.data.type
            # Validate Types is in list of types
        except AttributeError:
            self.logger.warn("Service: '{0}' has no type defined!".
                             format(service_id))

        from niocore.core.service.context import CoreServiceContext

        NIOEnvironment.reload_env()

        properties = NIOEnvironment.substitute_env_vars(configuration.data)

        context = CoreServiceContext(
            self._get_class(config_type),
            properties,
            IPCService,
            service_pipe,
            core_pipe,
            root=NIOEnvironment.get_root(),
            logging_config=get_logging_settings(),
            ipc_request_time_to_live=IPCMessage.TIME_TO_LIVE,
            blocks_async_configure=self._blocks_async_configure,
            blocks_async_start=self._blocks_async_start,
            blocks_async_stop=self._blocks_async_stop,
            stop_service_timeout=self._service_stop_timeout,
            check_parent_timeout=self._service_check_parent_timeout,
            instance_id=NIOEnvironment.get_variable("INSTANCE_ID", None)
        )

        # get list of builders for building service context
        for builder in self._get_builders():
            builder.prepare_context(context, configuration)

        # Go through components preparing context
        for component in self._context.components.values():
            try:
                component.prepare_context(context)
            except Exception:
                self.logger.exception("Failed to prepare context for "
                                      "'Service': {0}".format(service_id))

        # Pass initialized core modules and just prepared service contexts
        # to the service process
        service_context = context.get_sdk_context()
        context.modules = \
            {module: module.prepare_service_context(service_context)
             for module in self._service_modules}

        return context

    def stop(self):
        """ Executes the stopping process

        Go through all services started and stops them
        """
        # make a separate list so that _stop_service does not
        # interfere with the iteration
        with self._processes_lock:
            service_ids = list(self._processes.keys())
        for service_id in service_ids:
            # stop service synchronously to guarantee it stops before
            # 'main' (parent) process, otherwise, there is no guarantee of a
            # full synchronized resource cleanup(i.e., publishers, broker, etc)
            self._stop_service(service_id, True)
        super().stop()

    def get_process(self, service_id):
        """ Provides controlled access to a service process

        Go through all services started and stops them
        """
        with self._processes_lock:
            return self._processes.get(service_id)

    def execute_request(self, service_id, request):
        """ Executes a request on a service

        Args:
            service_id (str): Service identifier
            request (ExecutableRequest/IPCRequestCommand): request to execute

        Raises:
            RuntimeError: if service is not running
        """

        process = self.get_process(service_id)
        if not process:
            msg = "Could not have access to service: '{0}', verify that " \
                  "service is actually running".format(service_id)
            self.logger.error(msg)
            raise ValueError(msg)

        if not (isinstance(request, ExecutableRequest) or
                isinstance(request, IPCRequestCommand)):
            raise TypeError("'request' type is invalid")

        return process.execute_request(request)
