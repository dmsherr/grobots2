import os
import signal
from threading import Event

from nio.modules.initializer import ModuleInitializer
from nio.util.logging import get_nio_logger
from nio.util.runner import RunnerStatus
from nio.util.threading import spawn
from niocore.common.ipc import IPCMessage
from niocore.common.service.ipc_handler import IPCHandler
from niocore.common.service.message.status import StatusMessage
from niocore.common.service.message.stop import StopMessage
from niocore.core.service.context import RequestPoint
from niocore.util.class_reflection import get_class
from niocore.util.environment import NIOEnvironment
from niocore.util.logging import configure as configure_logging
from niocore.util.service_label import get_service_label


class ServiceLauncher(ModuleInitializer):

    """ An object that wraps the Service object and handles the core side.

    This object will live (at almost the highest level) in the service process
    """

    # Timeout while checking for 'stop_event' signal and parent process 'status'
    STOP_EVENT_TIMEOUT = 0.1

    def __init__(self, context):
        """ Initializes the ServiceLauncher instance

        Args:
            context (ServiceContext):  context to grab initialization
                parameters from

        Returns:
            None

        Raises:
            None

        """

        super().__init__()
        self._context = context
        configure_logging(
            logging_conf=context.logging_config,
            service_name=get_service_label(context.properties.get('name', ""),
                                           context.properties.get('id'))
        )
        self._service = None
        self._ipc_handler = None
        self._stop_event = Event()
        self._stopping_event = Event()
        self._exit_event = Event()
        self.logger = get_nio_logger('ServiceLauncher')

        # save requests per execution point
        self._requests = {}
        for point in RequestPoint:
            self._requests[point] = \
                [request for (request_point, request) in context.requests
                 if request_point == point]

    def configure(self):
        """ Configures the service,

        This is the code that runs first when a service process
        is created.

        This is a blocking call, and it delegates the blocking behavior on the
        service it instantiates.

        If an exception is caught, it will log the exception and let the
        process die.
        """
        try:
            # Adding Ctrl Handler for Windows to allow proper closing of the
            # service by a stop command of the nio core
            # http://msdn.microsoft.com/en-us/library/windows/
            #       desktop/ms682541(v=vs.85).aspx
            self.logger.debug("Console OS is " + os.name)
            if os.name == 'nt':
                try:
                    import win32api

                    self.logger.info("Setting Console Ctrl Handler")
                    win32api.SetConsoleCtrlHandler(self._close_console, True)
                except ImportError:
                    self.logger.warning("pywin32 not installed for Python")

            # Services need to ignore Ctrl+C signals from console and
            # wait for core to stop service through proper channels
            signal.signal(signal.SIGINT, signal.SIG_IGN)

            # handle SIGTERM by shutting down the service 
            signal.signal(signal.SIGTERM, self._shutdown_service)

            self.logger.debug("creating service instance")
            # create service instance
            self._service = \
                self._context.service_type(self._on_status_change_callback)
            self._configure_service(self._context)
            self.logger.debug("blocking")
            self._block(self._context.check_parent_timeout)
            self._exit_event.set()

        except (KeyboardInterrupt, SystemExit):
            self.logger.warning("Service abnormal termination")
        except:
            self.logger.warning("Service ended unexpectedly", exc_info=True)

    def get_context(self, module):
        """ Provides initializer with the prepared-service context for given
        module

        Args:
            module (module instance)

        Returns:
            service's module context
        """
        return self._context.modules[module]

    def _configure_service(self, context):
        """ Prepare and configure the service instance """
        if context.root:
            NIOEnvironment.set_environment(context.root, [])

        for module_obj in context.modules.keys():
            self.register_module(module_obj)

        # Init Modules with service flag on
        self.initialize()

        # set ipc request timeout on the Service process
        IPCMessage.TIME_TO_LIVE = context.ipc_request_time_to_live

        # Set up the IPC handler before configuring blocks, that way if there
        # is an error during configuration, we can notify the core
        self.logger.info(
            "Setting up IPC Handler with {}".format(context.ipc_class))
        self._ipc_handler = IPCHandler(context.ipc_class, self)
        self._ipc_handler.configure(context)
        self._ipc_handler.start()

        for request in self._requests[RequestPoint.before_configure]:
            request.execute()

        # access service context
        service_context = context.get_sdk_context()

        # make sure class type is what makes it to the service before
        # configuring it
        self._transform_block_namespaces_to_class_types(service_context)

        self._service.do_configure(service_context)

        for request in self._requests[RequestPoint.after_configure]:
            request.execute()

    @staticmethod
    def _transform_block_namespaces_to_class_types(context):
        """ Transforms block types from namespaces to actual block types

        A transformation is needed since when a service is launched its context
        is serialized, and the block types need to be expressed as a namespace
        to avoid serialization errors, however, service expects these types
        as actual block types.

        Args:
            context (ServiceContext): Service context where blocks are defined
        """
        for block_definition in context.blocks:
            # when receiving type as a string, interpret it as a namespace
            # and convert it to actual class type
            if isinstance(block_definition['type'], str):
                block_definition['type'] = get_class(block_definition['type'])

    def _start_service(self):
        for request in self._requests[RequestPoint.before_start]:
            request.execute()

        self._service.do_start()

        for request in self._requests[RequestPoint.after_start]:
            request.execute()

    def _stop_service(self):
        # make stop call async making sure it does not take longer than
        # given timeout
        stop_thread = spawn(self._service.do_stop)
        try:
            stop_thread.join(self._context.stop_service_timeout)
            if stop_thread.is_alive():
                self.logger.warning("Service did not stop on time")
        except:
            self.logger.warning("Exception stopping service", exc_info=True)

        for request in self._requests[RequestPoint.before_stop]:
            request.execute()

        # stop ipc handler
        if self._ipc_handler:
            self._ipc_handler.stop()
            self._ipc_handler = None

        try:
            self.finalize()
        except:
            self.logger.warning("While finalizing", exc_info=True)

        # stop blocking method
        self._stop_event.set()

    def _block(self, check_parent_timeout):
        """ Blocks the service.
        
        Blocking behavior is needed so that after a service is started, 
        the process doesn't end.

        Blocking occurs until service is stopped or parent process (nio core)  
        is terminated, when parent process is somehow abruptly terminated it 
        is desirable to stop service thus avoiding dangling processes/services

        Args:
            check_parent_timeout: Specifies how often to check for
                parent termination, if None no check is performed

        Returns:
            None
        """
        if not check_parent_timeout:
            self.logger.info('Check parent for termination is disabled')
        else:
            self.logger.info('Checking for parent for termination every: {} '
                             'seconds'.format(check_parent_timeout))

        # wait for stop event to unblock as long as parent is alive
        while not self._stop_event.wait(check_parent_timeout):
            # get parent process id
            ppid = os.getppid()
            # having a parent process id == 1 means the parent process
            # has terminated since parent process has become now "init"
            if ppid == 1:
                self.logger.info('nio main is terminated, stopping service')
                self._stop_service()
                # leave blocking
                break

        # This change in status creates an error trying to use the log
        # when the logging module was already finalized
        self.logger.info('Leaving block method')

    def _on_status_change_callback(self, old_status, new_status):

        if new_status == RunnerStatus.stopping:
            self._stopping_event.set()

        self.logger.info("Status changed from: {} to: {}".
                         format(old_status.name, new_status.name))
        # notify status change to core
        if self._ipc_handler:
            self._ipc_handler.send_async(
                IPCMessage(StatusMessage(self._service.status)))

    def _shutdown_service(self, *args, **kwargs):

        # make sure event is reset
        self._stopping_event.clear()

        if self._ipc_handler:
            # tell core that this service is being shutdown
            self._ipc_handler.send_async(
                IPCMessage(StopMessage(self._service.id())))

        # wait a maximum of 1 second before stopping by itself
        # in case core is not around or doesn't act.
        if not self._stopping_event.wait(1):
            self.logger.warning(
                "Communications with core are broken, stopping by itself")
            self._stop_service()
            # make sure service/process exits to avoid further execution from
            # running threads, which will throw confusing exceptions anyways
            # since service has stopped (modules have been finalized, etc)
            exit(1)
        else:
            self.logger.info("Core requested a service stop")

    def _close_console(self, signal_type):
        self.logger.info(
            "Console signal received with signal: " +
            str(signal_type))
        # Closing should be done by nio core.
        self.logger.info("Waiting for normal exit")
        self._exit_event.wait()
        return True
