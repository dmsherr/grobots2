"""
  NIO Core Component interface

"""
from nio.util.logging import get_nio_logger
from nio.util.runner import Runner


class MissingComponent(Exception):
    """Exception raised when a component is missing"""
    pass


class CoreComponent(Runner):
    """ Base core component class.

    Contains base properties and functionality common to all components

    """
    _name = "Unknown"
    # have a default somewhere in the "middle"
    default_order = 100
    default_version = "0.1.0"

    def __init__(self):
        self.logger = get_nio_logger(self._name)
        super().__init__(status_change_callback=self._on_status_change_callback)

        self._context = None

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, name):
        self._name = name

    def _on_status_change_callback(self, old_status, new_status):
        self.logger.info("Component: {0} status changed from: {1} to: {2}".
                         format(self.name, old_status.name, new_status.name))

    def prepare_context(self, context):
        """ Method executed when preparing an init context

        Components can override this method to provide specific information
        through the service init context

        Args:
            context (ServiceContext): service initialization context

        """
        pass

    def configure(self, context):
        """Configure method to override when subclassing component"""
        self._context = context

    def get_dependency(self, name, optional=False):
        """ Retrieves a core dependency

        Retrieves a core dependency by name and throws an exception
        if component is not available

        Args:
            name (str): Dependency's name
            optional (bool): Raise error if not dependency found

        Returns:
            Dependency component

        Raises:
            InvalidContext if component is not available
        """
        # Our reference to the core context will be set on configure
        if self._context is None:
            raise RuntimeError("Component has not been configured")

        dep = self._context.get_component(name)
        if dep is None and not optional:
            raise MissingComponent("Missing Component : %s" % name)
        return dep

    def get_order(self):
        return CoreComponent.default_order

    def get_version(self):
        """ Provides current component version

        A specific component wishing to provide their own version
        will override this method

        Returns:
            component version as string
        """
        return CoreComponent.default_version

    def get_details(self):
        """ Provides component details

        Actual component implementations may override this method and
        decide what details/properties they would like to expose.
        It is encouraged to call parent method and 'update' the result
        with own details

        """
        return {"version": self.get_version()}
