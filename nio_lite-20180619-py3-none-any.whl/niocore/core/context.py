"""

  Classes related to initialization contexts

"""
from niocore.core.api.system import SystemInfo
from niocore.core.hooks import CoreHooks


class ContextBuilder(object):

    """ Base class to inherit for participating in the process of building
        any type of initialization context (ServiceContext)

    """

    def prepare_context(self, context, *args):
        """ Method executed when preparing an init context

        Components can override this method to provide specific information
        trough the service init context

        Args:
            context (ServiceContext): service initialization context
            args: additional variable arguments as required

        """
        pass


class InvalidContext(Exception):

    """Exception raised when a context is not valid"""
    pass


class CoreContext(object):

    """ Core Component Initialization Context

        This context is pass to all core components when they are being
        initialized.
        Contains among other things the list of all components discovered
        in the system so every core component have a way to know about others.

        Components can specify a loop guard object for replacing the standard
        loop that blocks the process from exiting
    """

    def __init__(self, components, initialized_modules):
        """ Create the initialization context with a list of core components

        Args:
            components: List of core components available
            initialized_modules (list): contains a list of discovered modules
                with the format (module_name, module_class)

        Raises:
            InvalidContext
        """

        self.components = {}
        self.loop_guard = None
        self._system = SystemInfo()
        try:
            for component in components:
                self.components[component.name] = component
        except Exception as err:
            raise InvalidContext(err)

        for module in initialized_modules:
            self._system.register_module(module)

        # service module initialization related info.
        self.initialized_modules = initialized_modules

    @property
    def system(self):
        return self._system

    def shutdown_instance(self):
        CoreHooks.run('exit')

    def get_component_names(self):
        """Returns list of component names"""
        return list(self.components.keys())

    def get_component(self, name):
        """Returns a component based on component's name

        Args:
            name: Name of component to retrieve
        """
        return self.components.get(name)
