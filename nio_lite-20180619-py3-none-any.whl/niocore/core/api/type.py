"""

    Type Resource represents a type (i.e. block type, service type)

"""
from niocore.core.api.resource import Resource
from niocore.util.class_reflection import get_class_namespace
from nio.properties.holder import PropertyHolder


class TypeResource(Resource):

    """ Type Resource

    Wraps a type class to expose it through the API
    """

    def __init__(self, id, target):
        super().__init__(id, target)

    @property
    def id(self):
        """Returns the class (_target) id as the resource name"""
        return self._target.__name__

    @property
    def properties(self):
        """ Returns the properties of the target (Configuration) dict

        """
        prop_dict = {
            'name': self.id,
            'namespace': get_class_namespace(self._target)
        }
        # Get the description of the type if it has properties/commands
        if issubclass(self._target, PropertyHolder):
            prop_dict.update(self._target.get_description())

        return prop_dict
