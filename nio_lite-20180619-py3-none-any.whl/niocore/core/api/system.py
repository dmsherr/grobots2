"""

    System Info

"""
from nio import __version__ as nio_version
from niocore import __binary_build__ as binary_build
from niocore import __binary_name__ as binary_name
from collections import defaultdict
from niocore.core.api.resource import Resource
from niocore.util.environment import NIOEnvironment


class SystemInfo(Resource):

    """ System Info Resource

    This class is sued in the core to expose system properties through the API
    layer.

    """

    def __init__(self):
        super().__init__('system')

        self.properties['nio'] = {
            "version": nio_version,
            "build": binary_build,
            "binary": binary_name,
            "instance_id": NIOEnvironment.get_variable("INSTANCE_ID")
        }
        self.properties['components'] = defaultdict(dict)
        self.properties['modules'] = defaultdict(dict)

    def register_component(self, component):
        """ Register a component within the System Information.

        Args:
            component (component): The component instance being registered
        """
        self.properties['components'][component.name] = component.get_details()

    def register_module(self, module):
        """ Register a module within the System Information.

        Args:
            module (Module): The module to register. This will
                be an instance to the actual module implementation
        """
        self.properties['modules'][module.get_module_type()] = {
            module.__class__.__name__: module.get_details()
        }
