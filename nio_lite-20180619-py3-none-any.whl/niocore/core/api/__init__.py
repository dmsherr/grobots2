"""

    Common API definitions

"""
