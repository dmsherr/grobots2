"""

    API Resource

"""


class Resource(object):

    """ API Resource

    Resource that can be manipulated using NIO API

    A resource exposes a group of properties, commands and children for API
    consumers

    """

    def __init__(self, id, target=None):
        self._id = id
        self._target = target
        self._children = []
        self._properties = {}
        self._commands = []

    def apply_url_params(self, **kwargs):
        """ Allow item to filter itself out or set a 'state' based on
        conditions

        Kwargs:
            url parameters

        Return:
            True if item determines to filter itself out
        """
        return True

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, id):
        self._id = id

    @property
    def properties(self):
        return self._properties

    @property
    def commands(self):
        return self._commands

    @property
    def children(self):
        return self._children

    @property
    def target(self):
        return self._target

    def matches(self, identifier):
        """ Overrideable method to test resource against given identifier

        Args:
            identifier: identifier to test against
        Returns:
            True if resource can be identified using given identifier
        """
        return identifier == self.id
