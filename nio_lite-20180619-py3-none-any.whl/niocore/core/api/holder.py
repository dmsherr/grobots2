"""

    Property Holder Resource

"""
from niocore.core.api.resource import Resource


class PropertyHolderResource(Resource):
    """ Resource for handling Property Holder types

    Returns the description of the properties for a PropertyHolder Type

    """
    def __init__(self, id, target):
        super().__init__(id, target)
        self._properties = target.get_description()


class PropertyCommandHolderResource(Resource):
    """ Resource for handling Property Holder types

    Returns the description of the properties for a PropertyHolder Type

    """
    def __init__(self, id, target):
        super().__init__(id, target)
        description = target.get_description()
        self._properties = description['properties']
        self._commands = description['commands']
