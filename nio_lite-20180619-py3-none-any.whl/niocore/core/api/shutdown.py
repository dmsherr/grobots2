"""

  Shutdown Command

"""
from nio.command import Command
from niocore.core.api.command import CommandResource
from nio.modules.security.access import ensure_access


class ShutDownCommand(CommandResource):

    def __init__(self, shutdown):
        super().__init__('shutdown', Command('shutdown'))
        self._shutdown_func = shutdown

    def execute(self, args):

        # Ensure "execute" access for instance, i.e., user can shutdown
        ensure_access("instance", "execute")

        return self._do_shutdown()  # pragma: no cover

    def _do_shutdown(self):
        self._shutdown_func()
        return "Shutdown complete"
