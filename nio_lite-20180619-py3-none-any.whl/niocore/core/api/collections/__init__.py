"""
  Typed Configuration class

"""


class TypedConfiguration(object):

    """ Class containing a Configuration which can provide a Type

        Type is retrieve through a method provided
    """

    def __init__(self, config, type_retrieval_fn):
        """ Initializes a TypeConfiguration

        Args:
            config (Configuration): Configuration provided
            type_retrieval_fn (method): Method that provides a type based on
              the Configuration

        """
        # TODO: enforce types
        # if config is None or not isinstance(config, Configuration):
        #     raise TypeError("invalid config type")
        self._config = config
        self._type_retrieval_fn = type_retrieval_fn

    @property
    def config(self):
        return self._config

    @property
    def type(self):
        return self._type_retrieval_fn(self._config)
