"""

    API Collection

"""
from threading import RLock

from nio.util.ensure_types import ensure_is
from nio.util.logging import get_nio_logger
from niocore.core.api.collections.factory import ResourceFactory, \
    ResourceCommandFactory
from niocore.core.api.resource import Resource


class ResourceCollection(Resource):

    """ Generic Resource Collection

    Generic API for exposing a collection of similar resource types

    """

    def __init__(self, id,
                 target=None,
                 factory=ResourceFactory(),
                 command_factory=ResourceCommandFactory()):
        """ Constructor of a Resource Collection


        Args:
            id (str): Collection id
            target (list or dict): items to be exposed in the collection, when
                not provided, _get_target is called
            factory (ResourceFactory): Resource factory
            command_factory (ResourceCommandFactory): Resource command factory
        """
        super().__init__(id, target)
        self.logger = get_nio_logger(self.__class__.__name__)

        self.factory = factory
        self.command_factory = command_factory
        # Allow to provide target after constructor when target is not specified
        if self._target is None:
            self._target = self._get_target()
        self._target_lock = RLock()
        ensure_is(self._target, [list, dict], TypeError, msg='target')

        for res in self._target:
            # It is a command holder ?
            if hasattr(res, "get_commands"):
                # Create Command Resources
                for command in res.get_commands().values():
                    self._commands.append(
                        self._create_command_resource(command))

    def _get_target(self):
        """ Overridable method providing collection target types

        Returns:
            Collection target as a list

        """
        return list()

    def create(self, config):
        pass  # pragma: no cover

    def add(self, resource):
        pass  # pragma: no cover

    def modify(self, resource, update):
        pass  # pragma: no cover

    def delete(self, resource):
        pass  # pragma: no cover

    def fetch(self, id):
        pass  # pragma: no cover

    def fetch_all(self):
        """ Fetch all items

        Retrieve all items (Resources) in the collection

        """
        with self._target_lock:
            items = self._target
            if isinstance(self._target, dict):
                items = list(self._target.values())
            resources = []
            for item in items:
                try:
                    # make sure 'read' access to individual item is granted
                    if self.item_permission_granted(item, "read"):
                        rsrc = self._create_resource_item(item)
                        resources.append(rsrc)
                except TypeError:
                    self.logger.exception("Creating resource")

            return resources

    def set_factory(self, factory):
        """ Allows to overwrite factory used to create resources in
        the collection

        Args:
            factory (instance): New factory
        """
        self.factory = factory

    def _create_resource_item(self, item):
        """ Creates a Resource based on a collection item

        Args:
            item: the object to have the ResourceFactory create from
        """
        return self.factory.create(item)

    def _create_command_resource(self, command):
        """ Private method for creating command resources

        """
        return self.command_factory.create(command)

    def item_permission_granted(self, item, permission):
        """ Finds out if permission is granted for given item

        Note: This method is intended to be overriden

        Args:
            item: item in question
            permission (str): read|write|execute
        """
        return True
