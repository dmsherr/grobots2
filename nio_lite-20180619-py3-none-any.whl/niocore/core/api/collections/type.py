"""

    Resource Type Collection

"""
from inspect import isclass

from nio.util.discovery import is_class_discoverable
from niocore.core.api.collections.factory import ResourceFactory
from niocore.core.api.collections.resource import ResourceCollection
from nio.modules.security.access import ensure_access, has_access
from niocore.core.api.type import TypeResource
from niocore.core.loader.discover import Discover
from niocore.core.loader.loader import Loader
from niocore.modules.security.access import compose_resource
from niocore.util.environment import NIOEnvironment
from niocore.util.find import find


class ResourceDiscoverableTypeCollection(ResourceCollection):

    """ Resource collection for handling a list of types

    The collection's _target will be a list of class objects

    """

    def __init__(self, id):
        """ Constructor for type collection

        Args:
            id (str): Collection's id
        """

        # target is provided through _get_target
        super().__init__(id, factory=self._get_resource_factory())

    def _get_target(self):
        return self._retrieve_types()

    def get_type(self, class_type):
        """ Returns a class based on a string type

        Validates the class is  part of the list of types managed

        Arguments:
            class_type (str): entity's type

        Returns:
            Class type if exists

        """
        return find(lambda _type: _type.__name__ == class_type,
                    self.types)

    def _retrieve_types(self):
        """ Retrieve list of types

        Go through list of paths and retrieves types on those
        paths

        Returns:
            List of types

        """
        types = []
        for namespace in self._get_type_namespaces():
            self.logger.debug("Looking in {0}".format(namespace))
            types.extend(Discover.discover_classes(
                namespace, self._get_discoverable_base(),
                discovery_criteria=self._get_discovery_criteria,
                exclude_patterns=self._get_module_exclusions()))
        self.logger.info("{} types found, {}".format(
            len(types), [_type.__name__ for _type in types]))
        return types

    @property
    def types(self):
        """List of types available"""
        return self._target

    def fetch(self, class_name):
        """ Get a class resource based on a name

        Args:
            class_name (str): The name of the class to fetch

        Returns:
            TypeResource: A type resource for the discovered class. None if
                the class cannot be found in the collection
        """

        # Ensure "read" access to class details
        ensure_access(compose_resource(self._get_resource_id(), class_name),
                      "read")

        found_class = self._find_class_by_name(self.types, class_name)

        if found_class:
            return self._create_resource_item(found_class)

        return None

    def _find_class_by_name(self, classes, class_name):
        """Search through a list of classes to find the one with a name"""
        return find(lambda c: c.__name__ == class_name, classes)

    def create(self, config):
        """ Create the class resource based on a configuration

        To create a resource in this instance means to discover the class
        with the specified name, and return the corresponding resource for it.

        Args:
            config (AttributeDict): configuration of the class to create.
                Currently, this only needs to contain a name

        Returns:
            TypeResource: The resource for the newly created class

        Raises:
            Exception: If the class could not be discovered.
        """

        # Ensure "write" access to create new class resources
        ensure_access(self._get_resource_id(), "write")

        new_cls = self._find_class_by_name(self._retrieve_types(), config.id)

        if new_cls is None:
            raise ValueError("No class found with name %s" % config.id)

        return self._create_resource_item(new_cls)

    def add(self, cls_resource):
        """Add a class resource to our collection

        Args:
            cls_resource (TypeResource): The resource to add. This most likely
                is the output of create.

        Returns:
            dict: The properties of the added class, to be outputted if needed
        """

        # Ensure "write" access to add new class resources
        ensure_access(self._get_resource_id(), "write")

        self._target.append(cls_resource.target)
        return cls_resource.properties

    def modify(self, cls_resource, config):
        """ Modify just means update the class resource """

        # Ensure "write" access to modify class resource
        ensure_access(
            compose_resource(self._get_resource_id(), cls_resource.id),
            "write")

        updated_resource_target, _ = Loader.reload_class(cls_resource.target)

        if updated_resource_target:

            # replace requested type with newly obtained type
            for i, item in enumerate(self._target):
                if item == cls_resource.target:
                    self._target[i] = updated_resource_target
                    break

            # create new resource based on "updated" type
            new_resource = self._create_resource_item(updated_resource_target)
            return new_resource.properties

        raise Exception("Class name %s could not be loaded" %
                        cls_resource.id)

    def delete(self, cls_resource):
        """ We do not support deleting a type at this time. """
        raise NotImplementedError("Cannot delete a type")

    def fetch_all(self):
        """ Retrieves all resources

        Access to each individual item is ensured/verified from base method by
        calling the 'item_permission_granted' method
        """
        return super().fetch_all()

    def item_permission_granted(self, item, permission):
        """ Finds out if permission is granted for given item

        Args:
            item: item in question
            permission (str): read|write|execute
        """
        # figures out item's name similar to how ResourceFactory does it
        name = item.__name__ if isclass(item) else item.id()
        return has_access(compose_resource(self._get_resource_id(), name),
                          permission)

    def update(self):
        """ Updates collection by re-discovering and reloading its types
        """

        # Ensure "write" access to class resources
        ensure_access(self._get_resource_id(), "write")

        self.logger.info("Updating entire: '{0}' collection".format(self.id))

        # re-discover collection types
        self._target = self._retrieve_types()
        for i, item in enumerate(self._target):
            # update/reload each type/class and save it back
            updated_item, _ = Loader.reload_class(item)
            if updated_item:
                self._target[i] = updated_item
            else:
                raise Exception("Class name: {0} could not be reloaded".
                                format(item.__name__))

        return super().fetch_all()

    def _get_type_namespaces(self):
        """ Provides list of namespaces for types used by the Manager

        This method will return the default namespaces specified in the
        constructor as well as the namespaces of any configured paths in
        the environment.

        Returns:
            List of type namespaces
        """

        namespaces = set()
        for rsc_path in NIOEnvironment.get_resource_paths(
                self._get_resource_id(), self._get_default_namespaces()):
            namespaces.add(Loader.load_path(rsc_path))

        return namespaces

    def _get_resource_id(self):
        """ Provides resource id

        Overrideable method providing resource name for given collection
        """
        return self.id

    def _get_discoverable_base(self):
        """ Provides discoverable base type
        """
        return NotImplementedError

    def _get_default_namespaces(self):
        """ Provides default namespace

        When resource path setting is not specified in the configuration,
        the default namespaces specified through this method are used
        during discovery
        """
        return NotImplementedError

    def _get_discovery_criteria(self, obj):
        """ Specifies the discovery criteria

        The discovery criteria is a method that is called from within the
        discovery process to find out if a given type is to be discovered.

        Args:
            obj: class type

        """
        return is_class_discoverable(obj, self._get_default_discoverability())

    def _get_resource_factory(self):
        """ Provides resource factory to use when creating resources
        """
        return ResourceFactory(TypeResource)

    def _get_default_discoverability(self):
        """ Provides default discoverability setting

        Override this method to specify which discoverability a type has
        when it is not decorated using any of the discovery-like decorators
        """
        return NotImplementedError

    def _get_module_exclusions(self):
        """ Provides modules to exclude from discovery

        Override this method to specify which modules should be excluded
        from discovery

        Returns:
            list of patterns to exclude from discovery, accepts '*'
        """
        return NotImplementedError
