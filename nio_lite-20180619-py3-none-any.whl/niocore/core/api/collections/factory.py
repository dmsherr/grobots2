"""

    Resource Factory

"""
from inspect import isclass
from niocore.util.class_reflection import get_class_namespace
from niocore.core.api.command import CommandResource
from niocore.core.api.resource import Resource


class ResourceFactory(object):

    """ Generic Resource Factory

    """

    def __init__(self, res_type=Resource):
        """ Factory for creating Resources

        Args:
            res_type (type): type for creating new Resources
        """
        self._type = res_type
        # Validate Resource Type is a Resource
        if not issubclass(self._type, Resource):
            raise TypeError("res_type")

    def create(self, item):
        """ Creates a Resource based on a resource type

        """

        is_class = isclass(item)
        id = get_class_namespace(item) if is_class else item.id()
        return self._type(id, item)

    def validate(self, *args, **kwargs):
        """ Validates a resource.

        This method can be overriden to provide targeted resource validation,
        users of this method must expect an exception when validation fails

        Examples of potential exceptions are:
            AllowNoneViolation: Property value does not allow none
            TypeError: Property value is invalid
        """
        pass


class ResourceCommandFactory(ResourceFactory):

    """ Generic Resource Command Factory

    """

    def __init__(self, command_type=CommandResource):
        """ Factory for creating Command Resources

        Args:
            command_type (type): type for creating new Resources
        """
        super().__init__(command_type)
        # Validate Resource Type is a CommandResource
        if not issubclass(self._type, CommandResource):
            raise TypeError("command_type")

    def create(self, command):
        """ Creates a CommandResource based on a command type

        """
        return self._type(command.id, command)
