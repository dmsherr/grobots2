"""

    Resource Typed Collection

"""
from uuid import uuid4

from nio.service.base import Service
from nio.util.ensure_types import ensure_list
from nio.util.logging import get_nio_logger
from niocore.core.api.collections import TypedConfiguration
from niocore.core.api.collections.factory import ResourceFactory
from niocore.core.api.collections.resource import ResourceCollection
from niocore.core.api.configuration import TypedConfigurationResource
from nio.modules.security.access import ensure_access, has_access
from niocore.util.exceptions import MultipleChoices
from niocore.modules.security.access import compose_resource
from niocore.util.attribute_dict import AttributeDict, enforce_attr_dict
from niocore.util.find import find


class ResourceTypedFactory(ResourceFactory):

    def __init__(self, res_type=TypedConfigurationResource):
        super().__init__(res_type)

    def create(self, item):
        """ Creates a Resource for a Typed item

        Args:
            item (class,config): instance to return as resource

        Returns:
            Resource instance

        """
        return self._type(item.config.id, item)

    def validate(self, resource_type, properties, logger=None):
        """ Validates incoming properties for given typed resource.

        Args:
            resource_type (type): Resource class type
            properties (dict): Properties to validate against
            logger (python logger): Optional logger

        Raises:
            TypeError: Property value is invalid

        """
        instance = resource_type()
        # populate instance with properties to validate
        instance.from_dict(properties, logger)
        instance.validate(True)


class ResourceTypedCollection(ResourceCollection):
    # maintain information with properties excepted from checking
    # and ultimately removed
    property_exceptions = [(Service, ['status', 'pid'])]

    """ Resource collection for handling TypedManager items

        Navigate through the multiple configuration and creates the list of
        items (class, configuration)

        Allows saving, deleting and creating new items

    """

    def __init__(self, id, configuration, types, factory):
        """ Constructor for a  Resource Typed Collection

        Builds the list of metadata items and their type associated

        Args:
          id (str): Collection's id
          configuration (Configuration): Configuration containing all items /
                    metadata
          types: Collection with all possible types available
          factory (ResourceFactory): Factory used for creating resources

        """
        super().__init__(id, dict(), factory)
        self.logger = get_nio_logger(self.__class__.__name__)
        self._types = types
        self._configuration = configuration
        # Load data based on configuration
        self.refresh(configuration)

    def refresh(self, configuration):
        """ Updates collection data based on a configuration

        Args:
          configuration (Configuration): Configuration containing all items /
                    metadata

        """

        with self._target_lock:
            # Reset collection items
            self._target = dict()
            self.logger.info("Retrieving configurations for {0}".
                             format(self.id))
            for child_id in configuration.get_children():
                try:
                    config = self._retrieve_configuration(configuration,
                                                          child_id)
                    id = config.data.get('id', child_id)
                    self._target[id] = \
                        TypedConfiguration(config, self._get_type_from_config)

                    self.logger.debug("Creating type for configuration %s" %
                                      str(self._target[id].type))
                except TypeError:
                    # log and skip
                    config = configuration.data[child_id]
                    id = config.data.get('id', child_id)
                    _type = config.data.get('type', 'Not specified')
                    self.logger.error(
                        "Ignoring instance: '{0}' with invalid type: '{1}'".
                        format(id, _type))
                    continue

    @property
    def ids(self):
        """List of types available"""
        return list(self._target.keys())

    @property
    def properties(self):
        """List of properties"""
        return list(self._target.values())

    def get_info(self, id):
        """ Returns instance's info based on id

         Args:
            id (str): the instance's id

        Returns:
            TypedConfiguration instance

        """
        return self._target[id]

    def _retrieve_configuration(self, config, id):
        """ Retrieves a configuration for an instance

        In addition to retrieving the child configuration, this method analyzes
        the properties belonging to the configuration by matching them against
        the class properties for the type this configuration represents, any
        properties considered to be invalid are removed from the configuration
        and a warning message is logged.

        Args:
            config (Configuration): Parent configuration
            id (str): Child configuration identifier

        Return:
            child configuration
        """
        configuration = config.data[id]
        conf_properties = configuration.data
        # determine configurable class properties
        try:
            _class = self._get_class(conf_properties["type"])
        except KeyError:
            msg = "Configuration: '{0}' is invalid or missing 'type' field". \
                format(id)
            self.logger.exception(msg)
            raise TypeError(msg)

        properties = _class.get_class_properties()

        # show a warning for properties that are not in the class
        invalid_properties = [key for key in conf_properties.keys()
                              if key not in properties]
        if invalid_properties:
            self.logger.warning(
                "Configuration for type: '{0}', belonging to instance: '{1}' "
                "contains the following invalid properties: {2}".format(
                    conf_properties["type"], id, invalid_properties))
            # remove invalid properties from memory
            for prop in invalid_properties:
                conf_properties.pop(prop)

        return configuration

    def _get_type_from_config(self, config):
        """ returns class type from a configuration

        Args:
            config (Configuration): Configuration for an instance

        Returns:
            type (class): The class object corresponding to the type
        """
        if 'type' in config.data:
            return self._get_class(config.data['type'])
        raise TypeError("'type' field not available in configuration")

    def _get_class(self, class_path):
        """ Returns a class base on a string type

        If the type requested is not found a default type is returned

        Arguments:
            class_path (str): entity's type

        Returns:
            Class type

        Raises:
            RuntimeError: if class does not exists
        """

        the_type = self._types.get_type(class_path)
        if the_type is None:
            msg = "Type: {0} is invalid".format(class_path)
            raise TypeError(msg)
        return the_type

    def create(self, config_data):
        """ Create a new resource based on the specified configuration

        Args:
            config_data (dict): configuration data to use for new resource

        Returns:
            Resource: a newly created resource based on the config

        Raises:
            ValueError: if there is a problem with the configuration data
        """

        # Ensure "write" access to create new resource
        ensure_access(self.id, "write")

        if not isinstance(config_data, dict):
            raise ValueError("Configuration should be a dictionary")

        if "type" not in config_data:
            raise ValueError("Configuration must specify a type")

        # assign 'id' when not provided in the request
        if not ('id' in config_data and config_data['id']):
            config_data["id"] = uuid4().hex

        # create actual configuration from incoming AttributeDict
        resource_configuration = \
            self._create_configuration(config_data["id"], config_data)

        return self._create_resource_item(
            TypedConfiguration(resource_configuration,
                               self._get_type_from_config))

    def add(self, resource):
        """ Add a resource to the collection

        Args:
            resource (TypedConfigurationResource): the resource to add

        Returns:
            AttributeDict: The resulting configuration of the added resource
        """

        # Ensure "write" access to create add resource
        ensure_access(self.id, "write")

        properties = resource._target_config.data
        self._process_incoming_properties(resource.target.type, properties)
        rsc_config = \
            self._get_completed_resource_config(resource,
                                                resource._target_config)

        self._configuration.add(resource.id, rsc_config)
        with self._target_lock:
            self._target[resource.id] = TypedConfiguration(
                rsc_config, self._get_type_from_config)

        # serialize new configuration
        rsc_config.save()

        return rsc_config.data

    def _process_incoming_properties(self, type_in, properties_in,
                                     remove_excepted=True):

        # determine excepted properties based on incoming properties
        excepted_properties = []
        for _type, exceptions in ResourceTypedCollection.property_exceptions:
            if issubclass(type_in, _type):
                excepted_properties.extend(exceptions)

        # properties that are not in the class definitions will produce
        # a logging message, those excepted are removed.
        properties_to_remove = []
        properties = type_in.get_class_properties()
        for key in properties_in.keys():
            if key not in properties:
                if key not in excepted_properties:
                    raise ValueError("Property: {0} is invalid".format(key))
                else:
                    properties_to_remove.append(key)
                    self.logger.info('Attempting to save property: {0}, '
                                     'property ignored'.format(key))

        if properties_to_remove and remove_excepted:
            # remove 'excepted' properties from update
            for _property in properties_to_remove:
                properties_in.pop(_property)

        # make sure incoming properties pass validation if provided
        validate = getattr(self.factory, "validate", None)
        if callable(validate):
            validate(type_in, properties_in, self.logger)

    def modify(self, resource, update):
        """ Modifies an item's saved configuration """

        # Ensure "write" access to modify specific resource
        ensure_access(compose_resource(self.id, resource.id), "write")

        self._process_incoming_properties(resource.target.type, update)

        # Start with the target's original config
        orig_config = self._target[resource.id].config

        # if there is a name change, make sure configuration under old name
        # is removed before saving it using the new name
        if "name" in update and update["name"] != resource.properties["name"]:
            self._configuration.remove(resource.id)

        # Merge in the settings that we want to update with
        orig_config.data.merge(update)

        # Now merge that config in with the defaults. Seemingly, the only
        # way the resulting config would be different from the already merged
        # config would be if new properties exist on the resource that were
        # not previously included in the config. In that case, we want their
        # defaults included.
        # This call will also validate the config and make sure that the new
        # config meets the criteria of the properties
        rsc_config = self._get_completed_resource_config(resource, orig_config)

        # update endpoint
        with self._target_lock:
            self._target[resource.id] = TypedConfiguration(
                rsc_config, self._get_type_from_config)

        # save changes in memory
        self._configuration.add(resource.id, rsc_config)
        # permanent save / serialization
        rsc_config.save()

        return rsc_config.data

    def _get_completed_resource_config(self, resource, configuration):
        """Get a complete and valid set of properties for a resource.

        This will obtain the defaults of the resource type and attempt
        to merge in the specified properties. The resulting configuration
        can be assumed to be complete for the given resource type

        Args:
            resource (TypedConfigurationResource): The resource in which to get
                the properties for
            configuration (Configuration): Properties to attempt to merge
                into the default properties

        Returns:
            Configuration: The completed configuration for the resource type
        """
        # We don't want to create an instance if we don't have to.
        # Let's use the properties on the class and get the defaults for each.
        # Then we can merge in the specified properties

        # The problem is, we need serializable defaults, which come back
        # through a property's get_description method. So we can't rely
        # solely on the get_defaults method
        target_type = resource._target_type
        new_props = enforce_attr_dict(target_type.get_serializable_defaults())

        # Now merge in the specified properties
        new_props.merge(configuration.data)

        # Update our targets and configuration objects, then save
        # make sure original configuration type is kept when creating instance
        new_config = self._create_configuration(resource.id, new_props)

        return new_config

    def delete(self, resource):

        # Ensure "write" access to delete specific resource
        ensure_access(compose_resource(self.id, resource.id), "write")

        if not hasattr(resource, 'id') or resource.id not in self._target:
            raise ValueError("Resource %s is invalid or does not exist" %
                             resource)

        # Remove the resource from our target and the configuration
        with self._target_lock:
            del self._target[resource.id]
            self._configuration.remove(resource.id)

    def fetch(self, id):
        """ Fetches a resource in the collection base

        """

        # Ensure "read" access to specific resource
        ensure_access(compose_resource(self.id, id), "read")

        with self._target_lock:
            items = ensure_list(self._target, lambda x: list(x.values()))
            item_found = find(lambda item: item.config.id == id, items)
            if item_found is None:
                item_found = self._handle_fetch_through_name(items, id)

            if item_found is not None:
                return self._create_resource_item(item_found)
            return None

    @staticmethod
    def _handle_fetch_through_name(items, name):
        """ Fetches item by using the "name" property

        Args:
            name (str): Name to search for

        Returns:
             item if found None otherwise
        Raises:
            MultipleChoices: if multiple names matched
        """
        found = [item for item in items if hasattr(item.config.data, "name")
                 and item.config.data.name == name]
        # handle multiple choices
        found_count = len(found)
        if found_count == 1:
            return found[0]
        elif found_count > 1:
            ids = [item.config.data.id for item in found]
            raise MultipleChoices(ids)

    def fetch_all(self):
        """ Retrieves all resources

        Adds protection to base method
        """
        return super().fetch_all()

    def item_permission_granted(self, item, permission):
        """ Finds out if permission is granted for given item

        Args:
            item: item in question
            permission (str): read|write|execute
        """
        return has_access(compose_resource(self.id, item.config.id),
                          permission)

    @property
    def configuration(self):
        return self._configuration

    def _create_configuration(self, id, data):
        """ Creates a new instance of configuration managed by this collection

        Assumes all instances will contain same configuration type

        Args:
            id: Configuration id
            data: Configuration data

        Returns:
            Configuration instance
        """
        return type(self._configuration)(
            id=id,
            collection=self.id,
            fetch_on_create=False,
            data=data,
            substitute=False)
