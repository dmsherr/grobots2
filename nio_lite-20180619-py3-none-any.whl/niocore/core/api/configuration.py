"""

    Configuration/metadata Resource

"""
from niocore.core.api.collections import TypedConfiguration
from niocore.core.api.collections.factory import ResourceCommandFactory
from niocore.core.api.resource import Resource


class ConfigurationResource(Resource):

    """ Configuration Resource

    Wraps a Configuration item to expose it through the API
    """

    def __init__(self, id, target):
        super().__init__(id, target)

    @property
    def properties(self):
        """ Returns the properties of the target (Configuration) dict

        """
        # TODO Either create a util to prepare a serialized version
        # of the config or change Configuration not to inherit from AttribDict
        new_dict = {key: self._target[key] for key in self._target
                    if not key.startswith('_')}
        return new_dict


class TypedConfigurationResource(Resource):

    """ Typed Configuration Resource

    Wraps a Typed Configuration item to expose it through the API

    Aside from the configuration related for an item, a type is also provided
    so validations can be executed of the properties

    """

    def __init__(self, id, target, command_factory=ResourceCommandFactory()):
        """ Constructor

        Args:
            target (type, config): pair including a configuration and a type
        """
        super().__init__(id, target)

        if not isinstance(target, TypedConfiguration):
            raise TypeError("Invalid type for resource")
        self._target_type = target.type
        self._target_config = target.config
        self._command_factory = command_factory
        # Create Command Resources
        for command in self._target_type.get_commands().values():
            self._commands.append(self._create_command_resource(command))

    @property
    def properties(self):
        """ Returns the properties of the target (Configuration) dict

        """
        return self._target_config.data.get_attributes()

    def _create_command_resource(self, command):
        """ Private method for creating command resources

        """
        return self._command_factory.create(command)
