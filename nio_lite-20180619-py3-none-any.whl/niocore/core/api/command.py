"""

    API Command

"""
from nio.command import Command
from niocore.core.api.resource import Resource


class CommandResource(Resource):

    """ Command Resource for executing commands


    """

    def __init__(self, id, target):
        super().__init__(id, target)
        # Validate Target is a command
        if not issubclass(target.__class__, Command):
            raise TypeError("target")
        self._properties = target.get_description()

    def execute(self, args):
        pass
