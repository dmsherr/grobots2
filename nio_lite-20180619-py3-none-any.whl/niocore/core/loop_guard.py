"""
    Loop Guard, block and unblock process loop
"""
import time


class LoopGuard(object):

    """ Provides block and unblock methods for stopping a process for exiting.
    """

    exit_flag = False

    def block(self, **kwargs):
        """ blocking method, loops until flag is set """
        interval = kwargs['interval'] if 'interval' in kwargs else 0.05

        while not self.exit_flag:
            time.sleep(interval)

    def unblock(self):
        """ Unblocking method, signal to break the loop """
        self.exit_flag = True
