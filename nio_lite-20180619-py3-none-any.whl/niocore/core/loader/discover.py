import inspect
from fnmatch import fnmatchcase
from importlib import import_module
from pkgutil import walk_packages
from zipimport import zipimporter

from nio.util.discovery import is_class_discoverable
from nio.util.logging import get_nio_logger


class Discover(object):

    @classmethod
    def discover_classes(cls, namespace, base_class,
                         discovery_criteria=is_class_discoverable,
                         exclude_patterns=()):
        """Discover classes marked discoverable that extend a class

        Given a namespace and a base_class, each class in the namespace
        and all sub-namespaces is inspected to see if the discoverable type
        decorator is on the class and the class is a subclass of the base_class

        Args:
            namespace (str): A string containing the root namespace to search
                for classes in. All namespaces under this namespace will be
                searched as well
            base_class (class): A class that all classes will be checked
                against to see if they are subclasses
            discovery_criteria (callable): a callable receiving as argument
                a class type, callable returns True when class is considered
                discoverable
            exclude_patterns (list): Sequence of module names to exclude;
                '*' can be used as a wildcard in the names.

        Returns:
            list: list of classes in the namespace that are discoverable

        Raises:
            None
        """
        out_classes = list()

        # Given a list of patterns, provide a callable that will be true only
        # if the input matches one of the patterns.
        exclude_callable = lambda name: \
            any(fnmatchcase(name, pattern) for pattern in exclude_patterns)

        for discovered_module in cls._walk_namespace(namespace,
                                                     exclude_callable):
            new_classes = cls._get_classes_from_module(
                discovered_module, base_class, discovery_criteria)

            # find out if any of the new classes is duplicated by name
            # and discard class in such case
            out_names = [c.__name__ for c in out_classes]
            duplicated_classes = [c for c in new_classes
                                  if c.__name__ in out_names]
            for c in duplicated_classes:
                get_nio_logger("Discover").warning(
                    "Discovered multiple classes with name {}, discarding "
                    "class defined in: {}".format(c.__name__, c.__module__)
                )
                new_classes.remove(c)

            out_classes.extend(new_classes)

        return out_classes

    @classmethod
    def _walk_namespace(cls, namespace, exclude_callable):
        """Generator to walk through a namespace and yield its modules

        This will take a given namespace, by name, and recursively yield every
        module contained within it. It uses pkgutil.walk_packages to do so, any
        ImportErrors are caught and logged, those modules will not be yielded.

        Args:
            namespace (str): The string of the root namespace to search
            exclude_callable (callable): callable used to evaluate if
                module is to be excluded.

        Returns:
            modules (iterator): Modules contained in the namespace.
        """

        # Start off by yielding the module at the highest level. This will
        # either represent the __init__.py of the package or the module itself
        # if namespace referred to a specific file
        my_module = cls._get_module(namespace)
        if my_module:
            yield my_module

        try:
            namespace_path = my_module.__path__
        except AttributeError:
            # We expect this, if it's a file, it won't have a path. There is no
            # sense in walking if it is only a file (not a directory)
            return

        # Yield every sub-module that walk_packages discovers.
        # walk_packages will recursively look inside the namespace and detect
        # sub-sub-modules and packages
        # (Note: the prefix of `namespace + "."` is required to make this
        # recursive effect take place)
        for (imp, module_name, is_pkg) in walk_packages(
                namespace_path, namespace + "."):

            if exclude_callable(module_name):
                get_nio_logger("Discover").debug(
                    "Excluding {0} from discovery".format(module_name))
                continue

            # In this particular case, the module name gets returned without
            # the prefix, so we guard against it. Hack?
            if is_pkg and isinstance(imp, zipimporter):
                module_name = "{0}.{1}".format(namespace, module_name)

                # Since zipimporter didn't recurse, let's take care of that
                yield from cls._walk_namespace(module_name, exclude_callable)

            sub_module = cls._get_module(module_name)
            if sub_module:
                yield sub_module

    @classmethod
    def _get_module(cls, module_name):
        """Import a module and return it, if possible.

        This can be used as a "safe" import before returning. In the case that
        an ImportError is raised, this will return None and the error
        will be captured.

        This method will also catch any DependencyErrors and handle them.

        Returns:
            module (module): The imported module, None if failure occurred
        """
        try:
            # First, import the module to get its path
            my_module = import_module(module_name)
        except Exception:
            get_nio_logger("Discover").exception(
                "Failure loading module {0}".format(module_name))
            return None

        return my_module

    @classmethod
    def _get_classes_from_module(cls, module, base_class, discovery_criteria):
        """Returns all discoverable sub-classes inside of a module.

        Args:
            module (module): The module to inspect, this should be an actual
                module, not a string. No import will happen in this function
            base_class (class): The class the sub-classes should inherit from
            discovery_criteria (callable): a callable receiving as argument
                a class type, callable returns True when class is considered
                discoverable

        Returns:
            classes (list): Class objects that are discoverable and inherit
                from the base_class
        """

        # Go through each member in the module and first make sure it is a
        # class and it has the right discoverable type.
        # Then, we need to check that the class comes from the module we are
        # actually searching in. This will prevent imported classes from
        # appearing in the list.
        return [obj for (_, obj) in inspect.getmembers(module)
                if (inspect.isclass(obj) and
                    obj.__module__ == module.__name__ and
                    issubclass(obj, base_class) and
                    discovery_criteria(obj))]
