import os
import inspect
from importlib import import_module, reload
from pkgutil import walk_packages
from fnmatch import fnmatchcase

from nio.block.base import Base, Block
from nio.command.holder import CommandHolder
from nio.properties import PropertyHolder
from nio.util.logging import get_nio_logger
from nio.util.runner import Runner
from niocore.util.environment import NIOEnvironment


class Loader(object):

    reload_excepted_classes = \
        [CommandHolder, PropertyHolder, Block, Base, Runner]

    @classmethod
    def load_path(cls, path, root=None):
        """Load the classes from a given path and return the root namespace.

        Note: the modules inside of the path will not actually be imported
        here. Instead, use the namespace returned along with the Discover
        functionality to discover the types needed.

        Args:
            path (str): The path to use as the root namespace
            root (str): A root path to use as reference. If this is specified,
                only the parts of the path after the root will be used as a
                namespace. Ideally, the root passed here should be in sys.path

        Returns:
            namespace (str): The namespace at which the path can be accessed
        """
        if root is None:
            root = NIOEnvironment.get_root()

        if not os.path.isabs(root):
            get_nio_logger("Loader").warning(
                "Root path for loading should be "
                "an absolute path, {0} is not".format(root))

        # Figure out if the specified path includes the root path by splitting
        # the path around the root
        path_adjusted = path.split(root, 1)

        if len(path_adjusted) > 1:
            # This means the root was found in path, we want everything after
            # the root then
            out_path = path_adjusted[1]
        else:
            # The path is a relative path (no root found), just use path but
            # start it off with a slash for when we split in the next step
            out_path = "{0}{1}".format(os.sep, path)

        # Normalize path so the split works in multiple OS
        out_path = os.path.normpath(out_path)
        # Convert the output path to a namespace by replacing / with .
        return '.'.join(out_path.split(os.sep)[1:])

    @classmethod
    def reload_class(cls, _class):
        """Reloads a class or a set of classes and returns the reloaded classes

        Args:
            _class (class type): A starting class

        Returns:
            new_class (class type): starting class reloaded type
            reloaded_types (class type list): The newly updated class objects
                to replace the ones that were reloaded.

                If an error occurs reloading, the message will be logged and
                the class will not be included in the list of reloaded classes.
        """

        reloaded_modules = []
        reloaded_types = cls._reload_class(_class, reloaded_modules)

        # find newly reloaded class type
        new_class = None
        for _type in reloaded_types:
            if _type.__name__ == _class.__name__:
                new_class = _type
                break

        return new_class, list(reloaded_types)

    @classmethod
    def _reload_class(cls, _class, reloaded_modules):
        """Reloads a list of classes and return the reloaded classes

        Args:
            _class (class type): A starting class
            reloaded_modules (list): A list of already reloaded modules, this
                parameter is used for optimizations, it assists in keeping a
                list so that modules are not reloaded more than once per
                'external-reload' call

        Returns:
            classes (list): The newly updated class objects to replace the
                ones that were reloaded. If an error occurs reloading, the
                message will be logged and the class will not be included
                in the list of reloaded classes.
        """

        out_classes = set()

        try:
            module = import_module(_class.__module__)
        except Exception:
            get_nio_logger("Loader").exception(
                "Failure importing module: {0} for class {1}".
                format(_class.__module__, _class.__name__))
            return out_classes

        if _class.__module__ not in reloaded_modules:
            try:
                module = reload(module)
            except Exception:
                get_nio_logger("Loader").exception(
                    "Failure reloading module: {0} for class {1}".
                    format(_class.__module__, _class.__name__))
                return out_classes
            reloaded_modules.append(_class.__module__)

        new_class = cls._get_class_from_module(_class.__name__, module)
        if new_class:
            # find out base classes, and reload its module as well
            base_classes = inspect.getmro(new_class)
            for _base_class in base_classes:
                # exclude same class, explicit excepted classes and builtins
                if _base_class != new_class \
                        and _base_class not in cls.reload_excepted_classes \
                        and _base_class.__module__ != "builtins":
                    out_classes |= \
                        cls._reload_class(_base_class, reloaded_modules)
            out_classes.add(new_class)
        else:
            get_nio_logger("Loader").error(
                "Could not find class {0} in {1}".format(
                    _class.__name__, module.__name__))

        return out_classes

    @classmethod
    def _get_class_from_module(cls, class_name, module):
        """Returns the class with a given name inside of a module.

        Args:
            class_name (str): The name of the class to return
            module (module): The module to inspect, this should be an actual
                module, not a string. No import will happen in this function

        Returns:
            class (class): Class object of the specified name within the
                module. None if the class cannot be found.
        """

        # Go through each member in the module and first make sure it is a
        # class. Then, we need to check that the class comes from the module
        # we are actually searching in. This will prevent imported classes
        # from appearing in the list. Finally, check the class name
        for (name, _class) in inspect.getmembers(module):
            if (inspect.isclass(_class) and
                    _class.__module__ == module.__name__ and
                    name == class_name):
                return _class

        return None

    @classmethod
    def namespace_loadable(cls, namespace, exclude_patterns):
        """ Attempts to load all modules under given namespace

        Args:
            namespace (str): root namespace
            exclude_patterns (list): module patterns to exclude

        Returns:
             (loadable (bool), errors (dict))
             tuple containing overall operation result, and in case there were
             errors loading, a dict containing {[module name]: [failure reason]}
        """
        loadable = True
        results = {}

        # import top module
        my_module = import_module(namespace)
        namespace_path = my_module.__path__

        # import sub modules
        for (imp, module_name, is_pkg) in walk_packages(
                namespace_path, namespace + "."):
            try:
                # process for exclusion
                if any(fnmatchcase(module_name, pattern)
                       for pattern in exclude_patterns):
                    continue
                # attempt to import
                import_module(module_name)
            except Exception as e:
                loadable = False
                results[module_name] = str(e)

        return loadable, results

    @classmethod
    def is_namespace_valid(cls, namespace):
        """ Verifies that namespace can be loaded as a python module

        Args:
            namespace (str): namespace to validate

        Returns:
             True if namespace is valid, False otherwise
        """
        try:
            # import as module
            import_module(namespace)
            return True
        except:
            return False
