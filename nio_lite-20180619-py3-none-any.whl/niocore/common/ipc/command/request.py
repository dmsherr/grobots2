class IPCRequestCommand(object):
    """ Defines a Request Command
    """

    def __init__(self, command_path, parameters):
        """ Create a new IPCRequestCommand instance

        Args:
            command_path: path specifying command to execute, when sending a
                command to a block, this path is of the form [block]/[command]
                otherwise [command] is used.
            parameters: command parameters
        """
        self.command_path = command_path
        self.parameters = parameters or {}

    def __str__(self):
        return "command path: {0}, parameters: {1}".format(self.command_path,
                                                           self.parameters)
