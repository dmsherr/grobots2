

class IPCHeader(object):
    def __init__(self):
        self.message_id = None
        self.correlation_id = None

    def __str__(self):
        return "message_id: {0}, correlation_id: {1}".format(
            self.message_id, self.correlation_id)


class IPCMessage(object):
    # This setting is configured through nio.conf and set in the ServiceManager
    TIME_TO_LIVE = 2

    def __init__(self, body):
        self.header = IPCHeader()
        self.body = body

    def __str__(self):
        return "header: {0}, body: {1}".format(self.header, self.body)
