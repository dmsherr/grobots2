class IPCBase(object):
    """ Defines interface for InterProcessCommunications.
    """

    def start(self):
        raise NotImplementedError()

    def stop(self):
        raise NotImplementedError()

    def send(self, message, callback=None):
        raise NotImplementedError()

    def send_async(self, message):
        raise NotImplementedError()

    def is_request_pending(self, _id):
        raise NotImplementedError()
