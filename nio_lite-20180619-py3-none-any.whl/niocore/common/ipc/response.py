from enum import Enum


class IPCResponseStatus(Enum):
    ok = 1
    error = 2


class IPCResponse(object):
    """ Defines a Response Command
    """

    Status = IPCResponseStatus.ok

    def __init__(self, status, result=None, description="", exception=None):
        """ Sets the response result.

        Args:
            status (Status): specifies request status
            result: request result (varies depending on the command)
            description (string): resulting command description
        """
        self.status = status
        self.result = result
        self.description = description
        self.exception = exception

    def __str__(self):
        return "status: {0}, result: {1}, description: {2}".format(
            self.status.name,
            self.result,
            self.description)
