from nio.util.logging import get_nio_logger
from nio.util.threading import spawn
from niocore.common.executable_request import ExecutableRequest
from niocore.common.ipc import IPCMessage
from niocore.common.ipc.command.request import IPCRequestCommand
from niocore.common.ipc.response import IPCResponse
from niocore.common.ipc.response import IPCResponseStatus
from niocore.util.pickles import pickles


class IPCHandler(object):

    """ Handles IPC communications for a service.

    A service will create an instance of this class and delegate its
    IPC communications to it.
    """

    def __init__(self, ipc_service_type, service_launcher):
        """ Initializes the class providing the service it will handle
        communications for

        Args:
            ipc_service_type: Type for InterProcessCommunications, this type
                will conform to interface IPCBase (see niocore.common.ipc.base)
            service_launcher: ServiceLauncher instance for which communications
                will be handled
        """
        self.ipc_service_type = ipc_service_type
        self._service_launcher = service_launcher
        self._service = service_launcher._service
        self._ipc_service = None
        self.logger = get_nio_logger("{0}".format(self.__class__.__name__))

    def configure(self, context):
        """ Creates the IPC class that will be used for communications.

        Args:
            context: Context containing the pipe to be used to communicate
        """
        self._ipc_service = self.ipc_service_type(context.service_pipe,
                                                  context.core_pipe,
                                                  self._receive_callback)

    def start(self):
        if self._ipc_service:
            self._ipc_service.start()

    def stop(self):
        if self._ipc_service:
            self._ipc_service.stop()
            self._ipc_service = None

    def _handle_command(self, message):
        """ Receives a message from the core

        Args:
            message: Message encapsulating the core request, the
                command will be for the service or a block within the
                service, in which case the command path is formatted as:
                block/command
        Returns:
            response: Request response.
        """
        result = None
        try:
            if self._is_block_command(message.body.command_path):
                # invoke block command
                result = self._invoke_block_command(
                    message.body.command_path, message.body.parameters)
            elif message.body.command_path == 'start':
                # Handle the start command differently
                self._service_launcher._start_service()
            elif message.body.command_path == 'stop':
                # Handle the stop command differently
                self._service_launcher._stop_service()
            else:
                # invoke a regular service command, command_path in this
                # case matches requested command
                result = self._service.invoke(message.body.command_path,
                                              message.body.parameters)
        except Exception:
            self.logger.warning("Failed to execute command: {}".
                                format(message.body.command_path), exc_info=True)
            # since this method is launched from a thread spawn,
            # the exception is caught after a join on the thread
            # see nio_thread.join() in _receive_callback
            raise

        return IPCResponse(IPCResponseStatus.ok, result,
                           "Successful command execution")

    def _handle_request(self, message):
        """ Handles a service executor request

        Args:
            message: Message encapsulating the ExecutableRequest coming from
                core/main process

        Returns:
            response: Request response.
        """

        try:
            # access ExecutableRequest instance from message
            request = message.body
            # make sure it is an ExecutableRequest
            if not isinstance(request, ExecutableRequest):
                raise TypeError("Request is not an ExecutableRequest")
        except AttributeError:
            self.logger.warning("Failed to access body for message: {0}".
                                format(message), exc_info=True)
            # since this method is launched from a thread spawn,
            # the exception is caught after a join on the thread
            # see nio_thread.join() in _receive_callback
            raise

        try:
            # execute request coming from message
            result = request.execute()
        except Exception:
            self.logger.warning("Failed to execute: {0}".format(request),
                                exc_info=True)
            raise

        return IPCResponse(IPCResponseStatus.ok, result,
                           "Successful request execution")

    def _receive_callback(self, message):
        """ Receives a message from the core

        Args:
            message: Message encapsulating the core request, such request
                could be a command or a service request.
        """
        response_expected = message.header.message_id is not None
        if isinstance(message.body, IPCRequestCommand):
            nio_thread = spawn(self._handle_command, message)
        else:
            nio_thread = spawn(self._handle_request, message)

        # is a response expected?
        if response_expected:
            self.logger.debug("IPC response expected to message: {0}".
                              format(message.body))
            try:
                response = nio_thread.join()
            except Exception as e:
                description = "Failed to execute: {}".format(message)
                response = IPCResponse(IPCResponseStatus.error,
                                       None,
                                       description,
                                       e if pickles(e) else None)

            self.logger.debug("Response is: {0}".format(response))
            self._send_response(message.header.message_id,
                                response)
        else:
            self.logger.debug("NO IPC response expected to message: {0}".
                              format(message.body))

    def _send_response(self, message_id, response_command):
        """ Creates and sends a message.

        Args:
            message_id: id sent during the request, which will be
                used to correlate the request with this response.
            response_command: response to be contained in the message
        """
        if self._ipc_service:
            response = IPCMessage(response_command)
            response.header.correlation_id = message_id
            self.send_async(response)

    def send_async(self, message):
        """ Sends an async message to core

        Args:
            message: message to be sent
        """
        if self._ipc_service:
            try:
                self._ipc_service.send_async(message)
            except Exception:
                self.logger.exception(
                    "Could not send message: {0}".format(message))

    def _is_block_command(self, command_path):
        """ Finds out if command path specified is for a block

        Block commands use the format: block/command

        Args:
            command_path: command path identifier
        """
        try:
            return len(command_path.split('/')) == 2
        except:
            return False

    def _invoke_block_command(self, command_path, args):
        """ Invoke a particular command on a particular block instance
         within the service.

        Args:
            command_path (str): Of the form block_alias/command.
            args (dict): Of the form {param_name: value}.

        Returns:
            result: The result of the command invocation.

        """
        block, command = self._parse_cmd_path(command_path)
        # Error invoking command should not change block's status
        return block.invoke(command, args)

    def _parse_cmd_path(self, path):
        """ Helper function to split the id/command path and find the
        correct block controller in the service.

        Args:
            path (str): Path to the command. Of the form block_alias/command

        Returns:
            controller (BlockController): The controller wrapping the
                targeted Block instance.
            command (str): The name of the command.

        """
        try:
            block_id, command = path.split('/')
        except Exception as e:
            raise RuntimeError(
                "Invalid command path: %s, details: %s" % (path, str(e)))

        try:
            block = self._service.blocks[block_id]
        except KeyError:
            raise RuntimeError("Block %s does not exist" % block_id)
        else:
            return block, command
