class StopMessage(object):

    """ Defines a stop 'me' message to be sent from Service to Core

    """
    def __init__(self, id):
        """ Initializes the message

        Args:
            id: Service identifier
        """
        self.id = id

    def __str__(self):
        return "Stop Service Message: {0}".format(self.id)
