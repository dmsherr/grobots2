class ExecutableRequest(object):
    """ Defines an executor request """

    def __init__(self, _type, method, *args, create_instance=False, **kwargs):
        """ Creates an ExecutableRequest instance

         Args:
             _type (type): class type
             method (str): method to execute
             create_instance (bool): if True, an instance of type is created
                 and method is requested from it.
             args: positional arguments to use when calling method
             kwargs: keyword arguments to use when calling method
        """
        self._type = _type
        self._method = method
        self._args = args
        self._create_instance = create_instance
        self._kwargs = kwargs

    def execute(self):
        """ Executes request """

        # Determine object to get method from
        _object = self._type() if self._create_instance else self._type

        # get method to execute
        method = getattr(_object, self._method, None)

        # invoke
        return method(*self._args, **self._kwargs)

    def __str__(self):
        return "Executor request, type: {0}, method: {1}, args: {2}, kwargs: "\
               "{3}".format(self._type, self._method, self._args, self._kwargs)
