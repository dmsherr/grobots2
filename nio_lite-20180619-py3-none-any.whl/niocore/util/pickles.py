
import pickle


def pickles(instance):
    try:
        pickle.dumps(instance)
        return True
    except:
        return False
