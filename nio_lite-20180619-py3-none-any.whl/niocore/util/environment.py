"""

  NIO Environment handler


"""
import ast
import os
import re
import sys
from os.path import abspath, realpath, isdir, join

from nio.modules.settings import Settings
from nio.modules.persistence import Persistence
from nio.properties.base import ENVIRONMENT_VAR


class NIOEnvironment(object):

    _root = os.getcwd()
    _conf_files = []
    # TODO: remove when obsolete no longer applies
    _obsolete_env_vars = {}
    _user_defined_file = {}
    _user_defined_persistence = {}

    @classmethod
    def set_environment(cls, root, conf_files,
                        obsolete_env_file=""):
        """ Sets NIO running environment

        Args:
            root (str): working directory
            conf_files (list): paths to conf files
            obsolete_env_file (str): path to obsolete env file
        """
        if not os.path.isfile(root):
            root = realpath(root)

        cls._conf_files = []
        for conf_file in conf_files:
            if not os.path.isfile(conf_file):
                # They specified a conf file and it's not already a file
                new_path = join(root, conf_file)
                if not os.path.isfile(new_path):
                    raise ValueError("File: {} is invalid".format(conf_file))
                conf_file = new_path
            # save along with modified file date so that files
            # are reloaded only when needed
            modified_time = os.stat(conf_file).st_mtime
            cls._conf_files.append({
                "path": conf_file,
                "modified_time": modified_time
            })

        # TODO: remove when obsolete no longer applies
        cls._handle_obsolete_env_file(root, obsolete_env_file)

        cls._root = root
        # making project's root directory the working/current directory
        os.chdir(root)

        # Add root to sys.path so we can load custom block/service code
        sys.path.append(root)

    @classmethod
    def reset(cls):
        """ Resets environment

        Currently used from unittests
        """
        cls._root = os.getcwd()
        # TODO: remove when obsolete no longer applies
        cls._obsolete_env_vars = {}
        cls._conf_files = []
        cls._user_defined_file = {}
        cls._user_defined_persistence = {}

    @classmethod
    def substitute_env_vars(cls, settings, in_place=False):
        """ Public method for pre-processing settings.

        Substitutes any environment variable references for their
        configured values, leaving other settings unchanged.

        Args:
            settings (dict): the config to process
            in_place (bool): when true, substitute the settings dict
                destructively

        Returns:
            settings (dict): the same config, with environment variables
                replaced with configured values. Usually not needed,
                but provided for convenience.


        """
        # if the in_place flag is set, make a deep copy of settings
        if not in_place:
            from copy import deepcopy
            settings = deepcopy(settings)

        if isinstance(settings, dict):
            for k in settings:
                data = settings[k]
                if isinstance(data, dict) or isinstance(data, list):
                    data = cls.substitute_env_vars(data)
                else:
                    data = cls.replace_setting(data)
                settings[k] = data
        elif isinstance(settings, list):
            for idx, val in enumerate(settings):
                if isinstance(val, dict) or isinstance(val, list):
                    val = cls.substitute_env_vars(val)
                else:
                    val = cls.replace_setting(val)
                settings[idx] = val
        elif isinstance(settings, str):
            settings = cls.replace_setting(settings)

        return settings

    @classmethod
    def replace_setting(cls, value, attempt_conversion=True):

        def get_default(variable):
            """ Provides a default value for a variable that is unset
            """
            return "[[{}]]".format(variable)

        # A replace function to pass to the regex substitution
        def repl(m):
            return str(cls.get_variable(m.group(1), get_default(m.group(1))))

        if isinstance(value, str):
            # Find out if the entire string is a single environment variable,
            match = ENVIRONMENT_VAR.fullmatch(value)
            if match is not None:
                # if so, then try to convert it or eval it
                var_name = match.group(1)
                value = cls.get_variable(var_name, get_default(var_name))
                if attempt_conversion:
                    value = cls._attempt_conversion(value)
            else:
                # otherwise, just replace the environment variable expression
                # with the environment variable value
                value = re.sub(ENVIRONMENT_VAR, repl, value)
        return value

    @staticmethod
    def _attempt_conversion(value):
        try:
            value = ast.literal_eval(value)
        except (ValueError, SyntaxError):
            # if literal_eval fails, return value as is
            pass
        return value

    @classmethod
    def reload_env(cls):
        reload = False
        for conf_file in cls._conf_files:
            modified_time = os.stat(conf_file["path"]).st_mtime
            if modified_time != conf_file["modified_time"]:
                conf_file["modified_time"] = modified_time
                reload = True
                break
        if reload:
            Settings.clear()
            # TODO: keep in mind "import_files" is not an interface call
            Settings.import_files(cls.get_conf_files())
            cls.load_user_defined_from_settings()

    @classmethod
    def get_variable(cls, name, default=None):
        """Returns environment variables
        Arg:
            name: Name of the variable to get

        Returns: mixed
        """

        # Strip name
        name = name.strip()

        # TODO: remove when obsolete env vars no longer applies
        value = cls._obsolete_env_vars.get(name, default)

        # Get from user_defined settings
        # TODO: change 'value' to 'default' when obsolete no longer applies
        value = cls._user_defined_file.get(name, value)

        # Override from user_defined persistence
        value = cls._user_defined_persistence.get(name, value)

        # if asking for PROJECT_ROOT and it does not contain
        # a valid value then provide it from environment
        if name == "PROJECT_ROOT" and not isdir(value):
            value = cls.get_root()

        # Allow actual environment variables to override values
        return os.getenv(name, value)

    @classmethod
    def get_root(cls):
        """ Returns the project root path.

        This is typically the path where the nio.conf file exists. Or the path
        specified by the -r option on the executable.
        """
        return cls._root

    @classmethod
    def get_conf_files(cls):
        """ Returns the project configuration files """
        return [conf_file["path"] for conf_file in cls._conf_files]

    @classmethod
    def get_path(cls, path):
        """ Returns an absolute path given a project path.

        Args:
            path (str): a path to return relative to the project root. If an
                absolute path is provided, the same path will be returned.

        Returns:
            abspath (str): an absolute path to the specified path

        >>> NIOEnvironment.set_environment('/path/to/project')
        >>> NIOEnvironment.get_path('blocks/util') ==
        >>> '/path/to/project/blocks/util'
        """

        # join will return path if path is absolute
        root = cls.get_root()
        if root:
            return abspath(join(root, path))
        return abspath(path)

    @classmethod
    def get_resource_paths(cls, resource, default=""):
        """ Get the configured paths for a given environment resource.

        This will return a list of all configured paths in the nio.conf file
        for a given project resource. It assumes that project resource paths
        fall under the "environment" settings group and have a format of
        "resource". The configuration value can be a comma-separated list
        of paths.

        Example INI:
            [environment]
            blocks: blocks, alternate/path/to/blocks
            services: services

        Args:
            resource (str): A string representing the resource to load.
                Probably one of ['blocks', 'services', 'components']
            default: default value when gathering setting

        Returns:
            paths (list): A list of the configured paths. Note: this function
                will not produce absolute paths, a user can use the get_path
                function to accomplish that with each of the outputted paths
                from this function.
        """
        from nio.modules.settings import Settings
        path_str = Settings.get(
            'environment', '{0}'.format(resource), fallback=default)

        return [st.strip() for st in path_str.split(',') if st]

    @classmethod
    def load_user_defined_from_settings(cls):
        cls._user_defined_file = Settings.get(section="user_defined",
                                              fallback={})

    @classmethod
    def update_user_defined_from_settings(cls):
        """ Called after persistence module is updated
        """
        # very similar if not identical to the call made in
        # load_user_defined_from_settings, however, since Settings
        # gives higher priority to reading values from Persistence
        # there is a real possibility when reading 'user_defined' again,
        # after the Persistence module is initialized, that this call
        # will yield new results
        user_defined = Settings.get(section="user_defined",
                                    fallback={})
        # merge/override
        for key, value in user_defined.items():
            cls._user_defined_file[key] = value

    @classmethod
    def load_user_defined_from_persistence(cls):
        cls._user_defined_persistence = \
            Persistence().load("user_defined", default={})

    @classmethod
    def save_user_defined(cls):
        Persistence().save(cls._user_defined_persistence, "user_defined")

    @classmethod
    def get_user_defined(cls):
        return cls._user_defined_persistence

    # TODO: remove when obsolete no longer applies
    @classmethod
    def _handle_obsolete_env_file(cls, root, env_file):
        if env_file:
            if not os.path.isfile(env_file):
                env_file = join(root, env_file)
            if os.path.isfile(env_file):
                from configparser import ConfigParser
                config = ConfigParser(strict=False)
                config.optionxform = str
                config.read(env_file)

                try:
                    cls._obsolete_env_vars = config['vars']
                except KeyError:
                    pass
