"""

   Network common

"""
from copy import copy
from datetime import timedelta
from threading import Lock

from nio.modules.scheduler.job import Job
from nio.util.logging import get_nio_logger
from niocore.util.hooks import Hooks
from niocore.util.network.ping import ping, ping_cmd


class NetworkMonitor(object):
    """ Pings a list of host provided and execute hooks callback depending
    on monitoring outcome

    """

    def __init__(self,
                 timeout=30,
                 use_cmd=False,
                 report_success=True,
                 report_failure=False,
                 report_result=False):
        self._lock = Lock()
        self._hooks = Hooks([])
        self.logger = get_nio_logger(self.__class__.__name__)
        self._using_cmd = use_cmd
        self._report_success = report_success
        self._report_failure = report_failure
        self._report_result = report_result
        self._job = None
        self._timeout = timeout

    def monitor_host(self, host, callback):
        """ Adds a callback when a connection to a host can be established

        Args:
            host (str): Host to monitor
            callback : Method to be called when connection is established

        """
        with self._lock:
            if not self._job:
                self._job = Job(self._check_connections,
                                timedelta(seconds=self._timeout),
                                True)
            # register host
            self._hooks.register(host)
            self._hooks.attach(host, callback)

    def unmonitor_host(self, host, callback):
        """ Removes a callback so the method is not executed when host
           connection is established

        Args:
            host (str): Host to stop monitoring
            callback : Method to remove

        """
        with self._lock:
            try:
                # Remove callback
                self._hooks.detach(host, callback)
                # Remove url once all callbacks have been unregistered
                if self._hooks.unregister(host):
                    self._job.cancel()
                    self._job = None
            except KeyError:
                pass  # detaching a url that is not registered. Ignored
            except Exception:
                self.logger.exception("Un-monitoring callback for host {}".
                                      format(host))

    def _check_connections(self):
        """ Probe all connections to host list
        """
        with self._lock:
            hosts = copy(self._hooks.get_points())
        for host in hosts:
            if self._check_on(host):
                self.logger.debug("Connection to host: {} is up".format(host))
                if self._report_success:
                    self._execute_hooks(host, True)
            else:
                self.logger.debug("Connection to host: {} is down".format(host))
                if self._report_failure:
                    self._execute_hooks(host, False)

    def _execute_hooks(self, host, result):
        try:
            if self._report_result:
                self._hooks.run(host, result)
            else:
                self._hooks.run(host)
        except Exception:
            self.logger.exception("Executing hook on host: {}".format(host))

    def _check_on(self, host):
        self.logger.debug("Checking host: {}".format(host))

        if self._using_cmd:
            return ping_cmd(host)

        try:
            ping(host)
            return True
        except Exception as e:
            self.logger.info("Failed to check host, switching check method "
                             "to ping command, details: {}".
                             format(self.logger.exc_info(e)))
            self._using_cmd = True
            # Try using ping process
            return ping_cmd(host)
