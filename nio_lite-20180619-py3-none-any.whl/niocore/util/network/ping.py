"""

  Ping host implementation

"""
import time
import random
import select
import socket


def chk(data):
    x = sum(a + b * 256 for a, b in zip(data[::2], data[1::2] + b'\x00')) & \
        0xFFFFFFFF
    x = (x >> 16) + (x & 0xFFFF)
    x = (x >> 16) + (x & 0xFFFF)
    return (~x & 0xFFFF).to_bytes(2, 'little')


def ping(host, timeout=1):
    with socket.socket(socket.AF_INET,
                       socket.SOCK_RAW,
                       socket.IPPROTO_ICMP) as conn:
        payload = random.randrange(0, 65536).to_bytes(2, 'big') + b'\x01\x00'
        packet = b'\x08\x00' + b'\x00\x00' + payload
        packet = b'\x08\x00' + chk(packet) + payload
        conn.connect((host, 1))
        conn.sendall(packet)

        start = time.monotonic()

        while select.select([conn], [], [],
                            max(0, start + timeout - time.monotonic()))[0]:
            packet = conn.recv(1024)[20:]
            unchecked = packet[:2] + b'\0\0' + packet[4:]

            if packet == b'\0\0' + chk(unchecked) + payload:
                return time.monotonic() - start


def ping_cmd(host):
    import subprocess
    from os import name

    param = "-n" if name == 'nt' else "-c"

    output = str(subprocess.Popen(["ping", param, "1", host],
                                  stdout=subprocess.PIPE).communicate()[0])
    return not ('unreachable' in output or "100.0% packet loss" in output)
