from threading import Event

from nio.util.threading import spawn


def wait_for_events(max_time, *events):
    # create an event that gets signaled when
    # one of the events is signaled
    event_share = Event()

    def set_event_share(event, event_max_time):
        # wait on specific event
        if event.wait(event_max_time):
            # signal 'shared' event
            event_share.set()

    for current_event in events:
        # clear event and start wait on a different thread
        current_event.clear()
        spawn(set_event_share, current_event, max_time)

    # return on the first event that is set
    return event_share.wait(max_time)
