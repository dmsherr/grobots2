from uuid import uuid4


class Unique(object):
    @staticmethod
    def id():
        return uuid4().hex
