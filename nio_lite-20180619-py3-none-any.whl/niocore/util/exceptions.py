
class MultipleChoices(Exception):
    """ Exception to raise when an item can't be uniquely identified
    """
    def __init__(self, choices):
        super().__init__()
        self.choices = choices
