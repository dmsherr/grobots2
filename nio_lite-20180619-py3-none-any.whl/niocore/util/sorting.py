def sort_collection(collection, order_function):
    # determine orders, and prepare array to be sorted
    orders = []
    for item in collection:
        # determine component order
        order_fn = getattr(item, order_function)
        order = order_fn()

        # store it as a tuple following format (order, module)
        orders.append((order, item))
    # sort list of tuples, specify 'order' to be the key
    orders.sort(key=lambda item: item[0])

    return [item for _, item in orders]
