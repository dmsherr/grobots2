def get_service_label(name, id, include_id=False):
    """ Provides a label to a service based on name and id properties

    Args:
        name (str): Service name
        id (str): Service identifier
        include_id (bool): whether id is to be included in label
    """
    if name:
        if include_id:
            return "{}-{}".format(name, id)
        else:
            return name
    return id
