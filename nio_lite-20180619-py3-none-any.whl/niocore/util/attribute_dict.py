from collections import Mapping
from nio.util.class_attributes import ClassAttributes


class AttributeDict(dict):

    """Adds "." syntax when accessing dictionary entries

    For example:
    dictionary[key] can be accessed as dictionary.key

    """

    def __getattr__(self, key):
        """Override getattr, but translate KeyErrors into AttrErrors"""
        if key not in self:
            raise AttributeError(key)

        return self[key]

    def __setattr__(self, key, value):
        """Override setattr, make it an instance (self) method"""
        self[key] = value

    def merge(self, addl_dict):
        """Recursively merge in another dictionary, overwriting values

        Args:
            addl_config (dict): the additional configuration to overwrite

        Returns:
            None: the keys will be overwitten on this configuration object

        The purpose of this method is to recursively update values on this
        dictionary

        Example:
        >>> d = AttributeDict({"a":1, "b": {"c": 3, "d": 4}})
        >>> d.merge({"b": {"d": 5, "e": 5}})
        >>> d
        {"a":1, "b": {"c": 3, "d": 5, "e": 5}}
        """

        # First make sure it is actually a dictionary so we can iterate
        if not isinstance(addl_dict, Mapping):
            return

        def _recursive_dict_update(dict_a, dict_b):
            for key, val in dict_b.items():
                dict_val = dict_a.get(key, {})
                # Need to make sure they are both dictionaries before recursing
                if isinstance(val, Mapping) and isinstance(dict_val, Mapping):
                    r = _recursive_dict_update(dict_val, val)
                    dict_a[key] = r
                else:
                    dict_a[key] = dict_b[key]
            return dict_a

        _recursive_dict_update(self, addl_dict)

    def get_attributes(self):
        """ Finds out 'attribute' data from a configuration class,
        it does so relying on the __getattr__ method in AttributeDict,
        this method must give precedence to 'data' over 'methods' of a class
        should they have the same name, note, that this behaviour is contrary
        to python's use of __getattr__

        Returns:
            Attributes in dictionary format
        """
        attributes = {}
        for attr in self.keys():

            # first discard attributes starting with '_'
            if not attr.startswith('_'):

                # cache attribute value
                attr_value = getattr(self, attr)

                # Note: if attr name matches name of an existing method,
                # function, etc in the class, __getattr__ does not get called
                # since python only does so for attributes that don't actually
                # exist, therefore, do the opposite, give preference to data
                # over python attributes
                if not ClassAttributes.is_attr(attr_value):
                    attributes[attr] = self[attr]
                else:
                    attributes[attr] = attr_value

        return attributes


def enforce_attr_dict(orig_dict):
    """ Return an AttributeDict of a dict or AttributeDict """

    # make sure potential contaning dicts are also enforced to be attr dicts
    if isinstance(orig_dict, dict):
        for key, value in orig_dict.items():
            orig_dict[key] = enforce_attr_dict(value)

    if not isinstance(orig_dict, AttributeDict) and \
            isinstance(orig_dict, dict):
        # it's not an AttributeDict, but it's a dict, convert
        return AttributeDict(orig_dict)
    return orig_dict
