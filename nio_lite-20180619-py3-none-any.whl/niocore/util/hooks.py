"""

  Hooks utility

"""

from threading import RLock
from nio.util.threading import spawn


class Hooks(object):
    """ Simple Hooks utility for registering and executing associated callbacks

    """

    def __init__(self, points=None):
        """ Initialize Hooks based on list of points

        Args:
            points (list): List of points to define
        """
        self._hooks = {p: [] for p in points} if points else {}
        self._hooks_lock = RLock()

    def get_points(self):
        """ Return list of points
        """
        return list(self._hooks)

    def register(self, point):
        """ Register a new point if it does not exist
        """
        with self._hooks_lock:
            if not self._hooks.get(point):
                self._hooks[point] = []

    def unregister(self, point, force=False):
        """ Unregister a point if there is no more callback registered

        Args:
            point (str): point for running callbacks
            force (boolean): Force removal even there are some callbacks
            registered

        """
        with self._hooks_lock:
            if not self._hooks.get(point):
                if len(self._hooks.get(point)) == 0 or force:
                    del self._hooks[point]
                    return True
        return False

    def attach(self, point, callback):
        """ Attach a callback to a point

        """
        with self._hooks_lock:
            if callback not in self._hooks.get(point, None):
                self._hooks[point].append(callback)

    def detach(self, point, callback):
        """ Detach a callback from a point

        """
        with self._hooks_lock:
            self._hooks[point].remove(callback)

    def run(self, point, *args, **kwargs):
        """ Executes callbacks associated with a point

        Args:
            point (str): point for running callbacks
        """
        if "_wait_for_completion_" in kwargs:
            wait_for_completion = kwargs["_wait_for_completion_"]
            del kwargs["_wait_for_completion_"]
        else:
            wait_for_completion = False

        threads = []
        with self._hooks_lock:
            hooks = self._hooks.get(point)
            if hooks is None:
                raise TypeError("Invalid point")
            for hook in hooks:
                threads.append(spawn(hook, *args, **kwargs))

        if wait_for_completion:
            for thread in threads:
                thread.join()

        return threads
