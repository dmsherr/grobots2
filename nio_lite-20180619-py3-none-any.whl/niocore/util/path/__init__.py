import os


def get_subdirectories(path):
    """Finds subdirectories for given path

    Args:
        path (str):  given path

    Keyword Args:
        None

    Returns:
        out: list of subdirectories (relative)

    Raises:
        None

    Examples:
    #    >>> subdirectories = get_subdirectories(path)

    """

    sub_dirs = []

    excluded_dirs = ['__pycache__']

    if not os.path.isdir(path):
        return []

    if os.path.exists(path):
        for subdir in os.listdir(path):
            if subdir in excluded_dirs:
                continue

            # form child_path
            child_path = "{0}{1}{2}".format(path, os.sep, subdir)
            if os.path.isdir(child_path):
                sub_dirs.append(subdir)

    return sub_dirs
