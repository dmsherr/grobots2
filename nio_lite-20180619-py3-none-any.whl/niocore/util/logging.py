from copy import deepcopy
import logging.config
from nio.util.logging.helper import LoggingHelper
from niocore.util.attribute_dict import AttributeDict
from nio.modules.settings import Settings

_DEFAULT_CONFIG = {
    "version": 1
}


def configure(logging_conf=None, service_name='main'):
    """Configure the current Python logging with some logging config

    Args:
        logging_conf: A dictionary of how to configure logging. If omitted,
            the method will grab the current logging settings.
        service_name (str): The name of the service this config will affect.
            This defaults to main, which would represent the core service.
    """
    LoggingHelper._register_prefix(service_name)

    if logging_conf is None:
        logging_conf = get_logging_settings()

    if not logging_conf or not isinstance(logging_conf, dict):
        # Didn't specify any config
        return

    # Make a copy of the logging config since we will be updating it in place
    logging_conf = deepcopy(logging_conf)

    # Replace any instances of the service name placeholder with our actual
    # service name
    _replace_service_name(logging_conf, service_name)
    # Merge our final config into our defaults, then update the logging
    defaults = AttributeDict(_DEFAULT_CONFIG)
    defaults.merge(logging_conf)
    logging.config.dictConfig(defaults)


def get_logging_settings():
    """ Return the logging config passed through nio settings"""
    return Settings.getdict('logging', 'conf', fallback={})


def _replace_service_name(conf, service_name):
    """ This updates the configuration and swaps in the actual service name.

    Any string value or key in the conf dictionary that contains the service
    name placeholder will get replaced with the actual service name.

    This is useful for handling the logging differently for different services.

    Args:
        conf (dict): The dictionary to recursively iterate over
        service_name (str): The name of the current service

    Returns:
        None: update happens in place
    """

    key_replacements = []
    _replace_service_name_on_values(conf, service_name, key_replacements)

    # replace keys containing __service_name__
    for d, key in key_replacements:
        new_key = key.replace('__service_name__', service_name)
        d[new_key] = d.pop(key)


def _replace_service_name_on_values(conf, service_name, key_replacements):
    """ This updates the configuration and swaps in the actual service name
    on dictionary values while collecting where key replacements are in order.

    Any string value in the conf dictionary that contains the service name
    placeholder will get replaced with the actual service name.

    In addition, it will collect dictionary keys where service name appears
    and a replacement is needed (actual replacement is not done on the keys
    since it is not possible while iterating over dictionary)

    Args:
        conf (dict): The dictionary to recursively iterate over
        service_name (str): The name of the current service
        key_replacements (list): List of tuples with format (dict, key) where
            a replacement is to be made.

    Returns:
        None: update happens in place
    """
    for conf_key, conf_val in conf.items():
        if isinstance(conf_val, dict):
            if conf_key.find('__service_name__') > -1:
                # can't replace key while iterating, save it to replace later
                key_replacements.append((conf, conf_key))
            # replace on nested dictionary
            _replace_service_name_on_values(conf_val, service_name,
                                            key_replacements)
        else:
            if isinstance(conf_val, str):
                conf[conf_key] = conf_val.replace('__service_name__',
                                                  service_name)
            if conf_key.find('__service_name__') > -1:
                # can't replace key while iterating, save it to replace later
                key_replacements.append((conf, conf_key))
