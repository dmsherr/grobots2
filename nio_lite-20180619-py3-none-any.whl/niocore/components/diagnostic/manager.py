import requests
from niocore.util.environment import NIOEnvironment

from nio import discoverable
from nio.util.versioning.dependency import DependsOn

from nio.modules.communication.subscriber import Subscriber
from nio.modules.settings import Settings
from nio.modules.persistence import Persistence

from niocore.core.component import CoreComponent
from .handler import DiagnosticHandler
from . import __version__ as component_version
from collections import deque
from threading import Lock


@DependsOn("niocore.components.rest", "0.1.0")
@DependsOn("niocore.components.management_publisher", "0.1.1")
@discoverable
class DiagnosticManager(CoreComponent):

    _name = "DiagnosticManager"
    _anonymous_key = "e6348baa-3ca8-4d6a-8203-56cae0f6e779"

    def __init__(self):
        super().__init__()
        self._handler = None
        self._api_key = None
        # dependency components
        self._rest_manager = None

        # configurable settings
        self._stats_api_url_prefix = None
        self._router_stats = None
        self._service_stats = None

        self._subscriber = None

        # want one single stack for all requests, rather than a failure queue
        self._request_queue = None
        self._queue_failures = None
        self._failure_queue_len = None
        self._queue_lock = Lock()

    def get_version(self):
        return component_version

    def configure(self, context):
        super().configure(context)

        # Register dependencies to rest and service manager
        self._rest_manager = self.get_dependency("RESTManager")

        default = NIOEnvironment.get_variable(
            'API_KEY', default=DiagnosticManager._anonymous_key)
        self._api_key = Persistence().load("api_key", default=default)

        self._stats_api_url_prefix = \
            Settings.get("diagnostic", "api_url_prefix",
                         fallback="https://api.n.io/v1/diagnostic")

        self._service_stats = \
            Settings.getboolean("diagnostic", "service", fallback=True)

        self._router_stats = \
            Settings.getboolean("diagnostic", "signals", fallback=True)

        self._queue_failures = \
            Settings.getboolean("diagnostic", "failure_queue", fallback=True)

        self._failure_queue_len = \
            Settings.getint("diagnostic", "failure_queue_len", fallback=10000)

        topic = \
            Settings.get("management_publisher", "topic", fallback="management")
        if Settings.getboolean("diagnostic", "add_instance_id",
                               fallback=True):
            instance_id = NIOEnvironment.get_variable("INSTANCE_ID")
            topic = "{}.{}".format(topic, instance_id)
        self._subscriber = Subscriber(self._on_mgmt_signal, topic=topic)

    def start(self):
        """ Starts component
        """
        super().start()

        # create REST specific handlers
        self._handler = DiagnosticHandler("/diagnostic", self)
        self._rest_manager.add_web_handler(self._handler)

        self._request_queue = Persistence().load("diagnostic_failure",
                                                 default=None)
        Persistence().remove("diagnostic_failure")

        if self._request_queue:
            self.logger.info("Loading queued diagnostic requests")
            self._request_queue = deque(iterable=self._request_queue,
                                        maxlen=self._failure_queue_len)
        else:
            self.logger.debug("No queued diagnostic requests found")
            self._request_queue = deque(maxlen=self._failure_queue_len)

        self._subscriber.open()

    def stop(self):
        """ Stops component
        """
        self._rest_manager.remove_web_handler(self._handler)
        self._subscriber.close()
        if len(self._request_queue):
            self.logger.info("Saving queued failed diagnostic requests")
            Persistence().save(list(self._request_queue), "diagnostic_failure")
        super().stop()

    def _on_mgmt_signal(self, signals):
        for signal in signals:
            if hasattr(signal, "type"):
                if signal.type == "ServiceStatusChange":
                    self._on_service_status_change(signal)
                elif signal.type == "RouterDiagnostic":
                    self._on_router_stat(signal)
            else:
                self.logger.debug('Ignored signal: {}'.format(signal.to_dict()))

    def _on_service_status_change(self, signal):
        if self._service_stats:
            url = "{}/services".format(
                self._stats_api_url_prefix
            )
            key = self.api_key if self.api_key else signal.instance_id
            payload = {
                "service": signal.service,
                "old_status": signal.old_status,
                "status": signal.status,
                "time": signal.time
            }
            self._send_to_api(url, key, payload)
        else:
            self.logger.debug('Discarding: {}'.format(signal.to_dict()))

    def _on_router_stat(self, signal):
        if self._router_stats:
            url = "{}/signals".format(
                self._stats_api_url_prefix
            )
            key = self.api_key if self.api_key else signal.instance_id
            payload = {
                # "service-id" field was added in v3.0.0 thus allow for a chance
                # of having instances pre-v3.0.0 in the network
                "service_id": getattr(signal, "service_id", "Not Available"),
                "service": signal.service,
                "blocks_data": signal.blocks_data,
                "start_time": signal.start_time,
                "end_time": signal.end_time,
            }
            self._send_to_api(url, key, payload)
        else:
            self.logger.debug('Discarding: {}'.format(signal.to_dict()))

    def _send_to_api(self, url, key, json_data):
        """
        :param url: The diagnostic URL to post to
        :param key: Diagnostic API key
        :param json_data: Information about the diagnostics to post
        :return: None

        This method will add an item to the request queue and then go through
        the queue to post requests to the Diagnostic API
        """
        with self._queue_lock:
            self._request_queue.appendleft({
                'url': url,
                'key': key,
                'json_data': json_data,
            })

            self._send_all_in_queue()

    def _send_all_in_queue(self):
        """ Go through the requests queue and send them all """

        while len(self._request_queue):
            next_api_call = self._request_queue.pop()
            headers = {
                'nio-api-key': next_api_call['key']
            }
            url = next_api_call['url']

            # Initialize response variable in case requests.post never returns
            response = None
            try:
                response = requests.post(
                    url,
                    headers=headers,
                    json=next_api_call['json_data']
                )

                # Make sure the request went through properly,
                # raise if it didn't
                response.raise_for_status()

            except (requests.exceptions.HTTPError,
                    requests.exceptions.ConnectionError):
                self.logger.debug(
                    "Failed to post diagnostic to: {}".format(url))

                # If post failed due to duplicate signal, do not appendleft
                if response is not None and response.status_code == 409:
                    self.logger.debug(
                        "Duplicate signal discarded {}".format(
                            next_api_call['json_data']))
                    continue

                # Put the failed call back at the front of the queue
                self._request_queue.appendleft(next_api_call)
                break

            self.logger.debug('Posted diagnostic to: {}'.format(url))

    @property
    def api_key(self):
        return self._api_key

    @api_key.setter
    def api_key(self, _api_key):
        self.logger.debug("API Key set to: {}".format(_api_key))
        self._api_key = _api_key
        # persist value so that it can be read eventually
        # when component starts again
        Persistence().save(_api_key, "api_key")

    def get_order(self):
        # make it start,
        # 1) after management_publisher
        # 2) before service manager (giving services a chance to send
        #    diagnostics upon termination)
        return 40
