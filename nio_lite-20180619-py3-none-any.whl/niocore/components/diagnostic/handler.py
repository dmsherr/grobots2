"""

    Diagnostic Handler

"""
import json
from nio.modules.security.access import ensure_access
from nio.util.logging import get_nio_logger
from nio.modules.web import RESTHandler


class DiagnosticHandler(RESTHandler):
    """ Handles diagnostic API requests
    """

    def __init__(self, route, manager):
        super().__init__(route)
        self._manager = manager
        self.logger = get_nio_logger("DiagnosticHandler")

    def on_get(self, request, response, *args, **kwargs):
        """ API endpoint to retrieve current block structure

        Example:
            http://[host]:[port]/diagnostic/api_key

        """

        # Ensure instance "read" access in order to retrieve project blocks
        # structure
        ensure_access("instance", "read")

        # Log
        params = request.get_params()
        self.logger.debug("on_get, params: {0}".format(params))

        # What route?
        if "identifier" in params:

            # -- api_key
            if params["identifier"] == "api_key":
                result = {"api_key": self._manager.api_key}
                # Result
                response.set_header('Content-Type', 'application/json')
                response.set_body(json.dumps(result))
                return

        raise ValueError("GET request with params: {0} is invalid".
                         format(params))

    def on_post(self, request, response, *args, **kwargs):
        """ API endpoint to accept assigning an api_key

        Example:
             http://[host]:[port]/diagnostic with {"api_key": value} in body

        """
        # Ensure instance "write" access
        ensure_access("instance", "write")

        params = request.get_params()
        body = request.get_body()
        self.logger.debug("on_post, params: {0}, body: {1}".
                          format(params, body))

        if "api_key" in body:
            self._manager.api_key = body["api_key"]
        else:
            raise ValueError("POST request with params: {0} is invalid".
                             format(params))

    def on_put(self, request, response, *args, **kwargs):
        """ Passes along to on_post handler.
        """

        return self.on_post(request, response, args, kwargs)
