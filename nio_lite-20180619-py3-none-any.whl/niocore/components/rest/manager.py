"""

    REST Manager

"""
from enum import Enum
from niocore.core.api.shutdown import ShutDownCommand
from nio import discoverable
from niocore.core.component import CoreComponent
from niocore.util.network.monitor import NetworkMonitor
from niocore.components.rest.factory import RESTHandlerFactory
from nio.modules.web import WebEngine
from nio.modules.settings import Settings
from niocore.components.rest.loop_guard import LoopGuard
from . import __version__ as component_version


@discoverable
class RESTManager(CoreComponent):

    """ Core component to handle REST functionality

    Handles API calls by registering REST resources using the web module

    """

    _name = "RESTManager"

    class WebServerStatus(Enum):

        """ Web Server Status
        """
        created = 0
        starting = 1
        failing = 2
        started = 3
        stopping = 4

    def __init__(self):
        super().__init__()
        self._web_server = WebEngine.add_server(
            Settings.getint('rest', 'port', fallback=8181),
            Settings.get('rest', 'host', fallback="127.0.0.1"),
            Settings.get('rest'))
        # Well known components
        self._block_manager = None
        self._service_manager = None
        self._net_monitor = None
        self._net_monitor_timeout = None
        self._loop_guard = LoopGuard()
        self._web_server_status = RESTManager.WebServerStatus.created

    def get_version(self):
        return component_version

    def configure(self, context):
        """ Configure REST

        Replaces the default blocking method

        """
        super().configure(context)
        # Use Web Server blocking method
        context.loop_guard = LoopGuard()

        self._net_monitor_timeout = \
            Settings.getint("rest", "network_retry_interval", fallback=30)

        # register web root
        self.register(context.system, '/nio')

        # register shutdown api call
        self.register(ShutDownCommand(context.shutdown_instance))

        # Register well known collections (blocks and manager)
        self._block_manager = self.get_dependency('BlockManager')
        self._service_manager = self.get_dependency('ServiceManager')

    def start(self):
        """ Starts Web Server

        """
        super().start()

        # Register well known collections (blocks and manager)
        self.logger.info("Registering 'block' and 'service' endpoints")

        # Register block type collection
        self.register(self._block_manager.types)
        # Register block instances collection
        self.register(self._block_manager.instances)
        # Register service type collection
        self.register(self._service_manager.types)
        # Register service instances collection
        self.register(self._service_manager.instances)

        # Try to start Web Engine
        self._web_server_status = RESTManager.WebServerStatus.starting
        self._try_web_engine_start()

    def stop(self):
        """ Stops Web Server

        """
        # Stop WebEngine
        WebEngine.stop()

        # Remove Web Server
        WebEngine.remove_server(self._web_server)

        super().stop()

    def _try_web_engine_start(self):
        try:
            # Start Web Server and WebEngine
            self._web_server.start()

            # Connection worked
            if self._web_server_status == RESTManager.WebServerStatus.failing:
                self.logger.warn("Web Server connection established")
            self._web_server_status = RESTManager.WebServerStatus.started

            if self._net_monitor:
                # remove monitoring
                self._net_monitor.unmonitor_host(self._web_server.host,
                                                 self._try_web_engine_start)
                self._net_monitor = None
        except Exception as e:
            if self._is_port_taken(e):
                # if port is not free consider re-raise which
                # if 'nio' is starting up will cause a 'nio' stop
                raise

            if self._web_server_status == RESTManager.WebServerStatus.starting:
                # show message as a warning once
                self.logger.warn("Web Server failed to start")
                self._web_server_status = RESTManager.WebServerStatus.failing
            else:
                self.logger.info("Web Server failed to start again")

            if not self._net_monitor:
                self.logger.info("Monitoring network to recover "
                                 "once connectivity is detected")
                self._net_monitor = \
                    NetworkMonitor(timeout=self._net_monitor_timeout)

                # register for network connection on using Monitor host
                self._net_monitor.monitor_host(self._web_server.host,
                                               self._try_web_engine_start)

    @staticmethod
    def _is_port_taken(exception):
        """ Determines if exception relates to a port being in use (taken)
        It only looks for 'port not free' type of condition

        Args:
            exception: exception to analyze

        Returns:
            True: if it is determined that exception was raised due to
                requested port being in use
            False: otherwise
        """
        if len(exception.args) > 0:
            condition = str(exception.args[0]).lower()

            if "port" in condition and "not free" in condition:
                return True

        return False

    def register(self, resource, route=None):
        """ Register a resource with the web module

        """
        # build route if not provided
        route = route or self._build_route(resource)
        # create REST specific handler
        handler = RESTHandlerFactory.create(route, resource)
        # Add handler to WebServer
        self.add_web_handler(handler)

        return handler

    def add_web_handler(self, handler):
        self.logger.info('adding handler for {0}'.format(handler.route))
        self._web_server.add_handler(handler)

    def remove_web_handler(self, handler):
        self.logger.info('removing handler for {0}'.format(handler.route))
        self._web_server.remove_handler(handler)

    def _build_route(self, resource):
        # build route
        route = "/{0}".format(resource.id)
        self.logger.debug('route for {0} is {1}'.format(resource.id, route))
        return route
