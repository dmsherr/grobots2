"""

    REST handler factory

"""
from niocore.core.api.collections.resource import ResourceCollection
from niocore.core.api.command import CommandResource
from niocore.core.api.resource import Resource
from niocore.components.rest.handlers.resource import \
    RESTResourceHandler
from niocore.components.rest.handlers.collection \
    import RESTResourceCollectionHandler
from niocore.components.rest.handlers.command \
    import RESTCommandHandler


class InvalidResourceType(Exception):
    pass


class RESTHandlerFactory(object):

    """ REST handler factory

    Creates REST handlers depending on the resource being exposed
    to a REST service

    """

    _handler_types = {
        ResourceCollection: RESTResourceCollectionHandler,
        CommandResource: RESTCommandHandler,
        Resource: RESTResourceHandler}

    @classmethod
    def create(cls, route, resource):
        """ Returns a new REST handler for a resource

        Args:
            route (string):  route used to access resource
            resource (object): resource to expose through REST

        Returns:
            REST handler

        Raises:
            InvalidResourceType if resource is not registered
        """
        class_type = resource.__class__

        if isinstance(resource, CommandResource):
            # Commands have not parent
            return cls._handler_types[CommandResource](route, resource)

        elif class_type in cls._handler_types:
            return cls._handler_types[class_type](route, resource)

        elif isinstance(resource, ResourceCollection):
            return cls._handler_types[ResourceCollection](
                route, resource)

        elif isinstance(resource, Resource):
            return cls._handler_types[Resource](route, resource)

        raise InvalidResourceType()
