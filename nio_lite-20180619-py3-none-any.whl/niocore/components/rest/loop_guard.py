"""
   Web Engine block / unblock

"""
from niocore.core import loop_guard
from nio.modules.web import WebEngine


class LoopGuard(loop_guard.LoopGuard):

    def __init__(self):
        self.engine_ready = False

    def block(self, **kwargs):
        # Use core blocking if engine is not ready to stop process
        # from exiting
        if not self.engine_ready:
            super().block()
        if self.engine_ready:
            WebEngine.block()

    def unblock(self):
        if not self.engine_ready:
            super().unblock()
        WebEngine.stop()

    def set_ready(self):
        self.engine_ready = True
        self.exit_flag = True
