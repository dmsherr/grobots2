"""

  REST resource handler

"""
import json

from nio.modules.web.http import HTTPNotImplemented, HTTPError, HTTPNotFound
from nio.modules.web import RESTHandler
from niocore.core.api.resource import Resource
from niocore.util.find import find
from niocore.util.exceptions import MultipleChoices


class RESTResourceHandler(RESTHandler):

    """ REST resource handlers

    Handles a REST request to a resource controlling a target

    """

    def __init__(self, route, target):
        """ Initialize a web module REST handler corresponding to a resource

        Args:
            route (str): The route for the handler (optional)
            target (Resource): A Resource object that the handler will manage

        Raises:
            TypeError: If an invalid target is specified
        """

        super().__init__(route)
        if not isinstance(target, Resource):
            raise TypeError("Invalid target resource provided")

        self._target = target

    def _get_command(self, id):
        for command in self._target.commands:
            if command.id == id:
                return command
        return None

    def _extract_req_param(self, req, param):
        """Retrieve a req param and remove it from params"""
        param_val = req.get_params().get(param)
        if param_val:
            del req.get_params()[param]
        return param_val

    def _update_req_for_delegation(self, req):
        """Updates a request object to be delegated to the next child.

        This moves all of the sub items up one level in the request params
        and also reassigns the identifier so it can be used by the next handler
        """
        item = self._extract_req_param(req, 'identifier')
        sub_item = self._extract_req_param(req, 'item_identifier')
        sub_sub_item = self._extract_req_param(req, 'command')

        req.set_identifier(sub_item)

        if sub_item:
            req.get_params()['identifier'] = sub_item

        if sub_sub_item:
            req.get_params()['item_identifier'] = sub_sub_item

    def _get_child_handler(self, child_id, req):
        """Get the resource's child handler based on a id, if it exists

        This will use `_find_child` to look for an item with the given
        id, and if it exists, return that item's proper handler.

        This method will also update the request object by moving each param
        up one level, before returning the child handler. Note that this will
        only happen if a child handler is going to be returned.

        Args:
            child_id (str): The id of the item to search for
            req (Request): The request object coming in

        Returns:
            handler (RESTResourceHandler): The handler for the item if it
                exists, None otherwise.
        """

        # avoid a call to find a child when there is None to be found.
        if child_id is not None:
            item = self._find_child(child_id)

            # If we have the item, make it's own handler and use that instead
            if item is not None:
                # Modify request identifier
                self._update_req_for_delegation(req)

                # Need to import here to prevent an import cycle
                from ..factory import RESTHandlerFactory
                return RESTHandlerFactory.create(item.id, item)

    def _find_child(self, child_id):
        """ Finds a child in target's collection

        Args:
            child_id (str): Child identifier which can refer either to an
                actual identifier or to a name

        Returns:
             child item if found None otherwise
        Raises:
            MultipleChoices: if multiple names matched
        """
        child = find(lambda c: c.id == child_id, self._target.children)
        if child:
            return child

        # lookup child using 'matched' which takes into account "name"
        found = list(filter(
            lambda c: c.matches(child_id), self._target.children))
        # handle multiple choices
        found_count = len(found)
        if found_count == 1:
            return found[0]
        elif found_count > 1:
            ids = [child.id for child in found]
            raise MultipleChoices(ids)

    def on_get(self, req, resp):
        identifier = req.get_identifier() or 'properties'

        if identifier == 'properties':
            self.on_get_properties(resp)
            return

        if identifier == 'commands':
            self.on_get_commands(resp)
            return

        # Verify if identifier is a command
        command = self._get_command(identifier)
        if command is not None:
            params = req.get_params()
            # First, remove the identifier param that we use
            if 'identifier' in params:
                del params['identifier']

            self.on_command(resp, command, params)
            return

        # Check in children
        if identifier is not None:
            item_handler = self._get_child_handler(identifier, req)

            if item_handler:
                return item_handler.on_get(req, resp)

        raise HTTPNotFound()

    def on_post(self, req, resp):
        """ Executes a POST operation on the resource """
        identifier = req.get_identifier()

        # Verify if identifier is a command
        command = self._get_command(req.get_identifier())
        if command is not None:
            self.on_command(resp, command, req.get_body())
            return

        # Check in children
        if identifier is not None:
            item_handler = self._get_child_handler(identifier, req)

            if item_handler:
                return item_handler.on_post(req, resp)

        raise HTTPNotFound()

    def on_put(self, req, resp):
        raise HTTPNotImplemented()

    def on_delete(self, req, resp):
        raise HTTPError(400, "Cannot delete a resource that does not"
                             " belong to a collection")

    def on_options(self, req, resp):
        resp.set_status(200)

    def on_command(self, resp, command, body):
        """ Execute the command and return the result.

        If the return value of the command is a dictionary, the result will
        be json encoded before displaying.
        """
        self.set_response_output(resp, command.execute(body))

    def on_get_properties(self, resp):
        """ Returns dictionary with properties of the resource
        """
        self.set_response_output(resp, self._target.properties)

    def on_get_commands(self, resp):
        """ Returns properties for all commands registered

        """
        commands = {}
        for command in self._target.commands:
            commands[command.id] = command.properties

        self.set_response_output(resp, commands)

    def set_response_output(self, resp, output, status=200):
        """ Sets a response object.

        This method will set the response content type.

        Args:
            resp (Response): The response to set
            output (any): What the output to the response should be. If it is
                a dictionary or list, it will be json.dumps'd
            status (int): Optional HTTP status to return, defaults to 200
        """
        resp.set_status(status)
        if isinstance(output, dict) or isinstance(output, list):
            resp.set_header('Content-Type', 'application/json')
            resp.set_body(json.dumps(output, indent=4,
                                     separators=(',', ': '),
                                     default=str))
        else:
            resp.set_body(output)
