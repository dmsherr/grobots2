from nio.modules.web import RESTHandler


class HttpErrorResourceHandler(RESTHandler):
    """ Handler for managing resources that are not accessible

     see (resource._cp_dispatch)

    """

    def __init__(self, route, error):
        super().__init__(route)
        self.error = error

    def on_get(self, req, resp):
        raise self.error

    def on_post(self, req, resp):
        raise self.error

    def on_put(self, req, resp):
        raise self.error

    def on_delete(self, req, resp):
        raise self.error
