"""

  REST Command handler

"""
from niocore.components.rest.handlers.resource import RESTResourceHandler


class RESTCommandHandler(RESTResourceHandler):
    """ REST handler for a command

    Handles REST requests targeting a command

    """

    def __init__(self, route, command):
        super().__init__(route, command)

    def on_get(self, req, resp):
        self.set_response_output(resp, self._target.execute(req.get_params()))

    def on_post(self, req, resp):
        self.set_response_output(resp, self._target.execute(req.get_body()))
