"""

  REST collection handler

"""
from niocore.core.api.collections.resource import ResourceCollection
from niocore.components.rest.handlers.resource import RESTResourceHandler
from nio.modules.web.http import HTTPNotFound, HTTPError
from nio.modules.security import Unauthorized
from niocore.util.attribute_dict import AttributeDict


class RESTResourceCollectionHandler(RESTResourceHandler):

    """ Handler for REST requests targeting a collection
    of resources

    """

    def __init__(self, route, collection):
        if not isinstance(collection, ResourceCollection):
            raise TypeError("Invalid target resource collection provided")

        super().__init__(route, collection)

    def is_collection(self):
        return True

    def on_get(self, req, resp):
        sub_item = self._get_child_handler(req.get_identifier(), req)
        if sub_item:
            return sub_item.on_get(req, resp)

        if req.get_identifier():
            # We must not have this item, otherwise the resource's on_get would
            # have been called directly
            raise HTTPNotFound()

        collection = self._target.fetch_all()

        # anything to filter on?
        items = self._filter(collection, req.get_params())

        self.set_response_output(resp, items)

    def on_post(self, req, resp):
        sub_item = self._get_child_handler(req.get_identifier(), req)
        if sub_item:
            return sub_item.on_post(req, resp)

        # A resource POST should not specify an ID to preserve idempotence
        # http://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html
        identifier = req.get_identifier()
        if identifier is not None and len(str(identifier)) > 0:
            raise HTTPError(400, "Don't specify endpoint on POST")

        # If we are here, we are posting to the collection directly, so we want
        # to add a resource
        self._add_resource(resp, self._parse_body(req.get_body()), None)

    def on_put(self, req, resp):
        identifier = req.get_identifier()
        if identifier is None:
            # attempt to update entire collection
            try:
                collection = self._target.update()
                # respond with collection items properties
                items = {item.id: item.properties for item in collection}
                self.set_response_output(resp, items)

            except AttributeError:
                # Trying to PUT to the collection directly...forbidden
                raise HTTPError(405, "Cannot update a collection directly")

        elif 'item_identifier' in req.get_params():
            # We should not be putting to a sub-resource
            raise HTTPError(405, "Cannot update a sub-resource")

        else:
            item = self._target.fetch(identifier)
            if item:
                # updating an existing item
                new_config = self._target.modify(
                    item, self._parse_body(req.get_body()))

                self.set_response_output(resp, new_config)
            else:
                # They are putting to a non-existent source...that's an add
                self._add_resource(
                    resp, self._parse_body(req.get_body()), identifier)

    def on_delete(self, req, resp):
        identifier = req.get_identifier()

        if 'item_identifier' in req.get_params():
            # We should not be deleting to a sub-resource
            raise HTTPError(405, "Cannot delete a sub-resource")

        item = self._target.fetch(identifier)
        if item:
            self._target.delete(item)
            # Set deleted status (no content returned)
            resp.set_status(204)
        elif identifier:
            raise HTTPNotFound()
        else:
            raise HTTPError(405, "Cannot delete a collection")

    def _find_child(self, id):
        return self._target.fetch(id)

    def _add_resource(self, resp, config, id=None):
        """Add a resource to the target collection

        Args:
            resp (Response): Response being prepared for this request
            config (AttributeDict): The configuration of the resource to add
            id (str): Optional. The id of the resource to add. If no id
                is specified, it will be inferred from the config
        Raises:
            ValueError: If an invalid configuration was passed
            HTTPError: If the add fails
        """
        if not isinstance(config, AttributeDict):
            raise ValueError("Invalid configuration")

        # Set the id to the config if it is specified
        if id is not None:
            config['id'] = id

        try:
            # Create the resource and then add it to the collection
            new_rsc = self._target.create(config)
            new_rsc_config = self._target.add(new_rsc)

            # Set the 201 Created status and output the resulting config
            self.set_response_output(resp, new_rsc_config, 201)

        except Unauthorized:
            raise
        except Exception as e:
            raise HTTPError(400, "Unable to add resource : %s" % e)

    def _parse_body(self, body):
        try:
            return AttributeDict(body)
        except:
            raise HTTPError(400, "Invalid HTTP body")

    def _filter(self, collection, conditions):
        """ Filters the items collection given a set of conditions

        Args:
            collection: items to filter
            conditions (dictionary): conditions to filter on with format:
                {property_name: property_value}

        Returns:
            Dictionary of items that satisfy conditions
        """
        if not conditions:
            # They didn't specify conditions, send back everything
            return {item.id: item.properties for item in collection}

        items_out = dict()
        for item in collection:

            # allow item to filter itself out or set a 'state' based on
            # conditions
            add_item = item.apply_url_params(**conditions)
            if not add_item:
                continue

            # cache item properties, making a call to retrieve properties
            # within a loop can be costly if having several conditions
            item_properties = item.properties
            for key in conditions:
                # if key is valid and condition is not satisfied, skip item
                if key in item_properties and \
                        not self._equals(item_properties.get(key),
                                         conditions[key]):
                    add_item = False
                    break
            if add_item:
                # make a last attempt to modify or filter out resource
                items_out[item.id] = item_properties
        return items_out

    def _equals(self, system_value, user_value):
        """ Finds out if two values match

        User value is tried to be converted to a bool or a number before
        comparing, if value is not possible to convert then it is compared
        for equality as is.

        Args:
            system_value: value as seen by the system
            user_value: value coming from the user and/or request

        Returns:
            True if items are "considered" equal, False otherwise
        """

        # attempt to convert to boolean
        if isinstance(user_value, str) \
                and user_value.lower() in ['true', 'yes', 'on']:
            user_value = True
        elif isinstance(user_value, str) \
                and user_value.lower() in ['false', 'no', 'off']:
            user_value = False
        # attempt to convert to number
        else:
            # try to convert to number
            try:
                user_value = float(user_value)
            except ValueError:
                pass

        return system_value == user_value
