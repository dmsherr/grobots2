"""

   Configuration Manager

"""
from nio.util.versioning.dependency import DependsOn
from nio import discoverable

from niocore.core.component import CoreComponent

from .handler import EnvHandler


@DependsOn('niocore.components.rest')
@discoverable
class EnvManager(CoreComponent):
    """ Handle environment variables read/write operations
    """

    _name = "EnvManager"

    def __init__(self):
        super().__init__()
        self._rest_manager = None
        self._handler = None

    def configure(self, context):
        """ Configures component

        Establish dependency to RESTManager
        Fetches settings and instantiates Handler

        Args:
            context (CoreContext): component initialization context

        """

        super().configure(context)

        # Register dependency to rest manager
        self._rest_manager = self.get_dependency('RESTManager')
        self.logger.info('REST Manager set to {}'.format(self._rest_manager))

        self._handler = EnvHandler()

    def start(self):
        """ Starts component

        Register a REST handler that handles env updates
        """
        super().start()
        self._rest_manager.add_web_handler(self._handler)

    def stop(self):
        """ Stops component
        """
        self._rest_manager.remove_web_handler(self._handler)
        super().stop()
