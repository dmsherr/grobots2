"""

   Env Handler

"""
import json

from nio.util.logging import get_nio_logger
from nio.modules.security.access import ensure_access
from nio.modules.web import RESTHandler
from niocore.util.environment import NIOEnvironment


class EnvHandler(RESTHandler):

    """ Handler for environment component
    """

    def __init__(self):
        super().__init__('/env')

        self.logger = get_nio_logger("EnvHandler")

    def on_get(self, request, response, *args, **kwargs):
        """ API endpoint to get nio env variables

        Example:
            http://[host]:[port]/env/
            http://[host]:[port]/env/[variable]

        """
        # Ensure instance "execute" access
        ensure_access("instance", "execute")

        params = request.get_params()
        self.logger.debug("on_get, params: {0}".format(params))

        name = params.get('identifier', '')

        if len(name):
            # handle a single environment variable
            value = NIOEnvironment.get_variable(name)

            if value is not None:
                response.set_body(value)
            else:
                self.logger.info(
                    "Variable name: {0} is not defined".format(name))
        else:
            # fetch all environment variables
            response.set_header('Content-Type', 'application/json')
            env_vars = NIOEnvironment.get_user_defined()
            response.set_body(json.dumps(env_vars))

    def on_post(self, request, response, *args, **kwargs):

        # Ensure instance "write" access in order to change env variables
        ensure_access("instance", "write")

        body = request.get_body()
        self.logger.info("EnvHandler.on_post, body: {}".
                         format(body))

        env_vars = NIOEnvironment.get_user_defined()

        save_variables = False
        for name, value in body.items():
            if name not in env_vars:
                env_vars[name] = value
                save_variables = True
            elif env_vars[name] != value:
                env_vars[name] = value
                save_variables = True

        if save_variables:
            NIOEnvironment.save_user_defined()
        
        response.set_header('Content-Type', 'application/json')
        response.set_body(
            json.dumps(NIOEnvironment.get_user_defined()))

    def on_put(self, request, response, *args, **kwargs):
        """
        Method to completely overwrite user_defined variables
        """
        ensure_access("instance", "write")

        body = request.get_body()
        self.logger.info("EnvHandler.on_put, body: {}".
                         format(body))

        env_vars = NIOEnvironment.get_user_defined()
        env_vars_keys = [name for name, value in env_vars.items()]

        save_variables = False
        for name, value in body.items():
            # add var from body into env_vars
            if name not in env_vars:
                env_vars[name] = value
                save_variables = True
            # modify existing env_var to value from body
            elif env_vars[name] != value:
                env_vars[name] = value
                save_variables = True

        # remove old keys from env_vars
        for name in env_vars_keys:
            if name not in body:
                del env_vars[name]
                save_variables = True

        if save_variables:
            NIOEnvironment.save_user_defined()
        
        response.set_header('Content-Type', 'application/json')
        response.set_body(
            json.dumps(NIOEnvironment.get_user_defined()))

    def on_delete(self, request, response, *args, **kwargs):

        # Ensure instance "write" access in order to change env variables
        ensure_access("instance", "write")

        params = request.get_params()
        self.logger.debug("on_delete, params: {0}".format(params))

        name = params.get('identifier', '')
        env_vars = NIOEnvironment.get_user_defined()

        if name in env_vars:
            del env_vars[name]
            NIOEnvironment.save_user_defined()
            response.set_body(
                json.dumps(NIOEnvironment.get_user_defined()))

        else:
            self.logger.info("Variable: {} is not defined".format(name))

