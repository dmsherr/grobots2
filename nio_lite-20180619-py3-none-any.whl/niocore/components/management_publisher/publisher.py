from nio.modules.communication.publisher import PublisherError, Publisher
from nio.signal.management import ManagementSignal
from nio import discoverable
from niocore.common.executable_request import ExecutableRequest
from niocore.core.component import CoreComponent
from niocore.core.hooks import CoreHooks
from niocore.core.service.context import RequestPoint
from nio.modules.settings import Settings
from niocore.util.environment import NIOEnvironment
from datetime import datetime

from .service import ServiceManagementPublisher
from . import __version__ as component_version


@discoverable
class ManagementPublisher(CoreComponent):

    """Publishes management information through a publisher channel

    Subscribes to core component hook service_status_change
    so that it can publish it through a channel.

    """

    _name = "ManagementPublisher"

    def __init__(self):
        super().__init__()
        self._publisher = None
        self._topic = None
        self._instance_id = None

    def get_version(self):
        return component_version

    def configure(self, context):
        """ Configures publisher

        Hooks to service status change event
        Reads configurable topic for "management" publisher

        Args:
            context (CoreContext): component initialization context

        """

        super().configure(context)
        CoreHooks.attach('service_status_change',
                         self._on_service_status_change)

        # populate instance id to send along with signals
        self._instance_id = NIOEnvironment.get_variable("INSTANCE_ID")

        self._topic = \
            Settings.get("management_publisher", "topic", fallback="management")
        if Settings.getboolean("management_publisher", "add_instance_id",
                               fallback=True):
            self._topic = "{}.{}".format(self._topic, self._instance_id)
        self._publisher = Publisher(self._topic)

    def prepare_context(self, context):
        """ Prepares a service init context adding management publisher
        information

        Args:
            context (ServiceContext): service initialization context
        """

        # register requests to execute
        context.requests.append(
            (RequestPoint.before_configure,
             ExecutableRequest(ServiceManagementPublisher,
                               "create_mgmt_publisher",
                               self._topic,
                               context)))

        context.requests.append(
            (RequestPoint.before_configure,
             ExecutableRequest(ServiceManagementPublisher,
                               "open_mgmt_publisher")))

        context.requests.append(
            (RequestPoint.before_stop,
             ExecutableRequest(ServiceManagementPublisher,
                               "close_mgmt_publisher")))

    def start(self):
        """ Opens publisher socket

        """
        super().start()
        self._publisher.open()

    def stop(self):
        """ Stops monitoring

        Detaches service status change hook
        Closes publisher

        """

        # do not receive anymore service status change notifications
        CoreHooks.detach('service_status_change',
                         self._on_service_status_change)

        # Assumes that after unhook operation, hook is not called again.
        self._publisher.close()
        super().stop()

    def _on_service_status_change(self, process, old_status, new_status):
        """ Service status change coming from a hook

        Args:
            process (ServiceProcess): Service process instance
            old_status: old service status
            new_status: new service status
        """
        self.logger.debug(
            "Service status change notification: {0}, "
            "old status: {1}, new status: {2}".format(
                process.service_info.id,
                old_status,
                new_status))
        # make sure it has not been closed, since these notifications are async
        # there is a chance for them to arrive after 'stop' call
        if not self._publisher.is_closed():
            # even after checking, there is a chance for another thread to close
            # the publisher before sending
            try:
                signal = ManagementSignal({
                    "type": "ServiceStatusChange",
                    "instance_id": self._instance_id,
                    "service": process.service_info.name,
                    "service_id": process.service_info.id,
                    "old_status": old_status.name,
                    "status": new_status.name,
                    "time": datetime.utcnow().timestamp()
                })
                self.logger.debug('Publishing Service Status signal: {0}'.
                                  format(signal.to_dict()))
                self._publisher.send(signal)
            except PublisherError:
                if not self._publisher.is_closed():
                    # if there is a publisher error, and it is not closed,
                    # re-raise
                    raise

    def get_order(self):
        # make it start,
        # 1) after communication module
        # 2) before service manager (so that it is ready when service status
        # change calls are received)
        return 30
