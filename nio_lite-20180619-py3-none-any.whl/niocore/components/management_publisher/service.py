from collections import Iterable
from nio.modules.communication.publisher import Publisher, PublisherError
from nio.util.logging import get_nio_logger


class ServiceManagementPublisher(object):

    """ Provides functionality to create, open and close a management
    publisher channel for a service

    Note that functionality is defined at class level.
    """

    _mgmt_publisher = None
    _mgmt_publisher_lock = None
    _prev_mgmt_signal_handler = None
    _logger_name = "ServiceManagementPublisher"

    @classmethod
    def create_mgmt_publisher(cls, topic, context):
        """ Initializes service management publisher functionality
        """
        cls._mgmt_publisher = Publisher(topic)

        # intercept context's management signal handler
        cls._prev_mgmt_signal_handler = context.mgmt_signal_handler
        context.mgmt_signal_handler = cls.notify_management_signals

    @classmethod
    def open_mgmt_publisher(cls):
        if not cls._mgmt_publisher:
            raise RuntimeError("Management publisher has not been created")

        get_nio_logger(cls._logger_name).debug('Opening publisher')
        cls._mgmt_publisher.open()

    @classmethod
    def close_mgmt_publisher(cls):
        if not cls._mgmt_publisher:
            raise RuntimeError("Management publisher has not been created")

        get_nio_logger(cls._logger_name).debug('Closing publisher')
        cls._mgmt_publisher.close()

    @classmethod
    def notify_management_signals(cls, signals):

        if not isinstance(signals, Iterable):
            signals = [signals]

        get_nio_logger(cls._logger_name).debug(
            'Publishing {} management signals'.format(len(signals)))
        if cls._mgmt_publisher:
            try:
                cls._mgmt_publisher.send(signals)
            except PublisherError:
                # Do no raise when there is an error publishing
                # in management publisher
                get_nio_logger(cls._logger_name).exception(
                    "Error publishing management signal")

        if cls._prev_mgmt_signal_handler:
            cls._prev_mgmt_signal_handler(signals)
