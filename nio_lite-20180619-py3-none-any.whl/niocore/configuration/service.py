from nio.util.versioning.check import compare_versions, VersionCheckResult
from niocore.configuration import Configuration


class ServiceConfiguration(Configuration):
    """ Allows the instantiation of a 'Configuration' for a Service
    """
    def __init__(self, id, is_collection=False, collection=None,
                 fetch_on_create=True, data=None, substitute=True):
        super().__init__(id, is_collection, collection,
                         fetch_on_create, data, substitute)

        # Begin backwards compatibility block.

        # Ensure backwards compatibility with service configurations that
        # don't have an 'id'
        if self.data and "id" not in self.data and "name" in self.data:
            self.data["id"] = self.data["name"]

        # Ensures backwards compatibility for legacy Services
        # that used 'name' for uniqueness
        for item in self.data.get('execution', []):
            if item and "id" not in item and "name" in item:
                item["id"] = item["name"]
                # remove no-longer-needed "name"
                del item["name"]

            # go through receivers
            if isinstance(item['receivers'], dict):
                for receivers in item['receivers'].values():
                    self._guarantee_id_existence(receivers)

        for item in self.data.get('mappings', []):
            if item and "id" not in item and "name" in item:
                item["id"] = item["name"]
                # remove no-longer-needed "name"
                del item["name"]

        # update version if older than 1.0.0
        if "version" in self.data and \
                compare_versions(self.data["version"], "1.0.0") == \
                VersionCheckResult.older:
            self.data["version"] = "1.0.0"
        # End backwards compatibility block

    def _guarantee_id_existence(self, item):
        for receiver in item:
            if isinstance(receiver, dict):
                # recipient has the format
                # {"name": [block_name], "input": [input]}
                if "id" not in receiver:
                    receiver["id"] = receiver["name"]
                    # remove no-longer-needed "name"
                    del receiver["name"]

    def get_block_ids(self):
        """ Parse execution finding out all blocks involved by id

        Returns:
            Set containing service's source block ids
        """

        # get unique set of blocks referenced in the service's execution
        block_ids = self.get_execution_ids()

        # convert mappings to source blocks
        for mapping in self.data.get('mappings', []):
            # For each mapping, remove the alias from the execution ids
            # but add the block it is mapped to
            if mapping['id'] in block_ids:
                block_ids.remove(mapping['id'])
            block_ids.add(mapping['mapping'])

        return block_ids

    def get_execution_ids(self):
        """ Parse execution finding out all blocks being executed in a service

        Returns:
            Set containing block to be executed in the service
        """

        # get unique set of blocks referenced in the service's execution
        execution_ids = set()
        for execution in self.data.get('execution', []):
            execution_ids.add(execution['id'])
            if isinstance(execution['receivers'], dict):
                for receivers in execution['receivers'].values():
                    execution_ids |= \
                        self._get_block_ids_from_receivers(receivers)
            else:
                execution_ids |= \
                    self._get_block_ids_from_receivers(
                        execution['receivers'])

        return execution_ids

    def get_source_block(self, block_id):
        """ Determine if a given block is a mapping or a source block

        Returns:
            Set containing block to be executed in the service
        """

        # set source block to be same in case it is not a mapping.
        source_block = block_id

        for mapping in self.data.get('mappings', []):
            if mapping['id'] == block_id:
                # block is actually a mapping
                source_block = mapping['mapping']
                break

        return source_block

    @staticmethod
    def _get_block_ids_from_receivers(receivers):
        block_ids = set()
        for receiver in receivers:
            if isinstance(receiver, dict):
                # recipient has the format
                # {"id": [block_id], "input": [input]}
                block_ids.add(receiver["id"])
            else:
                # receivers have the simple id format
                block_ids.add(receiver)
        return block_ids
