from niocore.configuration import Configuration


class BlockConfiguration(Configuration):
    """ Allows the instantiation of a 'Configuration' for a Block
    """
    def __init__(self, id, is_collection=False, collection=None,
                 fetch_on_create=True, data=None, substitute=True):
        super().__init__(id, is_collection, collection,
                         fetch_on_create, data, substitute)
        # ensure backwards compatibility with configurations that
        # don't have an 'id'
        if self.data and "id" not in self.data and "name" in self.data:
            self.data["id"] = self.data["name"]
