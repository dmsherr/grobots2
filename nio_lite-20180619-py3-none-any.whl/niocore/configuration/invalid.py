from niocore.configuration import Configuration


class InvalidConfiguration(Configuration):
    pass
