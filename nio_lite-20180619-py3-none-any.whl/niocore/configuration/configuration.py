"""

Defines the Configuration class and system-wide configuration components.

"""
from enum import Enum, unique

from nio.modules.persistence import Persistence
from niocore.util.attribute_dict import AttributeDict
from niocore.util.environment import NIOEnvironment


@unique
class CfgType(Enum):

    """ Configuration types
    """
    block = 1
    service = 2
    all = 3


class ConfigurationError(Exception):
    pass


class Configuration(object):

    """ A configuration class used to handle nio project configurations.

    This class provides functionality to load, save and remove configurations,
    data within a configuration can reference NIO environment variables.

    Makes use of NIO's persistence module to load and save configuration data.
    """

    def __init__(self, id, is_collection=False, collection=None,
                 fetch_on_create=True, data=None, substitute=True):
        """Create a new configuration object

        Args:
            id (str): The id of the configuration to reference

        Keyword Args:
            is_collection (bool): specifies if instance is a collection holder
            collection (str): id of the collection instance is part of if any
            fetch_on_create (bool): Whether or not to fetch the configuration
                when the class is instantiated. Defaults to False.
            data (dict): actual configuration data.
            substitute (bool): if True environment variables are replaced with
                its values
        """
        self._id = id
        self._is_collection = is_collection
        self._collection = collection
        self._read_only = False

        # hold actual configuration data as an AttributeDict
        self._data = AttributeDict(data) \
            if data is not None else AttributeDict()

        self._persistence = Persistence()
        if fetch_on_create:
            # substitute parameter needs to be carried over, fetch in turn
            # might create Configurations itself
            self.fetch(substitute)
        if substitute:
            self.substitute()

    def substitute(self):
        """Substitute this dictionary with the values of its environment
        variables.


        Note: This will put this Configuration object into read-only mode.
        Therefore, after substituting you will not be able to save the config.
        If you wish to save, make a deepcopy of the config before substitution.

        Returns:
            None: The substitution will occur in place
        """
        self._read_only = True
        NIOEnvironment.substitute_env_vars(self.data, in_place=True)

    def fetch(self, substitute=True):
        """Fetch the configuration details.

        This method will re-sync the state of this configuration object
        with the source where it was loaded.
        """

        if self._is_collection:
            data = self._persistence.load_collection(self.id, default={})
            for persist_id, config_data in data.items():
                # (begin backwards compatibility)
                # if loading a collection saved under old-id convention,
                # replace it with new convention
                intended_persist_id = self._get_persist_id(config_data)
                # if not saved using persistence_id, remove old and save it
                # under intended id
                if persist_id != intended_persist_id:
                    # remove old persisted file
                    self._persistence.remove(persist_id, self.id)
                    # save it under intended id
                    self._persistence.save(
                        config_data, intended_persist_id, self.id)
                # (end backwards compatibility)

                # use id if available otherwise stay with existing
                _id = config_data["id"] if "id" in config_data else persist_id
                child_config = self.get_config_class()(
                    _id,
                    collection=self.id,
                    fetch_on_create=False,
                    data=config_data,
                    substitute=substitute)
                self.add(_id, child_config)
        else:
            self._data = \
                AttributeDict(self._persistence.load(self.id, default={}))

    def add(self, id, val):
        """Add an object to the configuration.

        This will add an object and register the object with the configuration
        provider. This method only needs to be called when the configuration
        object contains child configuration objects. Otherwise, the normal
        dictionary syntax should be useable.

        Args:
            id (str): The id of the configuration to be referenced as a key
            val (Configuration): A child configuration to register with the
                configuration provider

        Raises:
            TypeError: If the configuration cannot be added or registered with
                the configuration provider
        """
        if not isinstance(val, Configuration):
            raise TypeError("Only configuration-type instances are allowed "
                            "to be added to a Configuration")

        if not self._is_collection:
            raise TypeError("Cannot register a configuration to a "
                            "non-collection-type configuration")

        self.data[id] = val

    def save(self):
        """Save the configuration details.

        This method assumes the configuration being saved belongs
        to a collection

        Raises:
            ConfigurationError: On any attempt to save a readonly config
        """
        if self.read_only:
            raise ConfigurationError("Attempt to write to readonly config")

        if self._is_collection:
            # build a serializable collection out of config instances
            serializable_collection = \
                {self._get_persist_id(item.data): item.data
                 for _id, item in self.data.items()}
            self._persistence.save_collection(
                serializable_collection, collection=self.id)
        elif self._collection:
            self._persistence.save(self.data,
                                   self._get_persist_id(self.data),
                                   collection=self._collection)
        else:
            self._persistence.save(self.data,
                                   self.id)

    def remove(self, id):
        """Remove a configuration object

        This method assumes the configuration object to remove belongs
        to a collection and 'id' is the id of the child configuration

        Args:
            id (str): Child configuration to remove.
        """

        if self._is_collection:
            # removing an item belonging to this collection
            self._persistence.remove(self._get_persist_id(self.data[id].data),
                                     collection=self.id)
            # remove child from dictionary collection
            del self.data[id]

    def clear(self):
        """ Clears data associated with a Configuration
        """
        if self._is_collection:
            self._persistence.remove_collection(self.id)
        self.data = AttributeDict()

    def get_children(self):
        """ Returns list of children entries for a given configuration
        """
        return self.data.keys()

    @property
    def read_only(self):
        """ Returns True if configuration is read only

        Note: A configuration can become read only after a variable substitution
        """
        return self._read_only

    @property
    def id(self):
        """ Provides access to configuration id
        """
        return self._id

    @property
    def data(self):
        """ Provides access to actual configuration data
        """
        return self._data

    @data.setter
    def data(self, data):
        self._data = data

    def get_config_class(self):
        """ Provide same class type by default
        """
        return self.__class__

    def _get_persist_id(self, config):
        """ Figure out id to save under given an item belonging to a collection

        Args:
            config (dict): configuration data

        This is applicable to block and service configs.

        Note: An item would normally be saved under its id, however, it has
        proved to be inadequate since it is hard to read, therefore, a
        friendlier 'id' is calculated taking into account additional properties
        like 'type' and 'name'
        """
        if ("name" in config and "type" in config and "id" in config) \
                and not config["name"]:
            return self._make_name(
                "{}__{}".format(config["type"], config["id"]))
        elif "name" in config \
                and ("id" not in config or config["name"] == config["id"]):
            # handling v2 configs...
            # leave configs that have no 'id' or considered
            # 'name' to be the 'id' as is
            return self._make_name(config["name"])
        elif "name" in config and "id" in config:
            return self._make_name(
                "{}__{}".format(config["name"], config["id"]))
        elif "id" in config:
            return self._make_name(config["id"])
        raise ValueError("Invalid block or service configuration, {}".
                         format(config))

    @staticmethod
    def _make_name(name_in):
        """ Strips a string of unwanted chars.
        """
        # Allow alphanum chars, dots, underscores and dashes
        return "".join(x for x in name_in if (x.isalnum() or x in "._-"))
