import json
from configparser import RawConfigParser as ConfigParser, \
    NoSectionError, NoOptionError

from nio.modules.persistence import Persistence
from nio.modules.proxy import ProxyNotProxied
from niocore.util.attribute_dict import enforce_attr_dict
from nio.util.codec import load_json
from niocore.util.environment import NIOEnvironment


class SectionNotAvailable(Exception):
    pass


class Settings(object):

    """ Class to retrieve settings through Persistence and/or ConfigParser

    Initial settings to initialize Persistence are read through the use
    of the ConfigParser reading a windows-ini like file.

    When first attempting to retrieve a given setting, it is tried through
    persistence first, if the given section has no entry or is not defined
    under persistence, then setting is attempted to be retrieved through the
    use of the ConfigParser read information.

    Understanding Persistence calls to retrieve Settings

        - The reading of a settings section is achieved by loading a
          persistence item (persistence.load)

        - A settings call like: Settings.get(<section>, <option>) translates to:
          persistence.load(<section>, 'conf') and then retrieving <option> from
          the loaded-from-persistence dictionary

        A settings ini section when using file persistence is mapped as follows:

        proj/<persistence_directory>/conf/<section>.cfg
        {
            <option>: <option_value>,
            ...
        }

        For example a call like:

        Settings.getdict("logging", "conf") maps to:

        proj/etc/conf/logging.cfg
        {
           "conf": {
               "loggers": ...
           }
        }

        A settings ini section when using redis persistence is mapped as
        follows:
        redis://<ID>_conf/<section>
    """

    _parser_settings = ConfigParser()
    # persistence collection is set during module initialization
    _persistence_collection = None
    _persistence_settings = {}
    _persistence = None

    @classmethod
    def get(cls, section=None, option=None, **kwargs):
        """Accessor for settings.

        Args:
            section (str): section to get information from
            option (str): option to get information from

        Keyword Args:
            fallback: default to use when no information can be found

        Returns:
            settings: The requested settings or
                None if no possible value was found
        """
        try:
            return cls._read_from_persistence(section, option, **kwargs)
        except (NotImplementedError, ProxyNotProxied, SectionNotAvailable):
            return cls._cf_get(section, option, **kwargs)

    @classmethod
    def getint(cls, section, option, **kwargs):
        # a convenience method converting section value to an integer
        value = cls.get(section, option, **kwargs)
        if value is not None:
            return int(value)

    @classmethod
    def getfloat(cls, section, option, **kwargs):
        # a convenience method converting section value to a float
        value = cls.get(section, option, **kwargs)
        if value is not None:
            return float(value)

    @classmethod
    def getboolean(cls, section, option, **kwargs):
        # a convenience method converting section value to a boolean
        value = cls.get(section, option, **kwargs)
        if value is not None:
            return cls._convert_to_boolean(value)

    @classmethod
    def getdict(cls, section, option, **kwargs):
        # Reads option and converts to dict if value is a string
        value = cls.get(section, option, **kwargs)

        if isinstance(value, str):
            try:
                # interpret str as a json-serialized dict
                value = json.loads(value)
                NIOEnvironment.substitute_env_vars(value, in_place=True)
            except:
                # interpret string as a link to a file
                value = load_json(NIOEnvironment.get_path(value))
                NIOEnvironment.substitute_env_vars(value, in_place=True)

        return value

    # PERSISTENCE READING
    @classmethod
    def _get_persisted_section(cls, section):

        # if section has been read already use it as a cache
        if section in cls._persistence_settings:
            return cls._persistence_settings[section]

        # guarantee access to persistence instance
        if not cls._persistence:
            cls._persistence = Persistence()

        # load section and substitute any env vars
        section_settings = cls._persistence.load(
            section, collection=cls._persistence_collection)
        return section_settings

    @classmethod
    def _read_from_persistence(cls, section, option, **kwargs):
        # when persistence is not ready, let the exception propagate to caller
        p_section = cls._get_persisted_section(section)

        if p_section is None:
            # causing reading from configparser or getting fallback through it
            raise SectionNotAvailable()

        # if no option is specified, provide whole section
        if option is None:
            return p_section

        # figure default value if provided
        value = kwargs.get("fallback", None)

        # get option and provide a default value if it doesn't exist
        value = p_section.get(option, value)

        return NIOEnvironment.substitute_env_vars(value, False)

    @classmethod
    def _convert_to_boolean(cls, value):
        """Return a boolean value translating from other types if necessary.
        """
        if isinstance(value, str):
            if value.lower() not in ConfigParser.BOOLEAN_STATES:
                raise ValueError('Not a boolean: %s' % value)
            return ConfigParser.BOOLEAN_STATES[value.lower()]
        return bool(value)

    # CONFIG PARSER READING
    @classmethod
    def _cf_get(cls, section=None, option=None, **kwargs):
        """Accessor for settings.

        Args:
            section (str): section to get information from
            option (str): option to get information from

        if no section is specified, all sections are returned
        if no option is specified, all options within given section are returned

        Keyword Args:
            fallback: default to use when no information can be found

        Returns:
            settings: The requested settings or
                None if no possible value was found
        """
        if section is None:
            result = {}
            for section in cls._parser_settings.sections():
                result[section] = cls._get_section(section)
        elif option is None:
            try:
                result = cls._get_section(section)
            except NoSectionError:
                result = kwargs.get("fallback", None)
        else:
            try:
                result = cls._parser_settings.get(section, option, **kwargs)
            except (NoSectionError, NoOptionError):
                result = kwargs.get("fallback", None)

        result = NIOEnvironment.substitute_env_vars(result, False)
        return enforce_attr_dict(result)

    @classmethod
    def set(cls, section, option=None, value=None):
        """ Sets the value for a given section and option

        if the section does not exists, it creates it
        if option is not specified, value is assigned to the section and it
            must be a dictionary type

        Args:
            section (str): section to set information to
            option (str): option to set information to
            value: value to assign

        Raises:
            TypeError if value is invalid
        """
        if section not in cls._parser_settings.sections():
            cls._parser_settings[section] = {}
        if option is None:
            if not isinstance(value, dict):
                raise TypeError("When assigning to a section, value must be a "
                                "dictionary type")
            cls._parser_settings[section] = value
        else:
            cls._parser_settings.set(section, option, value)

    @classmethod
    def update(cls, section, configuration):
        """Add a dictionary containing configuration information to the
        settings at runtime.

        Args:
            section (str): The desired entry from 'configuration'
            configuration (Configuration): The configuration to be added

        """

        section_value = cls.get(section, fallback={})
        section_value.update(configuration)
        cls._parser_settings[section] = section_value

    @classmethod
    def import_files(cls, filenames):
        """Generate the settings based on the contents of
        config files (Python 'ini' style)

        Args:
            filenames (list): absolute paths to the config files

        """
        # keep case sensitivity
        cls._parser_settings.optionxform = str

        # read each file in given order
        for filename in filenames:
            cls._parser_settings.read(filename)

    @classmethod
    def clear(cls):
        """ Initialize setting holders.

        This is mostly useful in testing to start with a clean slate.
        """
        cls._parser_settings = ConfigParser()
        cls._persistence_settings = {}

    @classmethod
    def _get_section(cls, section):
        """ Gathers all option values for a given section

        Args:
            section (str): section to get values from

        Returns:
            section (dict): all section options

        """
        result = {}
        for option in cls._parser_settings.options(section):
            result[option] = cls._parser_settings.get(section, option)

        return result
