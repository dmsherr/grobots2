from nio.modules.context import ModuleContext
from nio.modules.settings.module import SettingsModule
from niocore.modules.settings.ini.settings import Settings
from niocore.util.environment import NIOEnvironment
from nio import discoverable


@discoverable
class SettingsIniModule(SettingsModule):

    def initialize(self, context):
        super().initialize(context)
        self._in_service = context.in_service
        if not context.in_service:
            # activate Settings only when running within core
            self.proxy_settings_class(Settings)
            conf_files = NIOEnvironment.get_conf_files()
            Settings.import_files(conf_files)
            # set collection to save to when using persistence
            Settings._persistence_collection = \
                Settings.get('persistence', 'collection', fallback='conf')
        else:
            # Don't proxy Settings, we want NotImplementedError to be raised
            # inside the service process
            pass

    def finalize(self):
        if not self._in_service:
            super().finalize()

    def prepare_core_context(self):
        context = ModuleContext()
        context.in_service = False
        return context

    def prepare_service_context(self, service_context=None):
        context = ModuleContext()
        context.in_service = True
        return context
