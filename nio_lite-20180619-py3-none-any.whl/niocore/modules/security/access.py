"""

    API Security

    Provides security utility methods

"""


def compose_resource(*resource_parts):
    """ Composes an arbitrary number of resource parts into one resource

    This is a utility allowing to have a single point for resource composition.

    Args:
        resource_parts (string): resource parts that will compose a resource

    Returns:
        resource (string)
    """
    return ".".join(resource_parts)
