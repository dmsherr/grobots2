from nio import discoverable
from nio.modules.context import ModuleContext
from nio.modules.scheduler.module import SchedulerModule
from nio.modules.settings import Settings
from nio.util.scheduler.job import Job
from nio.util.scheduler.scheduler import Scheduler


@discoverable
class CustomSchedulerModule(SchedulerModule):

    def initialize(self, context):
        super().initialize(context)
        self.proxy_job_class(Job)

        Scheduler.do_configure(context)
        Scheduler.do_start()

    def finalize(self):
        Scheduler.do_stop()
        super().finalize()

    def _prepare_common_context(self):
        context = ModuleContext()

        context.min_interval = \
            Settings.getfloat('scheduler', 'min_interval', fallback=0.1)
        context.resolution = \
            Settings.getfloat('scheduler', 'resolution', fallback=0.1)

        return context

    def prepare_core_context(self):
        return self._prepare_common_context()

    def prepare_service_context(self, service_context=None):
        return self._prepare_common_context()
