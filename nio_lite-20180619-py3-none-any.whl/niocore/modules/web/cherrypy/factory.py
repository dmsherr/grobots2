"""

 Cherrypy Handler factory

"""
from nio.modules.web import RESTHandler, WebHandler
from niocore.modules.web.cherrypy.collection import CherryPyRESTCollectionHandler
from niocore.modules.web.cherrypy.handler import CherryPyWebHandler
from niocore.modules.web.cherrypy.rest import CherryPyRESTHandler


class CPHandlerFactory(object):
    """ Factory for creating CP handlers based on NIO handlers

    """
    def get(self, handler):
        cp_handler = None

        if isinstance(handler, RESTHandler):
            if handler.is_collection():
                cp_handler = CherryPyRESTCollectionHandler(handler)
            else:
                cp_handler = CherryPyRESTHandler(handler)
        elif isinstance(handler, WebHandler):
            cp_handler = CherryPyWebHandler(handler)

        return cp_handler
