"""

    REST Collection Handler

"""
from niocore.modules.web.cherrypy.rest import CherryPyRESTHandler


class CherryPyRESTCollectionHandler(CherryPyRESTHandler):

    def set_route(self, mapper):
        super().set_route(mapper)
        # TODO: Add explicit name to route
        mapper.connect(
            self.get_route_name("_item"),
            self.build_route("/:identifier/:item_identifier"),
            controller=self,
            action="index_id",
            item_identifier=None)

        # Items in a collection can be commanded too
        mapper.connect(
            self.get_route_name("_command"),
            self.build_route("/:identifier/:item_identifier/:command"),
            controller=self,
            action="index_id",
            item_identifier=None,
            command=None)
