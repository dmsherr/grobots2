"""

    REST Web Handler

"""
import cherrypy
from niocore.modules.web.cherrypy.handler import CherryPyWebHandler
from cherrypy._cperror import HTTPError as CPHTTPError
from nio.util.logging import get_nio_logger

class CherryPyRESTHandler(CherryPyWebHandler):
    """ CherryPy REST handler that wraps a RESTHandler class """

    def __init__(self, handler):
        super().__init__(handler)

    def build_route(self, route):
        """Build route

        Return:
            String of the route
        """

        route_full = self._handler.route + route
        return route_full.replace('//', '/')

    def set_route(self, mapper):
        """Set route

        Args:
            mapper: Mapper object
        """

        # Parent
        super().set_route(mapper)

        # Set map
        # TODO: Add explicit name to route
        mapper.connect(self.get_route_name("_id"),
                       self.build_route("/:identifier"),
                       controller=self,
                       action="index_id")

    def index_id(self, identifier, *args, **kwargs):
        """Main handler for all requests, passes on to handlers"""

        # Method
        method = cherrypy.request.method.lower()

        # TRACE and PATCH just not supported. prevent from 500
        if method in ["trace", "patch"]:

            # -- Log
            get_nio_logger("WebHandler").exception(
                "Not Implemented: {0}".format(method))

            # -- HTTP error
            raise CPHTTPError(501, message="Method not implemented.")

        return self._call_handler('on_' + method)
