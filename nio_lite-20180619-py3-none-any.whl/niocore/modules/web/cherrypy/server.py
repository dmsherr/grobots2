"""

  CherryPy Web Server

"""
from cherrypy._cpserver import Server
from cherrypy._cptree import Tree

from nio.util.logging import get_nio_logger
from nio.modules.web import StaticHandler, WebEngine
from niocore.modules.web.cherrypy.factory import CPHandlerFactory
from .routes_dispatcher import NIORoutesDispatcher


class CPWebServer(object):

    """ Web Server

    Serves HTTP requests in a host, port specified
    """

    def __init__(self, port, host="127.0.0.1", server_conf=None):
        self._name = CPWebServer.build_name(host, port)
        self._app = None
        self._mounted_app = None
        self._static_dir = None
        config = server_conf or {}
        config['host'] = host or "127.0.0.1"
        config['port'] = port
        self.logger = get_nio_logger('WebServer')
        self._mapper = NIORoutesDispatcher()
        self._static_dirs = {}
        self._factory = CPHandlerFactory()
        # Configure server as last action
        self._server = self._configure_server(config)

    @staticmethod
    def build_name(host, port):
        return "{0}:{1}".format(host, port)

    @property
    def name(self):
        return self._name

    @property
    def server(self):
        return self._server

    @property
    def host(self):
        return self._server.socket_host

    @property
    def port(self):
        return self._server.socket_port

    def _configure_server(self, server_conf):
        server = Server()

        host = server_conf.get('host')
        port = int(server_conf.get('port'))

        server.bind_addr = (host, port)
        server.httpserver, server.bind_addr = server.httpserver_from_self()
        server.httpserver.wsgi_app = Tree()
        self.logger.info('Server configured on %s:%s' % (host, port))

        # handle ssl configuration if any
        ssl_cert = server_conf["ssl_certificate"] \
            if "ssl_certificate" in server_conf and \
               len(server_conf["ssl_certificate"]) else None

        ssl_key = server_conf["ssl_private_key"] \
            if "ssl_private_key" in server_conf and \
               len(server_conf["ssl_private_key"]) else None

        ssl_cert_chain = server_conf["ssl_certificate_chain"] \
            if "ssl_certificate_chain" in server_conf and \
               len(server_conf["ssl_certificate_chain"]) else None

        if ssl_cert and ssl_key:
            from cheroot.ssl.builtin import BuiltinSSLAdapter

            server.httpserver.ssl_adapter = \
                BuiltinSSLAdapter(ssl_cert, ssl_key, ssl_cert_chain)

        self._static_dir = server_conf.get("static.dir", None)

        return server

    def add_handler(self, handler):
        """ Adds a handler """

        if isinstance(handler, StaticHandler):
            route = handler.route[1:] if handler.route.startswith('/') else \
                handler.route
            static_cfg = {
                "tools.staticdir.root": self._static_dir,
                "tools.staticdir.on": True,
                "tools.staticdir.dir": route
            }
            self._static_dirs[handler.route] = static_cfg

        # create CP handler
        cp_handler = self._factory.get(handler)
        if not cp_handler:
            self.logger.error(
                "Handler {0} is not a valid WebHandler".format(handler))
            return

        # Set router details
        cp_handler.set_route(self._mapper)

    def remove_handler(self, handler):
        pass

    def start(self, module_conf=None):
        if module_conf is None:
            # Retrieve Global config
            module_conf = dict(list(WebEngine.config['/'].items()) +
                               list(WebEngine.config['global'].items()))

        # Replace request.dispatch
        module_conf["request.dispatch"] = self._mapper

        # Create app configuration
        config = {'/': module_conf}
        if self._static_dirs:
            config = dict(list(config.items()) +
                          list(self._static_dirs.items()))

        self._mounted_app = \
            self._server.httpserver.wsgi_app.mount(None,
                                                   script_name="",
                                                   config=config)

        # set cherrypy access_log level from configuration.
        # NOTE: All servers will share same log settings
        self._mounted_app.log.error_log = get_nio_logger('cherrypy')
        self._mounted_app.log.access_log = get_nio_logger('cherrypy.access')

        self._server.subscribe()
        self.logger.debug(self._mapper.mapper)

        self.logger.info('Starting server on %s:%s' % (self.host,
                                                       self.port))
        self._server.start()
        self.logger.info('Server %s started on %s:%s' % (self.name,
                                                         self.host,
                                                         self.port))

        # Start the engine as soon as a web server starts
        if not WebEngine.is_started():
            WebEngine.start()
            self.logger.info('Web engine started')

    def stop(self):
        self._server.stop()
        self._server.unsubscribe()
        self.logger.info('Server %s stopped' % self.name)
