"""

  Web Handler

"""
import cherrypy
from cherrypy._cperror import HTTPError as CPHTTPError
from nio import __version__ as nio_version
from nio.modules.security import Unauthorized
from nio.modules.web.http import HTTPUnauthorized, HTTPError
from nio.modules.web.request import Request
from nio.modules.web.response import Response
from nio.util.logging import get_nio_logger
from niocore import __binary_build__ as nio_binary_build
from niocore.util.exceptions import MultipleChoices


class CherryPyWebHandler(object):
    """ CherryPy Web Handler that wraps a WebHandler class """

    # Init
    def __init__(self, handler):
        self._handler = handler

    def get_route_name(self, suffix=None):
        """Get Route name

        Args:
            suffix: Suffix to add

        Returns:
            String of route
        """

        name = self._handler.route[1:] or 'default'
        return name + suffix if suffix else name

    def set_route(self, mapper):
        """Set route

        Args:
            mapper: Mapper object
        """

        # TODO: Add explicit name to route
        mapper.connect(self.get_route_name(),
                       self._handler.route,
                       controller=self,
                       action="index")

    def index(self, *args, **kwargs):
        """Index handler that handles all requests first"""

        return self._call_handler('on_' + cherrypy.request.method.lower())

    def _call_handler(self, handler_func, *args, **kwargs):
        """Call the handler

        Returns:
            Result from the callback
        """

        handler_callback = getattr(self._handler, handler_func)
        return self._do_callback(handler_callback, *args, **kwargs)


    def _do_callback(self, handler_callback, *args, **kwargs):
        """Handle callback of actual response

        Returns:
            Bytes as CherryPy expects
        """

        # Make request and response
        request = Request(cherrypy.request)
        response = Response()

        try:

            # -- Invoke overrideable-before_handler method, which provides
            # authentication by default in the framework
            self._handler.before_handler(request, response)
            # -- Handle callback
            handler_callback(request, response, *args, **kwargs)

        # MultipleChoices
        except MultipleChoices as e:
            response.set_status(300)
            response.set_body(
                "Resource could not be uniquely identified, unique choices "
                "are: {}".format(e.choices))

        # Unauthorized
        except Unauthorized:

            # -- Exception
            e = HTTPUnauthorized()

            # -- Log
            get_nio_logger("WebHandler").exception("Unauthorized Error")

            # -- HTTP error
            raise CPHTTPError(e.status, e.message)

        # HTTP error
        except HTTPError as e:

            # -- Log
            get_nio_logger("WebHandler").exception("HTTP Error")

            # -- HTTP error
            raise CPHTTPError(e.status, e.message)

        # Value Error
        except (ValueError, TypeError) as e:

            # -- Log
            get_nio_logger("WebHandler").exception("Value Error")

            # -- HTTP error
            raise CPHTTPError(400, message=str(e))

        # Not implemented error
        except NotImplementedError as e:

            # -- Log
            get_nio_logger("WebHandler").exception("Not Implemented")

            # -- HTTP error
            raise CPHTTPError(501, message=str(e))

        # Exception
        except Exception as e:

            # -- Log
            get_nio_logger("WebHandler").exception("Exception")

            # -- HTTP error
            raise CPHTTPError(message=str(e))

        # Finally
        finally:

            # -- Process request after being handled
            self._after_handler(request, response)

        # Render body in bytes
        return bytes(response.get_output_body(), 'utf-8')

    def _after_handler(self, request, response):
        """ Provides request processing after request handler was invoked
        """

        # -- Invoke overrideable-after_handler method
        self._handler.after_handler(request, response)

        # -- Add headers for all responses
        # Set status and headers when there is an exception too!
        # Grab the status and headers from the Response object
        # and set them to this thread's cherrypy.response
        cherrypy.response.status = response.get_status()
        for name, val in response.get_headers().items():
            cherrypy.response.headers[name] = val
