'''

    NIO Routes Dispatcher

'''
from cherrypy._cpdispatch import RoutesDispatcher


class NIORoutesDispatcher(RoutesDispatcher):

    """ Custom route dispatcher to allow presence of trailing slash
    in NIO API calls.

    """

    def __call__(self, path_info):

        # strip the trailing slash
        path_info = path_info.rstrip('/') or '/'

        # make the call
        super().__call__(path_info)
