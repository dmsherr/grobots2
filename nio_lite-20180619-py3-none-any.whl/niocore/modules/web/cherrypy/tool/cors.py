import cherrypy


class CORSTool(cherrypy.Tool):
    """ This tool adds CORS headers to every web response (even errors)
    """
    def __init__(self, point, allow_origin, allow_methods, allow_headers,
                 allow_credentials):
        """ Allows to initialize tool.

        Saves headers to be sent along with each response

        Args:
            point: specifies when, during request handling,
                the headers are added (before_handler is recommended)
            allow_origin: header to use for allow_origin
            allow_methods: header to use for allow_methods
            allow_origin: header to use for allow_origin
            allow_credentials: header to use for allow_credentials

        """
        super().__init__(point, self.set_headers)
        self._allow_origin = allow_origin
        self._allow_methods = allow_methods
        self._allow_headers = allow_headers
        self._allow_credentials = allow_credentials

    def set_headers(self):
        """ Method called from the cherrypy framework for every response
        """
        cherrypy.response.headers["Access-Control-Allow-Origin"] = \
            self._allow_origin
        cherrypy.response.headers["Access-Control-Allow-Methods"] = \
            self._allow_methods
        cherrypy.response.headers["Access-Control-Allow-Headers"] = \
            self._allow_headers
        cherrypy.response.headers["Access-Control-Allow-Credentials"] = \
            self._allow_credentials
