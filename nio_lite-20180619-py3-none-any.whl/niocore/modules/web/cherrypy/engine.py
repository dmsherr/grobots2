"""
  Cherrypy Web Engine

"""
import cherrypy
import json
from nio.modules.web import WebEngine as WebEngineIface
from nio.modules.web import WebServer
from nio.util.logging import get_nio_logger
from niocore.modules.web.cherrypy.tool.cors import CORSTool


def error_page(status, message, traceback, version):
    """Custom error page"""
    response = cherrypy.response
    response.headers['Content-Type'] = 'application/json'
    return json.dumps({
        'status': status,
        'status_code': response.status,
        'message': message,
    })


class WebEngine(object):

    """ Cherrypy Web Engine implementation

    """
    # Web Engine configuration
    config = {}
    _mapper = None

    servers = {}

    @classmethod
    def add_server(cls, port, host="127.0.0.1", configuration=None):
        """ Instantiates a web server

        Args:
            port (int): Port listening for requests
            host (str): Web server host address.
            configuration (dict): Contains additional server configuration,
                might contain additional ssl settings such as:
                ssl_certificate, ssl_private_key, ssl_certificate_chain

        Returns:
            The server if it already exists, or a new instantiated server

        Raises:
            TypeError: if port is None

        """

        if port is None:
            raise TypeError("Port cannot be None")

        # Check if server was already created
        name = WebServer.build_name(host, port)

        web_server = WebEngineIface.servers.get(name)
        if web_server is not None:
            get_nio_logger('WebEngine').info(
                "{0} web server already exists".format(name))
            return web_server

        web_server = WebServer(port, host, configuration)
        WebEngineIface.servers[name] = web_server
        return web_server

    @classmethod
    def remove_server(cls, server):
        if server is not None:
            server.stop()
            if server.name in WebEngineIface.servers:
                del WebEngineIface.servers[server.name]
            else:
                get_nio_logger('WebEngine').warning(
                    '{0} web server is not registered'.format(server.name))

    @classmethod
    def configure(cls, context):
        """ Configure Web Server

        Args:
            context: module context

        """
        WebEngineIface.config = {
            "global": {
                "server.thread_pool": context.server_thread_pool,
                "tools.CORS.on": True
            },
            "/": {"request.show_tracebacks": context.request_show_tracebacks},
        }
        cherrypy.config.update(WebEngineIface.config)

        # Custom error response, returns JSON instead of CherryPy's HTML
        cherrypy.config.update({"error_page.default": error_page})

        # Configure cherrypy logs
        WebEngineIface._configure_cherrypy_logs()

        # since CORS headers are set before actual handler is called,
        # they can be overriden within a handler if desired
        cherrypy.tools.CORS = CORSTool('before_handler',
                                       context.cors_allow_origin,
                                       context.cors_allow_methods,
                                       context.cors_allow_headers,
                                       context.cors_allow_credentials)

    @classmethod
    def start(cls):
        """ Starts Web Server using configured params

        """
        if WebEngineIface.is_started():
            get_nio_logger('WebEngine').info(
                "CherryPy Engine is started or starting. Ignoring...")
            return

        # unsubscribe cherrypy.web_server as we are only using WSGI servers
        cherrypy.server.unsubscribe()

        cherrypy.config.update({'engine.autoreload.on': False})
        cherrypy.engine.start()
        get_nio_logger('WebEngine').info('WebEngine started')

    @classmethod
    def stop(cls):
        """ Stops running Web Servers

        """
        # make it iterate over a new list to avoid
        # dict change size exceptions
        for web_server in list(WebEngineIface.servers.values()):
            web_server.stop()

        get_nio_logger('WebEngine').info('WebEngine stopping')
        cherrypy.engine.stop()
        get_nio_logger('WebEngine').info('WebEngine stopped')
        cherrypy.engine.exit()

    @classmethod
    def block(cls):
        """ Blocks the Web Server until further request arrives
        """
        cherrypy.engine.block()  # pragma: no cover (can't block in tests)

    @classmethod
    def _configure_cherrypy_logs(cls):
        """ Set the cherrypy loggers to NIO configured loggers

        """
        cherrypy.log.error_log = get_nio_logger('cherrypy')
        cherrypy.log.access_log = get_nio_logger('cherrypy.access')

    @classmethod
    def is_started(cls):
        """ Returns if engine has been started/starting or not

        """
        curr_state = str(cherrypy.engine.state)
        return curr_state == 'states.STARTED' or \
            curr_state == 'states.STARTING'
