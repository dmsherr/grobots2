from nio import discoverable
from nio.modules.context import ModuleContext
from nio.modules.settings import Settings
from nio.modules.web.module import WebModule
from niocore.modules.web.cherrypy.engine import WebEngine
from niocore.modules.web.cherrypy.http import CPRequest, CPResponse
from niocore.modules.web.cherrypy.server import CPWebServer


@discoverable
class CherryPyWebModule(WebModule):

    def initialize(self, context):
        super().initialize(context)
        self.proxy_web_engine_class(WebEngine)
        self.proxy_web_server_class(CPWebServer)
        self.proxy_request_class(CPRequest)
        self.proxy_response_class(CPResponse)
        WebEngine.configure(context)

    def _prepare_common_context(self):
        context = ModuleContext()

        context.server_thread_pool = \
            Settings.getint("web", "server_thread_pool", fallback=50)
        context.request_show_tracebacks = \
            Settings.getboolean("web", "request_show_tracebacks",
                                fallback=False)
        context.cors_allow_origin = \
            Settings.get("web", "cors_allow_origin", fallback="*")
        context.cors_allow_methods = \
            Settings.get("web", "cors_allow_methods",
                         fallback="GET,POST,PUT,DELETE,OPTIONS")
        context.cors_allow_headers = \
            Settings.get("web", "cors_allow_headers",
                         fallback="Accept, Origin, Content-Type, Authorization")
        context.cors_allow_credentials = \
            Settings.get("web", "cors_allow_credentials",
                         fallback="true")
        return context

    def prepare_core_context(self):
        return self._prepare_common_context()

    def prepare_service_context(self, service_context=None):
        return self._prepare_common_context()
