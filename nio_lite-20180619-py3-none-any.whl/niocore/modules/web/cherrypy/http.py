"""

   Cherrypy Http classes

"""

import json

import cherrypy

from nio.modules.web.http import HTTPError


class CPRequest(object):

    def __init__(self, request=cherrypy.request):
        self._params = request.params
        self._identifier = self._params.get('identifier')
        self._headers = request.headers
        self._body = request.body
        self._method = request.method
        # A cached copy of the contents of the body. This will only be
        # populated on the first attempt to access the body of this request.
        # Not every request will even have a body and not every request will
        # need to access the body, so we save some logic by caching
        self._body_contents = None

    def _get_length(self):
        """ Retrieves request length

        Returns:
            Content-Length header value
        """
        length_header = self.get_header('Content-Length')
        if not length_header:
            raise HTTPError(411, 'Content-Length is required')

        return int(length_header)

    def _get_content_type(self):
        """ Retrieves request type

        Returns:
            Content-Type header value
        """
        type_header = self.get_header('Content-Type')
        if not type_header:
            raise HTTPError(400, 'Missing Content-Type')

        return type_header

    def get_method(self):
        """ Retrieves request method

        Returns:
            Request method

        """

        return self._method

    def get_body(self):
        """ Retrieves request body

        Makes an attempt to load it as json and return it as dictionary
         if conversion fails, body is returned as read.

        Returns:
            Request body

        """
        # We only want to process the request body once. After that, we can
        # just access the cached copy.
        if self._body_contents is not None:
            return self._body_contents

        body = self._body.read(self._get_length()).decode('utf-8')

        try:
            # assume body is json
            body = json.loads(body)
        except ValueError:
            # if not json, return body as it came
            pass

        self._body_contents = body

        return body

    def get_identifier(self):
        return self._identifier

    def set_identifier(self, identifier):
        self._identifier = identifier

    def get_params(self):
        return self._params

    def get_headers(self):
        return self._headers


class CPResponse(object):

    def __init__(self, body=None):
        self._body = body
        self._status = 200
        self._headers = {}

    def set_header(self, header_name, header_value):
        self._headers[header_name] = header_value

    def set_status(self, status, message=None):
        self._status = status

    def set_body(self, body):
        self._body = body

    def get_status(self):
        return self._status

    def get_headers(self):
        return self._headers

    def get_output_body(self):
        if self._body is None:
            self._body = ""

        return str(self._body)
