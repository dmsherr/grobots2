class DataSerializer(object):
    """ Defines data serializer interface
    
    The data serializer defines how data will be serialized just before 
    sending it to the brew and deserialized after receiving it from the brew
    
    """
    def serialize(self, data):
        """ Override this method to provide data serialization

        Note: This interface potentially provides a way to abstract a 
        future-more-sophisticated mechanism to share data among 
        publishers and subscribers

        Args:
            data: data to serialize
        """
        raise NotImplementedError  # pragma: no cover

    def deserialize(self, data):
        """ Override this method to provide data de-serialization

        Args:
            data: data to de-serialize
        """
        raise NotImplementedError  # pragma: no cover
