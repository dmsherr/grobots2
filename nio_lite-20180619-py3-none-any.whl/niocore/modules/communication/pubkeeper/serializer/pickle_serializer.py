import pickle

from .interface import DataSerializer


class PickleSerializer(DataSerializer):

    def serialize(s, data):
        return pickle.dumps(data)

    def deserialize(self, data):
        return pickle.loads(data)
