import ujson as json

from nio import Signal

from .interface import DataSerializer


class UJSONSerializer(DataSerializer):

    def serialize(s, data):
        signals = [s.to_dict() for s in data]
        return json.dumps(signals).encode()

    def deserialize(self, data):
        signals_json = json.loads(data.decode())
        return [Signal(signal) for signal in signals_json]
