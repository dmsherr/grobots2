from nio.util.logging import get_nio_logger
from nio.util.threading import spawn
from nio.modules.settings import Settings


class PubkeeperServer(object):

    """ Runs a pubkeeper server instance
    """

    _SERVER_THREAD_TERMINATION_TIMEOUT = 2

    def __init__(self):
        super().__init__()
        self.logger = get_nio_logger("PubkeeperServer")
        self._server_thread = None

    @staticmethod
    def get_settings():
        settings = dict()
        settings["ip_address"] = \
            Settings.get("pubkeeper_server", "ip_address",
                         fallback="127.0.0.1")
        settings["port"] = \
            Settings.getint("pubkeeper_server", "port", fallback=9898)
        settings["jwt_secret"] = \
            Settings.get("pubkeeper_server", "jwt_secret", fallback="")
        settings["connect_timeout"] = \
            Settings.getint("pubkeeper_server", "connect_timeout", fallback=2)
        settings["interface"] = \
            Settings.get("pubkeeper_server", "interface", fallback="lo0")
        settings["websocket_ping_interval"] = \
            Settings.getint("pubkeeper_server",
                            "websocket_ping_interval",
                            fallback=10)

        auth_type = Settings.get(
            'pubkeeper_server_auth', 'auth_type', fallback='internal')
        if auth_type == 'local':
            settings["auth"] = PubkeeperServer.get_local_auth_settings()
        elif auth_type == 'internal':
            settings["auth"] = PubkeeperServer.get_internal_auth_settings()
        else:
            raise RuntimeError(
                "Pubkeeper server auth type must be 'local' or "
                "'internal' not '{}'".format(auth_type))

        return settings

    @staticmethod
    def get_internal_auth_settings():
        settings = dict()
        settings["provider"] = \
            "pubkeeper.server.core.auth.internal.provider.InternalAuthProvider"
        settings["token"] = Settings.get("pubkeeper_server_auth", "token")
        return settings

    @staticmethod
    def get_local_auth_settings():
        settings = dict()
        settings["module"] = \
            "pubkeeper.server.core.auth.local.LocalAuthModule"
        settings["provider"] = \
            "pubkeeper.server.core.auth.local.LocalAuthProvider"
        settings["validate"] = Settings.get(
            "pubkeeper_server_auth",
            "validate",
            fallback="http://localhost:9898/auth/validate")
        settings["database"] = Settings.get(
            "pubkeeper_server_auth",
            "database",
            fallback="sqlite///tokens.db")
        settings["enable_ui"] = Settings.getboolean(
            "pubkeeper_server_auth",
            "enable_ui",
            fallback="True")
        initial_token = Settings.get("pubkeeper_server_auth", "initial_token")
        settings["initial_token"] = initial_token
        settings["initial_password"] = Settings.get(
            "pubkeeper_server_auth",
            "initial_password",
            fallback=initial_token)

        return settings

    def start(self, settings):
        """ Starts pubkeeper-server
        """
        self._server_thread = self._start_pubkeeper_server(settings)
        self._wait_for_server_to_start(settings)

    def stop(self):
        """ Stops pubkeeper-server
        """
        self._stop_pubkeeper_server()
        if self._server_thread:
            try:
                if self._server_thread.is_alive():
                    self._server_thread.join(
                        self._SERVER_THREAD_TERMINATION_TIMEOUT)
            except:
                self.logger.exception('Joining server thread')

            if self._server_thread.is_alive():
                self.logger.warning(
                    'After {} seconds Pubkeeper Server thread is still alive'.
                    format(self._SERVER_THREAD_TERMINATION_TIMEOUT))

    def _start_pubkeeper_server(self, settings):
        # perform import at this level to avoid discovery warning
        # when pubkeeper server is not installed

        # Also do it from main thread since start_server top level code sets
        # up a signal handler which is only allowed from the main thread
        from pubkeeper.server.core import start_server

        auth = settings.pop("auth")
        server_thread = spawn(start_server, {'pubkeeper_server': settings,
                                             'auth': auth})
        return server_thread

    def _stop_pubkeeper_server(self):
        # perform import at this level to avoid discovery warning
        # when pubkeeper server is not installed
        from pubkeeper.server.core import stop_server
        try:
            stop_server()
        except Exception:
            self.logger.exception('Failed to stop Pubkeeper Server')

    def _wait_for_server_to_start(self, settings):
        # perform import at this level to avoid discovery warning
        # when pubkeeper server is not installed
        from pubkeeper.server.core import server_started_event
        # wait for server to start
        if server_started_event.wait(settings["connect_timeout"]):
            self.logger.info("Pubkeeper server started successfully")
        else:
            msg = "Pubkeeper server failed to start"
            self.logger.error(msg)
            raise RuntimeError(msg)
