from collections import Iterable

from nio.modules.communication.publisher import PublisherError
from nio.modules.communication.topic import is_topic_valid, InvalidTopic
from nio.util.logging import get_nio_logger
from pubkeeper.utils.exceptions import NoProtocolError

from .manager import Manager


class Publisher(object):
    def __init__(self, topic=None, **kwargs):
        """ Publisher constructor
        Kwargs:
            Arguments describing kind of signals to be published
        """
        self.logger = get_nio_logger("Publisher")
        self._topic = topic

        # topic cannot be empty nor None
        if not is_topic_valid(self._topic):
            raise InvalidTopic("Topic is invalid, topic: {}, kwargs: {}".
                               format(topic, kwargs))

        self._brewer = None

    def open(self, on_connected=None, on_disconnected=None):
        """ Opens publishing channel
        This method delegates functionality to notify others the
        publisher creation and its definitions via a management signal.
        """
        self.logger.debug("Adding publisher with topic: {0}".
                          format(self._topic))
        self._brewer = Manager.add_brewer(self.topic)

        if on_connected is not None:
            Manager.add_on_connected(on_connected)
        if on_disconnected is not None:
            Manager.add_on_disconnected(on_disconnected)

    def is_connected(self):
        return Manager.is_connected()

    def send(self, signals):
        """ Sends signals

        Args:
            signals: Signals to send
        """

        # make sure we can iterate
        if not isinstance(signals, Iterable):
            signals = [signals]

        if self._brewer is None:
            raise PublisherError("Publisher is not opened")

        self.logger.debug('Publishing {} signals to topic: {}'.
                          format(len(signals), self.topic))

        try:
            if Manager.serializer:
                signals = Manager.serializer.serialize(signals)
        except:  # noqa
            self.logger.exception("Unable to serialize signals for publishing")
            return

        try:
            self._brewer.brew(signals)
        except NoProtocolError:
            self.logger.warn("Unable to send signals, no pubkeeper connection")

    def close(self):
        """ Closes publisher.
        """
        if self._brewer:
            self.logger.debug("Removing publisher with topic: {0}".
                              format(self._topic))
            Manager.remove_brewer(self._brewer)

        self._brewer = None

    def is_closed(self):
        return self.closed

    @property
    def topic(self):
        return self._topic

    @property
    def closed(self):
        return self._brewer is None
