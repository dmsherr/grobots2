"""

    Class utility functions to get class type from string

"""


def get_class(cls):
    """ Returns class type from string

    Args:
        cls (str): class namespace

    Returns:
        class type

    """
    from importlib import import_module

    parts = cls.rsplit('.', 1)

    # namespace is in parts[0]
    m = import_module(parts[0])
    # class_name is in parts[1]
    return getattr(m, parts[1])
