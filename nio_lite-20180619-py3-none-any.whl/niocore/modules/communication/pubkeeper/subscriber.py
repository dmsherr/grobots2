from nio.modules.communication.topic import is_topic_valid, InvalidTopic
from nio.util.logging import get_nio_logger

from .manager import Manager


class Subscriber(object):
    """ This class encapsulates the user-facing interface to NIO's
    subscriber.
    """

    def __init__(self, handler, topic=None, **kwargs):
        """ Subscriber constructor
        Kwargs:
            Arguments describing kind of signals to subscribe to
        """
        self.logger = get_nio_logger("Subscriber")
        self._user_handler = handler
        self._patron = None

        self._topic = topic
        if not is_topic_valid(self._topic):
            raise InvalidTopic("Topic is invalid, topic: {}, kwargs: {}".
                               format(topic, kwargs))

    def open(self, on_connected=None, on_disconnected=None):
        """ Subscribes handler to matching publishers
        """
        self.logger.debug("Adding subscriber with topic: {0}".
                          format(self._topic))
        self._patron = Manager.add_patron(self._topic, self.handler)

        if on_connected is not None:
            Manager.add_on_connected(on_connected)
        if on_disconnected is not None:
            Manager.add_on_disconnected(on_disconnected)

    def is_connected(self):
        return Manager.is_connected()

    def close(self):
        """ Closes publisher.
        This method delegates functionality to notify others the
        subscriber removal via a management signal.
        """
        if self._patron:
            self.logger.debug("Removing subscriber with topic: {0}".
                              format(self._topic))
            Manager.remove_patron(self._patron)

        self._patron = None

    def handler(self, signals):
        """ Receives publisher messages
        Args:
            signals: signals coming from publisher
        """
        try:
            if Manager.serializer:
                signals = Manager.serializer.deserialize(signals)
        except:  # noqa
            self.logger.exception("Unable to unserialize signals")
            return

        self.logger.debug("Subscriber received: {} signals".
                          format(len(signals)))
        self._user_handler(signals)
