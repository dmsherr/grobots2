from nio import discoverable
from nio.modules.communication.module import CommunicationModule
from nio.modules.context import ModuleContext
from nio.modules.settings import Settings

from .serializer import UJSONSerializer
from .manager import Manager
from .publisher import Publisher
from .subscriber import Subscriber
from .util.class_reflection import get_class


@discoverable
class PubkeeperCommunicationModule(CommunicationModule):
    def initialize(self, context):
        super().initialize(context)

        if self._server:
            self._server.start(context.pubkeeper_server)

        Manager.configure(context)
        Manager.start()
        # proxy Publisher and Subscriber classes
        self.proxy_publisher_class(Publisher)
        self.proxy_subscriber_class(Subscriber)

    def finalize(self):
        Manager.stop()

        if self._server:
            self._server.stop()

        super().finalize()

    def _prepare_common_context(self, context):
        section = "pubkeeper_client"

        context.pkc_token = Settings.get(
            section, "token", fallback=None)
        context.pkc_host = Settings.get(
            section, "host", fallback=None)
        context.pkc_port = Settings.getint(
            section, "port", fallback=9898)
        context.pkc_ca_chain = Settings.get(
            section, "ca_chain", fallback=None)
        context.pkc_validate = Settings.getboolean(
            section, "validate", fallback=True)
        context.pkc_secure = Settings.getboolean(
            section, "secure", fallback=True)
        context.pkc_ws_ping_interval = Settings.getint(
            section, "websocket_ping_interval", fallback=10)
        context.async = Settings.getboolean(
            section, "async", fallback=True)

        # default data serializer to json serializer
        context.serializer = UJSONSerializer
        # override serializer if specified
        serializer_class = Settings.get(
            section, "serializer", fallback=None)
        if serializer_class:
            context.serializer = get_class(serializer_class)

        # read configurable brews
        context.brew_types = []
        brews = Settings.get(section, "brews", fallback='').split(',')
        for brew in brews:
            brew = brew.strip()
            if not brew:
                # Might have been a trailing comma or an empty list
                continue
            context.brew_types.append(self._get_brew_details(brew))

    def _get_brew_details(self, brew_id):
        """ Get a brew config for our module context based on a brew ID.

        Args:
            brew_id: The unique identifier of the brew, also the name of the
                configuration section where the brew config lives

        Returns:
            (brew_type, brew_settings) (Brew class, dict):
                A tuple of the brew class and a dictionary of options to pass
                to the brew's configure method
        """
        # Figure out the section in the configuration where this brew's
        # details are
        brew_class = Settings.get(brew_id, 'brew_class', fallback=brew_id)
        brew_type = get_class(brew_class)

        # get brew setting names
        settings = brew_type.get_settings()
        # start a brew settings dictionary for each brew
        brew_settings = Settings.get(brew_id, fallback={})
        for setting, value in settings.items():
            # attempt to get setting
            if isinstance(value, bool):
                value = Settings.getboolean(brew_id, setting, fallback=value)
            elif isinstance(value, int):
                value = Settings.getint(brew_id, setting, fallback=value)
            else:
                value = Settings.get(brew_id, setting, fallback=value)

            # add it to brew settings if it has a 'meaningful' value
            if value is not None:
                brew_settings[setting] = value

        return (brew_type, brew_settings)

    def prepare_core_context(self):
        context = ModuleContext()

        # leave prefix empty to have loggers in core without a prefix
        context.logging_prefix = ""

        section = "pubkeeper_server"
        standalone = Settings.getboolean(section, "standalone", fallback=False)
        if standalone:
            from .server import PubkeeperServer

            self._server = PubkeeperServer()
            context.pubkeeper_server = self._server.get_settings()
        else:
            self._server = None

        # does this Node can serve as a Bridge Node?
        section = "pubkeeper_client"
        context.bridge_mode = Settings.get(
            section, "bridge_mode", fallback=False)

        self._prepare_common_context(context)

        return context

    def prepare_service_context(self, service_context=None):
        context = ModuleContext()

        # make sure server is not even considered when in Service mode
        context.pubkeeper_server = None
        self._server = None

        # no service acts as a bridge node
        context.bridge_mode = False

        if service_context and hasattr(service_context, "properties"):
            context.logging_prefix = service_context.properties.get("name")
        else:
            context.logging_prefix = "service"
        self._prepare_common_context(context)

        return context
