from nio.util.logging import get_nio_logger
from pubkeeper.client import PubkeeperClient
from pubkeeper.utils.logging import Logging


class _Manager(object):
    def __init__(self):
        self._pubkeeper = None
        self._serializer = None
        self.logger = get_nio_logger("Comm-Manager")

    def configure(self, context):
        # Reinitialize the logger now that logging has been configured
        self.logger = get_nio_logger("Comm-Manager")
        Logging.prefix = context.logging_prefix
        config = {
            'host': context.pkc_host,
            'port': context.pkc_port,
            'ca_chain': context.pkc_ca_chain,
            'validate': context.pkc_validate,
            'secure': context.pkc_secure,
            'websocket_ping_interval': context.pkc_ws_ping_interval,
            'token': context.pkc_token,
            'bridge_mode': context.bridge_mode
        }
        self._pubkeeper = PubkeeperClient(config)

        for (brew_type, brew_settings) in context.brew_types:
            self.logger.info(
                'Instantiating brew: {}'.format(brew_type.__name__))
            brew = brew_type()
            # configure specific brew grabbing only its settings
            brew.configure(brew_settings)
            if brew_settings.get('name'):
                brew.name = brew_settings.get('name')
            self._pubkeeper.add_brew(brew)

        # create manager's data serializer instance
        self._serializer = context.serializer()
        self._async = context.async

    def start(self):
        try:
            self._pubkeeper.start(_async=self._async)
        except RuntimeError:
            self.logger.exception("Connecting to pubkeeper server")
            self.stop()
            raise

    def stop(self):
        self._pubkeeper.stop()

    def add_brewer(self, topic):
        return self._pubkeeper.add_brewer(topic)

    def remove_brewer(self, brewer):
        self._pubkeeper.remove_brewer(brewer)

    def add_patron(self, topic, callback):
        return self._pubkeeper.add_patron(topic, callback=callback)

    def remove_patron(self, patron):
        self._pubkeeper.remove_patron(patron)

    def add_on_connected(self, callback):
        self._pubkeeper.add_on_connected(callback)

    def add_on_disconnected(self, callback):
        self._pubkeeper.add_on_disconnected(callback)

    def is_connected(self):
        return self._pubkeeper.is_connected()

    @property
    def serializer(self):
        # provide external access to data serializer
        return self._serializer


Manager = _Manager()
