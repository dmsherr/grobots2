# coding: utf-8

import sys
from setuptools import setup, find_packages

NAME = "swagger_server"
VERSION = "1.0.0"

# To install the library, run the following
#
# python setup.py install
#
# prerequisite: setuptools
# http://pypi.python.org/pypi/setuptools

REQUIRES = ["connexion"]

setup(
    name=NAME,
    version=VERSION,
    description="Lift Intelligent Agent API (BETA)",
    author_email="",
    url="",
    keywords=["Swagger", "Lift Intelligent Agent API (BETA)"],
    install_requires=REQUIRES,
    packages=find_packages(),
    package_data={'': ['swagger/swagger.yaml']},
    include_package_data=True,
    entry_points={
        'console_scripts': ['swagger_server=swagger_server.__main__:main']},
    long_description="""\
    *** BETA version for Test Use Only, All Rights Reserved.   Copyright 2015 to 2018 Supply Chain Analytics(TM)  New Global Enterprises (C) 2018 C O N F I D E N T I A L  ***  ## Lift Intelligent Agent API (BETA)  ***    - Currently this API permits 4000 messages per second for the 400 trusted Lift API client endpoints sending approximately 10 messages per second.    - OAuth 2.0 AccessCode Tokens Scopes           - lifts:all                  Grants read access to all lifts       - lifts:active               Grants read access to only active lifts       - lifts:inactive             Grants read access to inactive lifts       - people:liftoperator        Grants read acces to the Lift Operator view       - people:shopmgr             Grants read and write access to the Shop Manager mechanical view       - people:floormgr            Grants read and write access to the Lift Operations management view       - people:mechanic            Grants read access to the Mechanic Lift maintenance view       - people:financialmgr        Grants read and write access to the Financial Manager view  ## Security Definitions        ***   # AccessCode        - Web and Mobile Authenticated Users              - lifts:all                 Grants read access to all lifts         - lifts:active              Grants read access to only active lifts         - lifts:inactive            Grants read access to inactive lifts         - readpublic_key            List and view details for public keys         - people:liftoperator       Lift Operator view         - people:shopmgr            Shop Manager mechanical view         - people:floormgr           Lift Operations Management view         - people:mechanic           Mechanic Lift Maintenance view         - people:financialmgr       Financial Manager view                      ***   # MobileApp_Implicit     - Implicitly Trusted Mobile App with Anonymous User           - readpublic_key              List and view details for public keys            ***   # admin_AccessCode     - administrative purposes          - admin_updatelifts          Grants write access to lifts data         - admin_writepublic_key       Create, list, and view details for public keys         - admin_public_key            Fully manage PKI keys    *** 
    """
)

